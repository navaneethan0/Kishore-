/* ==========================================================================
   RPLMS · Repository & Knowledge Base — client-side prototype
   All data lives in localStorage under key "rplms_repo_kb_v1".
   No backend — this simulates the workflows described in the module spec.
   ========================================================================== */

(function(){
  "use strict";

  const STORAGE_KEY = "rplms_repo_kb_v1";
  const CURRENT_USER = { student: "Aditi Rao", faculty: "Dr. Meera Nair", senior: "Dr. Meera Nair", admin: "Admin Office" };

  const CATEGORY_META = {
    "IoT":               "📡",
    "AI/ML":              "🧠",
    "Web Application":    "🌐",
    "Mobile Application": "📱",
    "Embedded Systems":   "🔧",
    "Robotics":           "🤖",
    "Others":             "📦"
  };

  const PAGE_ROLES = {
    dashboard: ["student","faculty","senior","admin"],
    search:    ["student","faculty","senior","admin"],
    published: ["student","faculty","senior","admin"],
    archived:  ["admin"],
    requests:  ["student","faculty","admin"],
    approvals: ["faculty"],
    history:   ["student","faculty","admin"],
    analytics: ["senior","admin"],
    categories:["admin"]
  };

  /* ---------------- Seed data ---------------- */
  function seedData(){
    const projects = [
      {
        id:"P-1001", title:"Smart Campus Energy Monitor", team:"Team Voltage", year:"2025",
        dept:"Electronics & Comm.", faculty:"Dr. Meera Nair", category:"IoT",
        technologies:["ESP32","MQTT","Node-RED","InfluxDB"],
        keywords:["energy","smart building","sensors"],
        abstract:"A low-cost IoT system that tracks real-time power consumption across campus buildings and flags anomalies before they become outages.",
        documents:["Final Report.pdf","Source Code.zip","Presentation.pptx","Hardware Schematics.pdf"],
        status:"Published", publishedDate:"2025-11-04", downloads:34
      },
      {
        id:"P-1002", title:"Crop Disease Classifier", team:"Team AgroVision", year:"2025",
        dept:"Computer Science", faculty:"Dr. Rakesh Iyer", category:"AI/ML",
        technologies:["PyTorch","ResNet-50","Flask","AWS S3"],
        keywords:["computer vision","agriculture","deep learning"],
        abstract:"A convolutional model that identifies leaf diseases in cotton and wheat crops from phone photos with 94% validation accuracy.",
        documents:["Final Report.pdf","Model Weights.zip","Presentation.pptx"],
        status:"Published", publishedDate:"2025-10-22", downloads:58
      },
      {
        id:"P-1003", title:"Peer Tutoring Marketplace", team:"Team Nexus", year:"2024",
        dept:"Computer Science", faculty:"Dr. Meera Nair", category:"Web Application",
        technologies:["React","Node.js","PostgreSQL","Stripe"],
        keywords:["marketplace","education","booking"],
        abstract:"A booking and payments platform that connects senior students offering tutoring sessions with juniors needing help, with built-in scheduling.",
        documents:["Final Report.pdf","Source Code.zip","ER Diagram.pdf"],
        status:"Published", publishedDate:"2024-12-10", downloads:21
      },
      {
        id:"P-1004", title:"Campus Shuttle Tracker", team:"Team Transit", year:"2024",
        dept:"Information Technology", faculty:"Dr. Kavita Desai", category:"Mobile Application",
        technologies:["Flutter","Firebase","Google Maps API"],
        keywords:["gps","transport","live tracking"],
        abstract:"A cross-platform app giving students live shuttle locations, ETAs and capacity indicators to cut down on wait times.",
        documents:["Final Report.pdf","APK Build.zip"],
        status:"Published", publishedDate:"2024-09-18", downloads:46
      },
      {
        id:"P-1005", title:"Autonomous Warehouse Picker Arm", team:"Team Kinematix", year:"2025",
        dept:"Mechanical Engineering", faculty:"Dr. Rakesh Iyer", category:"Robotics",
        technologies:["ROS2","OpenCV","Arduino Mega"],
        keywords:["robotic arm","pick and place","automation"],
        abstract:"A 4-DOF robotic arm that identifies, grips and sorts warehouse items by colour and shape using a vision pipeline.",
        documents:["Final Report.pdf","CAD Files.zip","Presentation.pptx"],
        status:"Published", publishedDate:"2025-08-30", downloads:19
      },
      {
        id:"P-1006", title:"Wearable Fall-Detection Band", team:"Team Pulse", year:"2025",
        dept:"Electronics & Comm.", faculty:"Dr. Kavita Desai", category:"Embedded Systems",
        technologies:["STM32","BLE","Accelerometer"],
        keywords:["healthcare","wearable","elderly care"],
        abstract:"A wrist-worn device that detects fall patterns via accelerometer data and alerts a caregiver's phone over Bluetooth within two seconds.",
        documents:["Final Report.pdf","Firmware.zip"],
        status:"Archived", publishedDate:"2025-02-14", downloads:12
      },
      {
        id:"P-1007", title:"Digital Library Fine Reminder Bot", team:"Team Overdue", year:"2023",
        dept:"Information Technology", faculty:"Dr. Meera Nair", category:"Others",
        technologies:["Python","Twilio","SQLite"],
        keywords:["automation","library","notifications"],
        abstract:"A scheduled bot that scans due-date records and sends WhatsApp reminders to students before fines accrue.",
        documents:["Final Report.pdf","Source Code.zip"],
        status:"Hidden", publishedDate:"2023-11-02", downloads:7
      },
      {
        id:"P-1008", title:"AI-Assisted Resume Screener", team:"Team Recruitly", year:"2024",
        dept:"Computer Science", faculty:"Dr. Rakesh Iyer", category:"AI/ML",
        technologies:["spaCy","FastAPI","React"],
        keywords:["nlp","hr tech","resume parsing"],
        abstract:"An NLP pipeline that ranks resumes against a job description and highlights matching and missing skills for recruiters.",
        documents:["Final Report.pdf","Source Code.zip","Presentation.pptx"],
        status:"Published", publishedDate:"2024-11-27", downloads:39
      }
    ];

    const requests = [
      {
        id:"R-5001", projectId:"P-1002", requestedBy:"Aditi Rao", role:"student",
        documents:["Final Report.pdf","Model Weights.zip"], reason:"Reference for my final-year project literature review.",
        remarks:"", status:"Pending", requestedAt:daysAgoISO(1), decisionAt:null, expiresAt:null
      },
      {
        id:"R-5002", projectId:"P-1001", requestedBy:"Aditi Rao", role:"student",
        documents:["Final Report.pdf"], reason:"Comparing sensor architectures for my IoT coursework.",
        remarks:"", status:"Approved", requestedAt:daysAgoISO(3), decisionAt:daysAgoISO(2), expiresAt:hoursFromISO(daysAgoISO(2), 24)
      },
      {
        id:"R-5003", projectId:"P-1004", requestedBy:"Aditi Rao", role:"student",
        documents:["Final Report.pdf","APK Build.zip"], reason:"Studying the GPS tracking approach for a similar app.",
        remarks:"Denied — dataset licensing restricted to the original team.", status:"Rejected", requestedAt:daysAgoISO(6), decisionAt:daysAgoISO(5), expiresAt:null
      },
      {
        id:"R-5004", projectId:"P-1003", requestedBy:"Rohan Mehta", role:"student",
        documents:["Final Report.pdf","ER Diagram.pdf"], reason:"Reusing the booking schema design as a reference.",
        remarks:"", status:"Downloaded", requestedAt:daysAgoISO(10), decisionAt:daysAgoISO(9), expiresAt:daysAgoISO(8)
      }
    ];

    const history = [
      {id:"H-1", projectId:"P-1001", user:"Aditi Rao", action:"Requested download", status:"Pending", ts:daysAgoISO(3)},
      {id:"H-2", projectId:"P-1001", user:"Dr. Meera Nair", action:"Approved request", status:"Approved", ts:daysAgoISO(2)},
      {id:"H-3", projectId:"P-1003", user:"Rohan Mehta", action:"Requested download", status:"Pending", ts:daysAgoISO(10)},
      {id:"H-4", projectId:"P-1003", user:"Dr. Meera Nair", action:"Approved request", status:"Approved", ts:daysAgoISO(9)},
      {id:"H-5", projectId:"P-1003", user:"Rohan Mehta", action:"Downloaded files", status:"Downloaded", ts:daysAgoISO(8)},
      {id:"H-6", projectId:"P-1004", user:"Aditi Rao", action:"Requested download", status:"Pending", ts:daysAgoISO(6)},
      {id:"H-7", projectId:"P-1004", user:"Dr. Kavita Desai", action:"Rejected request", status:"Rejected", ts:daysAgoISO(5)},
      {id:"H-8", projectId:"P-1002", user:"Aditi Rao", action:"Requested download", status:"Pending", ts:daysAgoISO(1)}
    ];

    return { projects, requests, history, nextReqId:5005, nextHistId:9 };
  }

  function daysAgoISO(n){ const d=new Date(); d.setDate(d.getDate()-n); return d.toISOString(); }
  function hoursFromISO(iso, h){ const d=new Date(iso); d.setHours(d.getHours()+h); return d.toISOString(); }

  /* ---------------- State load/save ---------------- */
  let DB;
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    DB = raw ? JSON.parse(raw) : seedData();
  }catch(e){ DB = seedData(); }
  function save(){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(DB)); }catch(e){} }

  let role = "student";
  let pendingRequestProjectId = null;

  /* ---------------- Utilities ---------------- */
  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));
  function fmtDate(iso){
    if(!iso) return "—";
    const d = new Date(iso);
    return d.toLocaleDateString(undefined,{ year:"numeric", month:"short", day:"numeric" });
  }
  function fmtDateTime(iso){
    if(!iso) return "—";
    const d = new Date(iso);
    return d.toLocaleDateString(undefined,{ month:"short", day:"numeric" }) + " · " +
           d.toLocaleTimeString(undefined,{ hour:"2-digit", minute:"2-digit" });
  }
  function projectById(id){ return DB.projects.find(p=>p.id===id); }
  function isExpired(req){
    if(req.status!=="Approved" || !req.expiresAt) return false;
    return new Date(req.expiresAt).getTime() < Date.now();
  }
  function effectiveStatus(req){ return isExpired(req) ? "Expired" : req.status; }

  function toast(msg, isError){
    const t = $("#toast");
    t.textContent = msg;
    t.classList.toggle("error", !!isError);
    t.classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(()=> t.classList.remove("show"), 2600);
  }

  /* ---------------- Navigation ---------------- */
  function goto(page){
    $$(".page").forEach(p=>p.classList.remove("active"));
    $$(".tab-btn").forEach(b=>b.classList.remove("active"));
    const target = $("#page-"+page);
    if(!target) return;
    target.classList.add("active");
    const btn = $(`.tab-btn[data-page="${page}"]`);
    if(btn) btn.classList.add("active");
    renderPage(page);
    window.scrollTo({top:0, behavior:"smooth"});
  }

  function applyRoleVisibility(){
    $$(".tab-btn").forEach(btn=>{
      const page = btn.dataset.page;
      const allowed = PAGE_ROLES[page].includes(role);
      btn.style.display = allowed ? "" : "none";
    });
    const activeBtn = $(".tab-btn.active");
    if(!activeBtn || activeBtn.style.display === "none"){
      goto("dashboard");
    }
  }

  /* ---------------- Dashboard ---------------- */
  function renderDashboard(){
    const published = DB.projects.filter(p=>p.status==="Published");
    const pendingReqs = DB.requests.filter(r=>effectiveStatus(r)==="Pending");
    const totalDownloads = DB.projects.reduce((s,p)=>s+p.downloads,0);
    const myRequests = DB.requests.filter(r=>r.requestedBy===CURRENT_USER[role]);

    let stats = [];
    if(role==="student"){
      stats = [
        {num: published.length, label:"Published Projects"},
        {num: myRequests.length, label:"My Download Requests"},
        {num: myRequests.filter(r=>effectiveStatus(r)==="Approved").length, label:"Ready to Download"},
        {num: DB.projects.filter(p=>p.status==="Published").reduce((s,p)=>s+ (new Set(p.category)?1:0),0) && new Set(DB.projects.map(p=>p.category)).size, label:"Categories"}
      ];
    } else if(role==="faculty"){
      stats = [
        {num: pendingReqs.length, label:"Pending Approvals"},
        {num: DB.requests.filter(r=>r.status==="Approved").length, label:"Approved Requests"},
        {num: DB.requests.filter(r=>r.status==="Rejected").length, label:"Rejected Requests"},
        {num: published.length, label:"Published Projects"}
      ];
    } else if(role==="senior"){
      stats = [
        {num: published.length, label:"Published Projects"},
        {num: totalDownloads, label:"Total Downloads"},
        {num: new Set(DB.projects.map(p=>p.dept)).size, label:"Departments Covered"},
        {num: new Set(DB.projects.map(p=>p.category)).size, label:"Active Categories"}
      ];
    } else {
      stats = [
        {num: DB.projects.length, label:"Total Repository Size"},
        {num: DB.projects.filter(p=>p.status==="Archived").length, label:"Archived Projects"},
        {num: DB.projects.filter(p=>p.status==="Hidden").length, label:"Hidden Projects"},
        {num: pendingReqs.length, label:"Pending Requests"}
      ];
    }

    $("#statGrid").innerHTML = stats.map(s=>`
      <div class="stat-card"><div class="num">${s.num}</div><div class="label">${s.label}</div></div>
    `).join("");

    const recent = [...DB.projects].filter(p=>p.status==="Published")
      .sort((a,b)=> new Date(b.publishedDate)-new Date(a.publishedDate)).slice(0,5);
    $("#recentPublished").innerHTML = recent.map(p=>`
      <div class="mini-row">
        <div>
          <div class="title">${p.title}</div>
          <div class="meta">${p.category} · ${p.dept} · ${fmtDate(p.publishedDate)}</div>
        </div>
        <button class="btn ghost small" data-open-details="${p.id}">View</button>
      </div>
    `).join("") || emptyMini("Nothing published yet.");

    const top = [...DB.projects].sort((a,b)=>b.downloads-a.downloads).slice(0,5);
    $("#mostDownloaded").innerHTML = top.map(p=>`
      <div class="mini-row">
        <div>
          <div class="title">${p.title}</div>
          <div class="meta">${p.category} · ${p.dept}</div>
        </div>
        <div class="count">${p.downloads} ⬇</div>
      </div>
    `).join("");

    bindDetailButtons();
  }
  function emptyMini(msg){ return `<div class="mini-row"><div class="meta">${msg}</div></div>`; }

  /* ---------------- Search ---------------- */
  function populateFilterOptions(){
    const cats = [...new Set(DB.projects.map(p=>p.category))].sort();
    const years = [...new Set(DB.projects.map(p=>p.year))].sort().reverse();
    const depts = [...new Set(DB.projects.map(p=>p.dept))].sort();
    $("#filterCategory").innerHTML = `<option value="">All Categories</option>` + cats.map(c=>`<option value="${c}">${c}</option>`).join("");
    $("#filterYear").innerHTML = `<option value="">All Years</option>` + years.map(y=>`<option value="${y}">${y}</option>`).join("");
    $("#filterDept").innerHTML = `<option value="">All Departments</option>` + depts.map(d=>`<option value="${d}">${d}</option>`).join("");
  }

  function renderSearch(){
    const q = $("#searchInput").value.trim().toLowerCase();
    const cat = $("#filterCategory").value;
    const year = $("#filterYear").value;
    const dept = $("#filterDept").value;

    const results = DB.projects.filter(p=>{
      if(p.status!=="Published") return false;
      if(cat && p.category!==cat) return false;
      if(year && p.year!==year) return false;
      if(dept && p.dept!==dept) return false;
      if(!q) return true;
      const hay = [p.title, p.abstract, p.dept, p.faculty, p.category, ...p.technologies, ...p.keywords].join(" ").toLowerCase();
      return hay.includes(q);
    });

    $("#resultCount").textContent = `${results.length} project${results.length===1?"":"s"} found`;
    $("#searchResults").innerHTML = results.map(renderProjectCard).join("") || `<p class="subtitle">No projects match your filters. Try broadening your search.</p>`;
    bindCardActions();
  }

  function renderProjectCard(p){
    const icon = CATEGORY_META[p.category] || "📁";
    return `
    <div class="proj-card">
      <div style="display:flex; justify-content:space-between; align-items:flex-start;">
        <span class="cat-tag blue">${icon} ${p.category}</span>
        <span class="status-pill status-${p.status}">${p.status}</span>
      </div>
      <h3>${p.title}</h3>
      <p class="abstract">${p.abstract}</p>
      <div class="tech-row">${p.technologies.slice(0,4).map(t=>`<span class="tech-pill">${t}</span>`).join("")}</div>
      <div class="meta-row">
        <span><b>${p.team}</b></span>
        <span>${p.dept}</span>
        <span>${p.year}</span>
        <span>${p.faculty}</span>
      </div>
      <div class="card-actions">
        <button class="btn ghost small" data-open-details="${p.id}">View Details</button>
        ${role==="student" ? `<button class="btn primary small" data-open-request="${p.id}">Request Download</button>` : ""}
      </div>
    </div>`;
  }

  function renderPublished(){
    const list = DB.projects.filter(p=>p.status==="Published");
    $("#publishedList").innerHTML = list.map(renderProjectCard).join("") || `<p class="subtitle">No published projects yet.</p>`;
    bindCardActions();
  }

  function renderArchived(){
    const list = DB.projects.filter(p=>p.status==="Archived" || p.status==="Hidden");
    $("#archivedList").innerHTML = list.map(p=>{
      const icon = CATEGORY_META[p.category] || "📁";
      return `
      <div class="proj-card">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <span class="cat-tag blue">${icon} ${p.category}</span>
          <span class="status-pill status-${p.status}">${p.status}</span>
        </div>
        <h3>${p.title}</h3>
        <p class="abstract">${p.abstract}</p>
        <div class="meta-row"><span><b>${p.team}</b></span><span>${p.dept}</span><span>${p.year}</span></div>
        <div class="card-actions">
          <button class="btn ghost small" data-open-details="${p.id}">View Details</button>
          <button class="btn primary small" data-restore="${p.id}">Restore</button>
        </div>
      </div>`;
    }).join("") || `<p class="subtitle">Nothing archived or hidden.</p>`;

    $$("[data-restore]").forEach(b=>b.addEventListener("click", e=>{
      const p = projectById(e.target.dataset.restore);
      p.status = "Published";
      save();
      toast(`"${p.title}" restored to the repository.`);
      renderArchived();
    }));
    bindDetailButtons();
  }

  /* ---------------- Details modal ---------------- */
  function openDetails(id){
    const p = projectById(id);
    if(!p) return;
    const icon = CATEGORY_META[p.category] || "📁";
    $("#detailsBody").innerHTML = `
      <span class="cat-tag blue">${icon} ${p.category}</span>
      <h2 class="detail-title">${p.title}</h2>
      <div class="detail-meta">
        <span><b>Team:</b> ${p.team}</span>
        <span><b>Faculty:</b> ${p.faculty}</span>
        <span><b>Department:</b> ${p.dept}</span>
        <span><b>Year:</b> ${p.year}</span>
        <span><b>Status:</b> ${p.status}</span>
        <span><b>Published:</b> ${fmtDate(p.publishedDate)}</span>
      </div>
      <div class="detail-section">
        <h4>Abstract</h4>
        <p>${p.abstract}</p>
      </div>
      <div class="detail-section">
        <h4>Technologies</h4>
        <div class="tech-row">${p.technologies.map(t=>`<span class="tech-pill">${t}</span>`).join("")}</div>
      </div>
      <div class="detail-section">
        <h4>Keywords</h4>
        <div class="tech-row">${p.keywords.map(t=>`<span class="tech-pill">${t}</span>`).join("")}</div>
      </div>
      <div class="detail-section">
        <h4>Documents (${p.documents.length})</h4>
        <div class="doc-list">
          ${p.documents.map(d=>`<div class="doc-item"><span>📄 ${d}</span><span style="color:var(--ink-soft)">Locked</span></div>`).join("")}
        </div>
      </div>
      <div class="detail-section">
        <h4>Downloads</h4>
        <p>${p.downloads} approved downloads to date.</p>
      </div>
      ${role==="student" && p.status==="Published" ? `<button class="btn primary full" data-open-request="${p.id}" id="detailsRequestBtn">Request Download</button>` : ""}
    `;
    $("#detailsBackdrop").classList.add("open");
    const reqBtn = $("#detailsRequestBtn");
    if(reqBtn) reqBtn.addEventListener("click", ()=>{ closeDetails(); openRequestModal(p.id); });
  }
  function closeDetails(){ $("#detailsBackdrop").classList.remove("open"); }

  function bindDetailButtons(){
    $$("[data-open-details]").forEach(b=> b.onclick = ()=> openDetails(b.dataset.openDetails));
  }
  function bindCardActions(){
    bindDetailButtons();
    $$("[data-open-request]").forEach(b=> b.onclick = ()=> openRequestModal(b.dataset.openRequest));
  }

  /* ---------------- Download request modal ---------------- */
  function openRequestModal(projectId){
    const p = projectById(projectId);
    if(!p) return;
    pendingRequestProjectId = projectId;
    $("#requestProjectName").textContent = `${p.title} · ${p.team}`;
    $("#requestDocs").innerHTML = p.documents.map((d,i)=>`
      <label><input type="checkbox" name="doc" value="${d}" ${i===0?"checked":""}> ${d}</label>
    `).join("");
    $("#requestReason").value = "";
    $("#requestRemarks").value = "";
    $("#requestBackdrop").classList.add("open");
  }
  function closeRequestModal(){ $("#requestBackdrop").classList.remove("open"); pendingRequestProjectId = null; }

  function submitRequest(e){
    e.preventDefault();
    const docs = $$('input[name="doc"]:checked').map(c=>c.value);
    if(docs.length===0){ toast("Select at least one document.", true); return; }
    const reason = $("#requestReason").value.trim();
    if(!reason){ toast("Please provide a reason for download.", true); return; }
    const remarks = $("#requestRemarks").value.trim();

    const req = {
      id: "R-" + (DB.nextReqId++),
      projectId: pendingRequestProjectId,
      requestedBy: CURRENT_USER.student,
      role: "student",
      documents: docs,
      reason, remarks,
      status: "Pending",
      requestedAt: new Date().toISOString(),
      decisionAt: null,
      expiresAt: null
    };
    DB.requests.unshift(req);
    DB.history.unshift({
      id:"H-"+(DB.nextHistId++), projectId:req.projectId, user:req.requestedBy,
      action:"Requested download", status:"Pending", ts:req.requestedAt
    });
    save();
    closeRequestModal();
    toast("Download request submitted for faculty review.");
    if($("#page-requests").classList.contains("active")) renderRequests();
  }

  /* ---------------- Download requests table ---------------- */
  function renderRequests(){
    const subtitle = $("#requestsSubtitle");
    let list = DB.requests;
    if(role==="student"){
      subtitle.textContent = "Track the status of every report you've requested.";
      list = list.filter(r=>r.requestedBy===CURRENT_USER.student);
    } else {
      subtitle.textContent = "All download requests submitted across the repository.";
    }
    list = [...list].sort((a,b)=> new Date(b.requestedAt)-new Date(a.requestedAt));

    $("#requestsTable").innerHTML = list.map(r=>{
      const p = projectById(r.projectId);
      const status = effectiveStatus(r);
      const canDownload = role==="student" && status==="Approved";
      return `
      <tr>
        <td><b>${p ? p.title : r.projectId}</b></td>
        <td>${r.requestedBy}</td>
        <td>${r.documents.length} file${r.documents.length===1?"":"s"}</td>
        <td style="max-width:220px;">${r.reason}</td>
        <td><span class="status-pill status-${status}">${status}</span></td>
        <td>${fmtDateTime(r.requestedAt)}</td>
        <td>${canDownload ? `<button class="btn primary small" data-download="${r.id}">Download</button>` : ""}</td>
      </tr>`;
    }).join("") || `<tr class="empty-row"><td colspan="7">No download requests yet.</td></tr>`;

    $$("[data-download]").forEach(b=> b.onclick = ()=> completeDownload(b.dataset.download));
  }

  function completeDownload(reqId){
    const r = DB.requests.find(x=>x.id===reqId);
    if(!r || effectiveStatus(r)!=="Approved") return;
    r.status = "Downloaded";
    const p = projectById(r.projectId);
    if(p) p.downloads += 1;
    DB.history.unshift({ id:"H-"+(DB.nextHistId++), projectId:r.projectId, user:r.requestedBy, action:"Downloaded files", status:"Downloaded", ts:new Date().toISOString() });
    save();
    toast("Files downloaded. Access link is now consumed.");
    renderRequests();
  }

  /* ---------------- Approvals (faculty) ---------------- */
  function renderApprovals(){
    const pending = DB.requests.filter(r=>r.status==="Pending");
    $("#approvalsList").innerHTML = pending.map(r=>{
      const p = projectById(r.projectId);
      return `
      <div class="proj-card">
        <span class="status-pill status-Pending">Pending Review</span>
        <h3>${p ? p.title : r.projectId}</h3>
        <div class="meta-row"><span><b>Requested by</b> ${r.requestedBy}</span><span>${fmtDateTime(r.requestedAt)}</span></div>
        <div class="detail-section" style="margin-top:2px;">
          <h4>Reason</h4><p>${r.reason}</p>
        </div>
        ${r.remarks ? `<div class="detail-section"><h4>Remarks</h4><p>${r.remarks}</p></div>` : ""}
        <div class="detail-section">
          <h4>Requested Documents</h4>
          <div class="tech-row">${r.documents.map(d=>`<span class="tech-pill">${d}</span>`).join("")}</div>
        </div>
        <div class="card-actions">
          <button class="btn approve small" data-approve="${r.id}">Approve</button>
          <button class="btn reject small" data-reject="${r.id}">Reject</button>
        </div>
      </div>`;
    }).join("") || `<p class="subtitle">No pending requests — you're all caught up.</p>`;

    $$("[data-approve]").forEach(b=> b.onclick = ()=> decideRequest(b.dataset.approve, "Approved"));
    $$("[data-reject]").forEach(b=> b.onclick = ()=> decideRequest(b.dataset.reject, "Rejected"));
  }

  function decideRequest(reqId, decision){
    const r = DB.requests.find(x=>x.id===reqId);
    if(!r) return;
    r.status = decision;
    r.decisionAt = new Date().toISOString();
    if(decision==="Approved") r.expiresAt = hoursFromISO(r.decisionAt, 24);
    DB.history.unshift({
      id:"H-"+(DB.nextHistId++), projectId:r.projectId, user: CURRENT_USER.faculty,
      action: decision==="Approved" ? "Approved request" : "Rejected request",
      status: decision, ts: r.decisionAt
    });
    save();
    toast(`Request ${decision.toLowerCase()}.${decision==="Approved" ? " Access valid for 24 hours." : ""}`);
    renderApprovals();
  }

  /* ---------------- History ---------------- */
  function renderHistory(){
    let list = DB.history;
    if(role==="student") list = list.filter(h=>h.user===CURRENT_USER.student);
    list = [...list].sort((a,b)=> new Date(b.ts)-new Date(a.ts));

    $("#historyTable").innerHTML = list.map(h=>{
      const p = projectById(h.projectId);
      return `
      <tr>
        <td><b>${p ? p.title : h.projectId}</b></td>
        <td>${h.user}</td>
        <td>${h.action}</td>
        <td><span class="status-pill status-${h.status}">${h.status}</span></td>
        <td>${fmtDateTime(h.ts)}</td>
      </tr>`;
    }).join("") || `<tr class="empty-row"><td colspan="5">No history recorded yet.</td></tr>`;
  }

  /* ---------------- Analytics ---------------- */
  function renderAnalytics(){
    const published = DB.projects.filter(p=>p.status==="Published");
    const totalDownloads = DB.projects.reduce((s,p)=>s+p.downloads,0);

    $("#analyticsStats").innerHTML = [
      {num: DB.projects.length, label:"Total Projects"},
      {num: published.length, label:"Published"},
      {num: totalDownloads, label:"Total Downloads"},
      {num: new Set(DB.projects.map(p=>p.dept)).size, label:"Departments"}
    ].map(s=>`<div class="stat-card"><div class="num">${s.num}</div><div class="label">${s.label}</div></div>`).join("");

    renderBarChart("#chartCategory", groupCount(DB.projects, p=>p.category));
    renderBarChart("#chartDept", groupCount(DB.projects, p=>p.dept));

    const top = [...DB.projects].sort((a,b)=>b.downloads-a.downloads).slice(0,6);
    $("#topDownloadsList").innerHTML = top.map(p=>`
      <div class="mini-row">
        <div><div class="title">${p.title}</div><div class="meta">${p.category} · ${p.dept}</div></div>
        <div class="count">${p.downloads} ⬇</div>
      </div>
    `).join("");
  }

  function groupCount(arr, keyFn){
    const map = {};
    arr.forEach(item=>{ const k = keyFn(item); map[k] = (map[k]||0)+1; });
    return map;
  }

  function renderBarChart(sel, dataMap){
    const entries = Object.entries(dataMap).sort((a,b)=>b[1]-a[1]);
    const max = Math.max(...entries.map(e=>e[1]), 1);
    $(sel).innerHTML = entries.map(([label,val])=>`
      <div class="bar-row">
        <span class="bar-label">${label}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${(val/max*100).toFixed(0)}%"></div></div>
        <span class="bar-val">${val}</span>
      </div>
    `).join("");
  }

  /* ---------------- Categories ---------------- */
  function renderCategories(){
    const counts = groupCount(DB.projects.filter(p=>p.status==="Published"), p=>p.category);
    const cats = Object.keys(CATEGORY_META);
    $("#categoryGrid").innerHTML = cats.map(c=>`
      <div class="cat-card">
        <div class="cat-icon">${CATEGORY_META[c]}</div>
        <h3>${c}</h3>
        <div class="cat-count">${counts[c]||0}</div>
        <div class="cat-count-label">published projects</div>
      </div>
    `).join("");
  }

  /* ---------------- Router ---------------- */
  function renderPage(page){
    switch(page){
      case "dashboard": renderDashboard(); break;
      case "search": populateFilterOptions(); renderSearch(); break;
      case "published": renderPublished(); break;
      case "archived": renderArchived(); break;
      case "requests": renderRequests(); break;
      case "approvals": renderApprovals(); break;
      case "history": renderHistory(); break;
      case "analytics": renderAnalytics(); break;
      case "categories": renderCategories(); break;
    }
  }

  /* ---------------- Init & events ---------------- */
  function init(){
    $$(".tab-btn").forEach(btn=>{
      btn.addEventListener("click", ()=> goto(btn.dataset.page));
    });
    $$("[data-goto]").forEach(btn=>{
      btn.addEventListener("click", ()=> goto(btn.dataset.goto));
    });

    $("#roleSelect").addEventListener("change", e=>{
      role = e.target.value;
      applyRoleVisibility();
      renderPage(currentPageId());
    });

    $("#searchInput").addEventListener("input", debounce(renderSearch, 150));
    $("#filterCategory").addEventListener("change", renderSearch);
    $("#filterYear").addEventListener("change", renderSearch);
    $("#filterDept").addEventListener("change", renderSearch);
    $("#clearFilters").addEventListener("click", ()=>{
      $("#searchInput").value=""; $("#filterCategory").value=""; $("#filterYear").value=""; $("#filterDept").value="";
      renderSearch();
    });

    $("#detailsClose").addEventListener("click", closeDetails);
    $("#detailsBackdrop").addEventListener("click", e=>{ if(e.target.id==="detailsBackdrop") closeDetails(); });

    $("#requestClose").addEventListener("click", closeRequestModal);
    $("#requestBackdrop").addEventListener("click", e=>{ if(e.target.id==="requestBackdrop") closeRequestModal(); });
    $("#requestForm").addEventListener("submit", submitRequest);

    document.addEventListener("keydown", e=>{
      if(e.key==="Escape"){ closeDetails(); closeRequestModal(); }
    });

    applyRoleVisibility();
    renderDashboard();
  }

  function currentPageId(){
    const active = $(".page.active");
    return active ? active.id.replace("page-","") : "dashboard";
  }
  function debounce(fn, ms){
    let t; return (...args)=>{ clearTimeout(t); t=setTimeout(()=>fn(...args), ms); };
  }

  document.addEventListener("DOMContentLoaded", init);
})();
