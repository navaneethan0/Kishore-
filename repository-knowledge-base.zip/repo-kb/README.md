# RPLMS — Repository & Knowledge Base Module

A self-contained HTML/CSS/JS prototype of the Repository & Knowledge Base module
described in the Student 10 spec. Pure front-end (no build step, no backend) —
data is mocked and persisted to the browser's `localStorage` so your changes
stick between reloads.

## Files
- `index.html` — page structure & all views (Dashboard, Search, Published,
  Archived, Download Requests, Approvals, History, Analytics, Categories)
- `style.css` — blue-themed design system (tokens, components, responsive layout)
- `script.js` — app logic: mock data, search/filter, download request &
  24-hour approval workflow, history log, analytics charts, role switching

## Run it
Just open `index.html` in any modern browser. No server or install required.
(A local server like `python3 -m http.server` works too, but isn't needed.)

## Try the roles
Use the **"Viewing as"** dropdown top-right to switch between:
- **Student** — search repository, view details, request downloads, view own history
- **Technical Faculty** — review and approve/reject pending download requests
- **Senior Faculty** — view repository analytics
- **Admin** — view repository statistics, archive/hide/restore projects

## Core workflow implemented
1. Student searches the repository and opens a project's details.
2. Student submits a **Download Request** (documents, reason, remarks).
3. Faculty reviews it on the **Approvals** page and approves or rejects.
4. On approval, a 24-hour access window opens; the student can download once
   from the **Download Requests** table before it expires.
5. Every action is logged to **Download History**.
6. **Analytics** and **Categories** pages summarize the repository by
   category, department and download counts.

## Notes
- Data resets if you clear your browser's local storage for this file, or
  clear it manually via your browser's DevTools.
- This is a UI/workflow prototype — the "download" action simulates the
  file transfer rather than serving real files.
