﻿/* ============================================================
   ILP RAPID PROTOTYPING LAB - DASHBOARD JAVASCRIPT
   Dashboard-only logic, data, and interactivity
   ============================================================ */

/* ------------------------------------------------------------
   STORAGE KEY - localStorage key for dashboard data
   ------------------------------------------------------------ */
const STORAGE_KEY = 'ilp_dashboard_v3';

/* ------------------------------------------------------------
   PROJECT STATUS COLORS - Donut chart segment colors
   ------------------------------------------------------------ */
const STATUS_COLORS = {
  'Not Started': '#3b82f6',
  'In Progress': '#60a5fa',
  'Under Review': '#f59e0b',
  'Completed': '#22c55e'
};

/* ------------------------------------------------------------
   DEFAULT DATA - Seed data for dashboard widgets
   ------------------------------------------------------------ */
const DEFAULT_DATA = {
  admin: {
    name: 'Dr. Karthik',
    role: 'Senior Faculty',
    employeeId: 'SC-001',
    email: 'senior@ilp.com',
    phone: '9876543210',
    department: 'Rapid Prototyping Lab',
    joinedOn: 'January 2026'
  },
  isLoggedIn: true,
  students: [
    { id: 'STU-001', name: 'Rahul Sharma', team: 'Team Alpha' },
    { id: 'STU-002', name: 'Priya Patel', team: 'Team Beta' },
    { id: 'STU-003', name: 'Amit Kumar', team: 'Team Gamma' }
  ],
  staff: [
    { id: 'STF-001', name: 'Dr. Suresh Menon', role: 'Technical Mentor' },
    { id: 'STF-002', name: 'Anita Desai', role: 'Lab Engineer' },
    { id: 'STF-003', name: 'Vikram Singh', role: 'Project Supervisor' }
  ],
  teams: [
    { id: 'TEAM-001', name: 'Team Alpha', project: 'Smart IoT Sensor', members: 4 },
    { id: 'TEAM-002', name: 'Team Beta', project: 'Robotic Arm Controller', members: 3 },
    { id: 'TEAM-003', name: 'Team Gamma', project: '3D Printing Optimizer', members: 5 }
  ],
  projects: [
    { id: 'PRJ-001', name: 'Design Phase (Stage 3) Submission', team: 'Team Alpha', deadline: '2026-05-20', status: 'In Progress' },
    { id: 'PRJ-002', name: 'Product Development (Stage 4)', team: 'Team Beta', deadline: '2026-07-15', status: 'Not Started' },
    { id: 'PRJ-003', name: 'Testing & Validation (Stage 5)', team: 'Team Gamma', deadline: '2026-07-29', status: 'Under Review' },
    { id: 'PRJ-004', name: 'Prototype Assembly', team: 'Team Alpha', deadline: '2026-04-15', status: 'Completed' },
    { id: 'PRJ-005', name: 'Research Documentation', team: 'Team Beta', deadline: '2026-08-20', status: 'In Progress' }
  ],
  notifications: [
    { id: 1, message: 'New deadline approaching for Team Alpha', time: '2 hours ago', read: false, type: 'deadline' },
    { id: 2, message: 'Ticket requires attention', time: '5 hours ago', read: false, type: 'ticket' },
    { id: 3, message: 'Team Beta submitted Stage 4 report', time: '1 day ago', read: false, type: 'project' }
  ]
};

/* In-memory application state */
let appData = {};

/* ------------------------------------------------------------
   DOM READY - Initialize dashboard on page load
   ------------------------------------------------------------ */
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  lucide.createIcons();


  initSidebar();
  initHeader();
  initModals();

  initDashboardActions();

  renderDashboard();
  renderProfileModal();
  renderNotifications();
  updateNotificationBadge();
});

/* ============================================================
   DATA MANAGEMENT
   ============================================================ */

/** Load data from localStorage or use defaults */
function loadData() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      appData = { ...DEFAULT_DATA, ...JSON.parse(saved) };
    } catch (e) {
      appData = { ...DEFAULT_DATA };
    }
  } else {
    appData = { ...DEFAULT_DATA };
    saveData();
  }
}

/** Save current data to localStorage */
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
}

/* ============================================================
   AUTHENTICATION - Login / sign out
   ============================================================ */


/* ============================================================
   SIDEBAR - Mobile toggle
   ============================================================ */

function initSidebar() {
  document.getElementById('hamburgerBtn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
  });

  document.getElementById('sidebarOverlay').addEventListener('click', closeSidebar);

  document.querySelectorAll('.dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const targetId = btn.getAttribute('aria-controls');
      const group = btn.closest('.nav-group') || btn.closest('.nav-dropdown');
      const menu = document.getElementById(targetId) || (group ? group.querySelector('.dropdown-menu') : null);
      const isActive = btn.classList.contains('active');

      document.querySelectorAll('.dropdown-toggle').forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-expanded', 'false');
      });
      document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));
      document.querySelectorAll('.sub-dropdown-toggle').forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-expanded', 'false');
      });
      document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));

      if (!isActive) {
        btn.classList.add('active');
        btn.setAttribute('aria-expanded', 'true');
        if (menu) menu.classList.add('active');
      }
    });
  });

  // Register sub-dropdown menu toggles
  document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const targetId = btn.getAttribute('aria-controls');
      const group = btn.closest('.nav-subgroup');
      const menu = document.getElementById(targetId) || (group ? group.querySelector('.sub-dropdown-menu') : null);
      const isActive = btn.classList.contains('active');

      if (menu) {
        if (isActive) {
          btn.classList.remove('active');
          btn.setAttribute('aria-expanded', 'false');
          menu.classList.remove('active');
        } else {
          btn.classList.add('active');
          btn.setAttribute('aria-expanded', 'true');
          menu.classList.add('active');
        }
      }
    });
  });
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('active');
}

/* ============================================================
   HEADER - Notifications and profile
   ============================================================ */

function initHeader() {
  // NOTE: Notification dropdown toggle is handled by global_header.js
  // We only set up the markAllRead behaviour here so it uses real appData
  const markAllBtn = document.getElementById('markAllReadBtn');
  if (markAllBtn) {
    markAllBtn.addEventListener('click', () => {
      appData.notifications.forEach(n => { n.read = true; });
      saveData();
      renderNotifications();
      updateNotificationBadge();
      showToast('All notifications marked as read', 'success');
    });
  }
}

/* ============================================================
   MODALS - Profile and sign out
   ============================================================ */

function initModals() {

  document.getElementById('closeProfileBtn').addEventListener('click', () => closeModal('profileModal'));

  document.getElementById('editProfileBtn').addEventListener('click', () => {
    closeModal('profileModal');
    openEditProfileModal();
  });

  document.getElementById('closeEditProfileModal').addEventListener('click', () => closeModal('editProfileModal'));
  document.getElementById('cancelEditProfile').addEventListener('click', () => closeModal('editProfileModal'));
  document.getElementById('saveEditProfile').addEventListener('click', saveProfile);


  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.active').forEach(modal => {
        closeModal(modal.id);
      });
    }
  });
}

function openModal(modalId) {
  document.getElementById(modalId).classList.add('active');
  lucide.createIcons();
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
}

function openEditProfileModal() {
  const admin = appData.admin;
  document.getElementById('editName').value = admin.name;
  document.getElementById('editEmail').value = admin.email;
  document.getElementById('editPhone').value = admin.phone;
  document.getElementById('editDepartment').value = admin.department;
  openModal('editProfileModal');
}

function saveProfile() {
  appData.admin.name = document.getElementById('editName').value;
  appData.admin.email = document.getElementById('editEmail').value;
  appData.admin.phone = document.getElementById('editPhone').value;
  appData.admin.department = document.getElementById('editDepartment').value;
  saveData();
  closeModal('editProfileModal');
  updateHeaderProfile();
  renderProfileModal();
  showToast('Profile updated successfully', 'success');
}

/* ============================================================
   DASHBOARD ACTIONS - Quick actions and view-all buttons
   ============================================================ */

function initDashboardActions() {
  document.getElementById('viewAllProjectsBtn').addEventListener('click', () => {
    showToast('Projects page will be added in the full application', 'warning');
  });

  document.getElementById('viewAllDeadlinesBtn').addEventListener('click', () => {
    showToast('Showing all upcoming deadlines on dashboard', 'success');
    renderDeadlines(true);
  });

  document.querySelectorAll('.quick-action-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action;

    if (action === "Add New Trainee" || action === "Add Faculty") {
      window.location.href = "add_profiles.html";
    }
    else if (action === "Create New Team") {
      window.location.href = "create_team.html";
    }
    else if (action === "View Faculty List") {
      window.location.href = "faculty.html";
    }
    else if (action === "View Trainee List") {
      window.location.href = "trainee.html";
    }
    else if (action === "View Projects") {
      window.location.href = "project_details.html";
    }
    else {
      showToast(`${action} — available in full application`, 'warning');
    }
  });
});
}

/* ============================================================
   DASHBOARD RENDERING
   ============================================================ */

function renderDashboard() {
  updateHeaderProfile();

  document.getElementById('statTeams').textContent = appData.teams.length;
  document.getElementById('statStudents').textContent = appData.students.length;
  document.getElementById('statCompleted').textContent =
    appData.projects.filter(p => p.status === 'Completed').length;
  document.getElementById('statStaff').textContent = appData.staff.length;

  renderDonutChart();
  renderDeadlines();
}

function updateHeaderProfile() {
  const admin = appData.admin;
  // document.getElementById('headerUserName').textContent = admin.name;
  document.getElementById('headerUserRole').textContent = admin.role;
  //document.getElementById('welcomeName').textContent = admin.name;
}

function renderProfileModal() {
  const admin = appData.admin;
  document.getElementById('modalUserName').textContent = admin.name;
  document.getElementById('modalUserRole').textContent = admin.role;
  document.getElementById('modalEmployeeId').textContent = admin.employeeId;
  document.getElementById('modalEmail').textContent = admin.email;
  document.getElementById('modalPhone').textContent = admin.phone;
  document.getElementById('modalDepartment').textContent = admin.department;
  document.getElementById('modalJoined').textContent = admin.joinedOn;
}

/** Build interactive SVG donut chart with hover tooltips */
function renderDonutChart() {
  const statuses = ['Not Started', 'In Progress', 'Under Review', 'Completed'];
  const statusCounts = {};
  appData.projects.forEach(p => {
    statusCounts[p.status] = (statusCounts[p.status] || 0) + 1;
  });

  const total = appData.projects.length;
  document.getElementById('donutTotal').textContent = total;

  const svg = document.getElementById('donutSvg');
  const tooltip = document.getElementById('chartTooltip');
  const radius = 70;
  const strokeWidth = 28;
  const center = 90;
  const circumference = 2 * Math.PI * radius;
  const gap = 4;

  svg.innerHTML = '';
  let accumulated = 0;

  statuses.forEach(status => {
    const count = statusCounts[status] || 0;
    if (count === 0) return;

    const segmentLength = (count / total) * circumference;
    const visibleLength = Math.max(segmentLength - gap, 1);
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;

    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', center);
    circle.setAttribute('cy', center);
    circle.setAttribute('r', radius);
    circle.setAttribute('fill', 'none');
    circle.setAttribute('stroke', STATUS_COLORS[status]);
    circle.setAttribute('stroke-width', strokeWidth);
    circle.setAttribute('stroke-dasharray', `${visibleLength} ${circumference - visibleLength}`);
    circle.setAttribute('stroke-dashoffset', String(-accumulated));
    circle.setAttribute('class', 'donut-segment');
    circle.setAttribute('data-status', status);

    circle.addEventListener('mouseenter', () => {
      highlightChartSegment(status, `${status}: ${count} (${pct}%)`);
    });
    circle.addEventListener('mouseleave', clearChartHighlight);

    svg.appendChild(circle);
    accumulated += segmentLength;
  });

  const legend = document.getElementById('chartLegend');
  legend.innerHTML = statuses.map(status => {
    const count = statusCounts[status] || 0;
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;
    return `
      <li data-status="${status}">
        <span class="legend-dot" style="background: ${STATUS_COLORS[status]}"></span>
        <span>${status}</span>
       
          <span class="legend-count"> (${pct}%)</span>
      </li>
    `;
  }).join('');

  legend.querySelectorAll('li').forEach(item => {
    const status = item.dataset.status;
    const count = statusCounts[status] || 0;
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;

    item.addEventListener('mouseenter', () => {
      highlightChartSegment(status, `${status}: ${count} (${pct}%)`);
    });
    item.addEventListener('mouseleave', clearChartHighlight);
  });
}

/** Highlight a chart segment and show tooltip on hover */
function highlightChartSegment(status, text) {
  const tooltip = document.getElementById('chartTooltip');
  tooltip.textContent = text;
  tooltip.classList.add('visible');

  document.querySelectorAll('.donut-segment').forEach(seg => {
    seg.classList.toggle('active', seg.dataset.status === status);
    seg.classList.toggle('dimmed', seg.dataset.status !== status);
  });

  document.querySelectorAll('.chart-legend li').forEach(item => {
    item.classList.toggle('active', item.dataset.status === status);
  });
}

/** Reset chart hover highlight state */
function clearChartHighlight() {
  document.getElementById('chartTooltip').classList.remove('visible');
  document.querySelectorAll('.donut-segment').forEach(seg => {
    seg.classList.remove('active', 'dimmed');
  });
  document.querySelectorAll('.chart-legend li').forEach(item => {
    item.classList.remove('active');
  });
}

/**
 * Returns badge class and label based on days remaining.
 * @param {number} daysLeft - Days until deadline (negative = overdue)
 */
function getDeadlineBadge(daysLeft) {
  if (daysLeft < 0) {
    return { className: 'overdue', label: `${Math.abs(daysLeft)} Days Overdue` };
  }
  if (daysLeft === 0) {
    return { className: 'critical', label: 'Due Today' };
  }
  if (daysLeft <= 7) {
    return { className: 'critical', label: `${daysLeft} Days Left` };
  }
  if (daysLeft <= 14) {
    return { className: 'urgent', label: `${daysLeft} Days Left` };
  }
  // if (daysLeft <= 19) {
  //   return { className: 'safe', label: `${daysLeft} Days Left` };
  // }
  return { className: 'safe', label: `${daysLeft} Days Left` };
}

/**
 * Render upcoming deadline list.
 * @param {boolean} showAll - If true, show all non-completed projects
 */
function renderDeadlines(showAll = false) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sorted = [...appData.projects]
    .filter(p => p.status !== 'Completed')
    .sort((a, b) => new Date(a.deadline) - new Date(b.deadline));

  const items = showAll ? sorted : sorted.slice(0, 3);
  const list = document.getElementById('deadlineList');

  if (items.length === 0) {
    list.innerHTML = '<li class="empty-state">No upcoming deadlines</li>';
    return;
  }

  list.innerHTML = items.map(project => {
    const deadline = new Date(project.deadline);
    const daysLeft = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
    const month = deadline.toLocaleString('en-US', { month: 'short' }).toUpperCase();
    const day = deadline.getDate();
    const badge = getDeadlineBadge(daysLeft);

    return `
      <li class="deadline-item">
        <div class="deadline-date">
          <span class="deadline-month">${month}</span>
          <span class="deadline-day">${day}</span>
        </div>
        <div class="deadline-info">
          <p class="deadline-title">${project.name}</p>
          <p class="deadline-team">${project.team}</p>
        </div>
        <span class="deadline-badge ${badge.className}">${badge.label}</span>
      </li>
    `;
  }).join('');
}

/* ============================================================
   NOTIFICATIONS
   ============================================================ */

function renderNotifications() {
  const list = document.getElementById('notificationList');
  const iconColors = {
    deadline: { bg: '#fef2f2', color: '#ef4444' },
    ticket: { bg: '#fffbeb', color: '#f59e0b' },
    project: { bg: '#dbeafe', color: '#3b82f6' }
  };

  list.innerHTML = appData.notifications.map(n => {
    const ic = iconColors[n.type] || iconColors.project;
    return `
      <li class="notification-item ${n.read ? '' : 'unread'}" data-id="${n.id}">
        <div class="notification-icon" style="background: ${ic.bg}; color: ${ic.color}">
          <i data-lucide="bell"></i>
        </div>
        <div class="notification-content">
          <p>${n.message}</p>
          <span>${n.time}</span>
        </div>
      </li>
    `;
  }).join('');

  list.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', () => {
      const id = parseInt(item.dataset.id, 10);
      const notif = appData.notifications.find(n => n.id === id);
      if (notif) {
        notif.read = true;
        saveData();
        renderNotifications();
        updateNotificationBadge();
      }
    });
  });

  lucide.createIcons();
}

function updateNotificationBadge() {
  const unread = appData.notifications.filter(n => !n.read).length;
  const badge = document.getElementById('notificationBadge');
  badge.textContent = unread;
  badge.classList.toggle('hidden', unread === 0);
}

/* ============================================================
   TOAST MESSAGES
   ============================================================ */

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = { success: 'check-circle', error: 'x-circle', warning: 'alert-triangle' };
  toast.innerHTML = `
    <i data-lucide="${icons[type] || 'info'}"></i>
    <p>${message}</p>
  `;

  container.appendChild(toast);
  lucide.createIcons();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
function initModernDashboard() {

    lucide.createIcons();

    const filters = document.querySelectorAll('.dashboard-filter');

    filters.forEach(filter => {

        filter.addEventListener('change', () => {

            showToast(
                `${filter.value} selected`,
                'success'
            );

        });

    });

}

const dashboardData = {

    "2026": {
        trainees: 540,
        projects: 118,
        faculty: 32,
        nearDeadline: 12,
waitingResources: 5,
overdueProjects: 2,
developmentProjects: 33,
testingProjects: 14,
documentationPending: 8,
projectOverview: {
completed: 38,
progress: 32,
planned: 30
},

        batches: {
            batch1: {
    trainees: 120,
    projects: 28,
    faculty: 8,
    projectOverview: {
        completed: 100,
        progress: 0,
        planned: 0
    },

    teams: [
        {
            name: "Team Alpha",
            status: "Completed",
            members: 5,
            progress: 100,
            color: "green-fill"
        },
        {
            name: "Team Beta",
            status: "Completed",
            members: 4,
            progress: 100,
            color: "green-fill"
        },
        {
            name: "Team Gamma",
            status: "Completed",
            members: 6,
            progress: 100,
            color: "green-fill"
        }
    ]
},

            batch2: {
    trainees: 160,
    projects: 36,
    faculty: 8,

    nearDeadline: 5,
    waitingResources: 3,
    overdueProjects: 1,
    developmentProjects: 18,
    testingProjects: 8,
    documentationPending: 5,

    projectOverview: {
        completed: 45,
        progress: 35,
        planned: 20
    },

    teams: [
        {
            name: "Team Alpha",
            status: "Completed",
            members: 5,
            progress: 100,
            color: "green-fill"
        },
        {
            name: "Team Beta",
            status: "Development",
            members: 4,
            progress: 75,
            color: "blue-fill"
        },
        {
            name: "Team Gamma",
            status: "Testing",
            members: 6,
            progress: 60,
            color: "orange-fill"
        },
        {
            name: "Team Delta",
            status: "Planned",
            members: 5,
            progress: 20,
            color: "purple-fill"
        }
    ]
},

            batch3: {
    trainees: 140,
    projects: 32,
    faculty: 8,

    nearDeadline: 7,
    waitingResources: 2,
    overdueProjects: 4,
    developmentProjects: 15,
    testingProjects: 6,
    documentationPending: 4,

    projectOverview: {
        completed: 30,
        progress: 50,
        planned: 20
    },

    teams: [
        {
            name: "Team Alpha",
            status: "Completed",
            members: 5,
            progress: 100,
            color: "green-fill"
        },
        {
            name: "Team Beta",
            status: "Development",
            members: 4,
            progress: 70,
            color: "blue-fill"
        },
        {
            name: "Team Gamma",
            status: "Development",
            members: 6,
            progress: 55,
            color: "blue-fill"
        },
        {
            name: "Team Delta",
            status: "Testing",
            members: 5,
            progress: 40,
            color: "orange-fill"
        },
        {
            name: "Team Epsilon",
            status: "Planned",
            members: 4,
            progress: 20,
            color: "purple-fill"
        }
    ]
},

            batch4: {
    trainees: 120,
    projects: 22,
    faculty: 8,

    nearDeadline: 0,
    waitingResources: 0,
    overdueProjects: 0,
    developmentProjects: 0,
    testingProjects: 0,
    documentationPending: 0,

    projectOverview: {
        completed: 0,
        progress: 0,
        planned: 100
    },

    teams: [
        {
            name: "Team Alpha",
            status: "Planned",
            members: 5,
            progress: 0,
            color: "purple-fill"
        },
        {
            name: "Team Beta",
            status: "Planned",
            members: 4,
            progress: 0,
            color: "purple-fill"
        },
        {
            name: "Team Gamma",
            status: "Planned",
            members: 6,
            progress: 0,
            color: "purple-fill"
        },
        {
            name: "Team Delta",
            status: "Planned",
            members: 5,
            progress: 0,
            color: "purple-fill"
        }
    ]
},
        }
    },

    "2025": {
    trainees: 430,
    projects: 90,
    faculty: 26,

    nearDeadline: 8,
    waitingResources: 3,
    overdueProjects: 1,
    developmentProjects: 22,
    testingProjects: 10,
    documentationPending: 6,

    projectOverview: {
        completed: 55,
        progress: 30,
        planned: 15
    },

    batches: {

        batch1: {
            trainees: 110,
            projects: 24,
            faculty: 6,

            nearDeadline: 0,
            waitingResources: 0,
            overdueProjects: 0,
            developmentProjects: 0,
            testingProjects: 0,
            documentationPending: 0,

            projectOverview: {
                completed: 100,
                progress: 0,
                planned: 0
            },

            teams: [
                {
                    name: "Team Alpha",
                    status: "Completed",
                    members: 5,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Beta",
                    status: "Completed",
                    members: 4,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Gamma",
                    status: "Completed",
                    members: 6,
                    progress: 100,
                    color: "green-fill"
                }
            ]
        },

        batch2: {
            trainees: 120,
            projects: 26,
            faculty: 7,

            nearDeadline: 3,
            waitingResources: 1,
            overdueProjects: 0,
            developmentProjects: 12,
            testingProjects: 4,
            documentationPending: 2,

            projectOverview: {
                completed: 50,
                progress: 35,
                planned: 15
            },

            teams: [
                {
                    name: "Team Delta",
                    status: "Completed",
                    members: 5,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Epsilon",
                    status: "Development",
                    members: 4,
                    progress: 70,
                    color: "blue-fill"
                },
                {
                    name: "Team Zeta",
                    status: "Testing",
                    members: 5,
                    progress: 50,
                    color: "orange-fill"
                }
            ]
        },

        batch3: {
            trainees: 100,
            projects: 20,
            faculty: 6,

            nearDeadline: 4,
            waitingResources: 2,
            overdueProjects: 1,
            developmentProjects: 8,
            testingProjects: 4,
            documentationPending: 3,

            projectOverview: {
                completed: 35,
                progress: 45,
                planned: 20
            },

            teams: [
                {
                    name: "Team Eta",
                    status: "Completed",
                    members: 5,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Theta",
                    status: "Development",
                    members: 4,
                    progress: 60,
                    color: "blue-fill"
                },
                {
                    name: "Team Iota",
                    status: "Planned",
                    members: 5,
                    progress: 20,
                    color: "purple-fill"
                }
            ]
        },

        batch4: {
            trainees: 100,
            projects: 20,
            faculty: 7,

            nearDeadline: 1,
            waitingResources: 0,
            overdueProjects: 0,
            developmentProjects: 2,
            testingProjects: 2,
            documentationPending: 1,

            projectOverview: {
                completed: 80,
                progress: 15,
                planned: 5
            },

            teams: [
                {
                    name: "Team Kappa",
                    status: "Completed",
                    members: 5,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Lambda",
                    status: "Completed",
                    members: 4,
                    progress: 100,
                    color: "green-fill"
                },
                {
                    name: "Team Mu",
                    status: "Development",
                    members: 5,
                    progress: 85,
                    color: "blue-fill"
                }
            ]
        }
    }
}
};
function updateProjectOverview(data) {

    const radius = 90;
    const circumference = 2 * Math.PI * radius;

    const completedLen =
        (data.completed / 100) * circumference;

    const progressLen =
        (data.progress / 100) * circumference;

    const plannedLen =
        (data.planned / 100) * circumference;

    const completedArc =
        document.getElementById("completedArc");

    const progressArc =
        document.getElementById("progressArc");

    const plannedArc =
        document.getElementById("plannedArc");
      
        // Hide arcs with 0%
completedArc.style.display =
    data.completed > 0 ? "block" : "none";

progressArc.style.display =
    data.progress > 0 ? "block" : "none";

plannedArc.style.display =
    data.planned > 0 ? "block" : "none";

    completedArc.setAttribute(
    "stroke-dasharray",
    `${completedLen} ${circumference}`
);

completedArc.setAttribute(
    "stroke-dashoffset",
    "0"
);

    progressArc.setAttribute(
        "stroke-dasharray",
        `${progressLen} ${circumference}`
    );

    progressArc.setAttribute(
        "stroke-dashoffset",
        `-${completedLen}`
    );

    plannedArc.setAttribute(
        "stroke-dasharray",
        `${plannedLen} ${circumference}`
    );

    plannedArc.setAttribute(
        "stroke-dashoffset",
        `-${completedLen + progressLen}`
    );

    // Update legend values
    document.getElementById("completedPercent").textContent =
        data.completed + "%";

    document.getElementById("progressPercent").textContent =
        data.progress + "%";

    document.getElementById("plannedPercent").textContent =
        data.planned + "%";
}
document.addEventListener("DOMContentLoaded", () => {

    const yearFilter =
        document.getElementById("yearFilter");

    const batchFilter =
        document.getElementById("batchFilter");

    // DEFAULT LOAD

    yearFilter.value = "2026";
    batchFilter.value = "all";
batchFilter.disabled = false;

const defaultBatch =
    dashboardData["2026"];

updateDashboard(defaultBatch);

loadBatchOverview();

    // YEAR CHANGE

    yearFilter.addEventListener("change", function () {

        if (this.value === "all") {

            batchFilter.disabled = true;
            batchFilter.value = "all";

            document.getElementById("overviewTitle")
                .textContent = "Batch Overview";

            loadBatchOverview();

            return;
        }

        batchFilter.disabled = false;
        batchFilter.value = "all";

        updateDashboard(
            dashboardData[this.value]
        );

        loadBatchOverview();

    });

    // BATCH CHANGE

    batchFilter.addEventListener("change", function () {

        const selectedYear =
            yearFilter.value;

        if (
            selectedYear === "all"
        ) {
            return;
        }

        if (
            this.value === "all"
        ) {

            updateDashboard(
                dashboardData[selectedYear]
            );

            loadBatchOverview();

            return;
        }

        const data =
            dashboardData[selectedYear]
            .batches[this.value];

        updateDashboard(data);

        loadTeamOverview(this.value);

    });

});
function updateDashboard(data){

    document.getElementById("totalTrainees").textContent =
        data.trainees;

    document.getElementById("technicalFaculty").textContent =
        data.faculty;

    document.getElementById("activeProjects").textContent =
        data.projects;

    document.getElementById("projectTotalText").textContent =
        data.projects;

    document.getElementById("nearDeadline").textContent =
        data.nearDeadline ?? 0;

    document.getElementById("waitingResources").textContent =
        data.waitingResources ?? 0;

    document.getElementById("overdueProjects").textContent =
        data.overdueProjects ?? 0;

    document.getElementById("developmentProjects").textContent =
        data.developmentProjects ?? 0;

    document.getElementById("testingProjects").textContent =
        data.testingProjects ?? 0;

    document.getElementById("documentationPending").textContent =
        data.documentationPending ?? 0;

    if(data.projectOverview){
        updateProjectOverview(
            data.projectOverview
        );
    }
}

function loadTeamOverview(batch){

    const selectedYear =
        document.getElementById("yearFilter").value;

    const teams =
        dashboardData[selectedYear]
        .batches[batch]
        .teams;

    document.getElementById("overviewTitle")
        .textContent =
        `Team Overview (${batch.toUpperCase()})`;

    document.getElementById("overviewGrid").innerHTML =
        teams.map(team => `
        <div class="batch-card">

            <h4>${team.name}</h4>

            <span class="status">
                ${team.status}
            </span>

            <p>${team.members} Members</p>

            <div class="progress">
                <div class="progress-fill ${team.color}"
                     style="width:${team.progress}%">
                </div>
            </div>

            <strong>${team.progress}%</strong>

        </div>
        `).join('');
}

function loadBatchOverview() {

    document.getElementById("overviewTitle")
        .textContent = "Batch Overview";

    document.getElementById("overviewGrid").innerHTML = `

    <div class="batch-card">
        <h4>Batch-01</h4>

        <span class="status completed">
            Completed
        </span>

        <p>28 Teams</p>

        <div class="progress">
            <div class="progress-fill green-fill"
                 style="width:100%">
            </div>
        </div>

        <strong>100%</strong>
    </div>

    <div class="batch-card">
        <h4>Batch-02</h4>

        <span class="status progress-status">
            In Progress
        </span>

        <p>36 Teams</p>

        <div class="progress">
            <div class="progress-fill blue-fill"
                 style="width:75%">
            </div>
        </div>

        <strong>75%</strong>
    </div>

    <div class="batch-card">
        <h4>Batch-03</h4>

        <span class="status review">
            In Progress
        </span>

        <p>32 Teams</p>

        <div class="progress">
            <div class="progress-fill orange-fill"
                 style="width:60%">
            </div>
        </div>

        <strong>60%</strong>
    </div>

    <div class="batch-card">
        <h4>Batch-04</h4>

        <span class="status planned">
            Planned
        </span>

        <p>22 Teams</p>

        <div class="progress">
            <div class="progress-fill purple-fill"
                 style="width:5%">
            </div>
        </div>

        <strong>0%</strong>
    </div>
    `;
}