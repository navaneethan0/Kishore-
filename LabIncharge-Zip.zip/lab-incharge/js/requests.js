// Material Requests Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Requests Table
    const requestsBody = document.getElementById('requests-body');
    requestsBody.innerHTML = '';
    
    data.requests.forEach(req => {
        const row = document.createElement('tr');
        row.dataset.id = req.id;
        
        let statusClass = '';
        switch(req.status) {
            case 'Pending': statusClass = 'pending'; break;
            case 'Approved': statusClass = 'approved'; break;
            case 'Partially Issued': statusClass = 'partial'; break;
            case 'Pending Allocation': statusClass = 'allocation'; break;
            case 'Rejected': statusClass = 'rejected'; break;
        }

        row.innerHTML = `
            <td style="color: #6c5ce7; font-weight: 600;">${req.id}</td>
            <td style="font-weight: 500;">${req.teamId}</td>
            <td>${req.component}</td>
            <td style="text-align: center;">${req.requestedQty}</td>
            <td style="text-align: center;">${req.available}</td>
            <td><span class="status-badge ${statusClass}">${req.status}</span></td>
            <td>${req.date}</td>
            <td>
                <button class="view-btn sm-action"><i class="far fa-eye"></i> View</button>
            </td>
        `;
        
        row.querySelector('.view-btn').addEventListener('click', () => {
            updateDetailsPanel(req);
        });

        requestsBody.appendChild(row);
    });

    function updateDetailsPanel(req) {
        document.getElementById('panel-req-id').textContent = req.id;
        document.getElementById('panel-team-id').textContent = `${req.teamId} - Team ${req.teamId.split('-')[1]}`;
        document.getElementById('panel-comp-name').textContent = req.component;
        document.getElementById('panel-req-qty').textContent = `${req.requestedQty} units`;
        document.getElementById('panel-avail').textContent = `${req.available} units`;
        
        const issueInput = document.getElementById('issue-qty');
        issueInput.value = Math.min(req.requestedQty, req.available);
        issueInput.max = req.available;
        
        // Highlight active row
        document.querySelectorAll('#requests-body tr').forEach(r => r.classList.remove('active-row'));
        const activeRow = [...document.querySelectorAll('#requests-body tr')].find(r => r.dataset.id === req.id);
        if (activeRow) activeRow.classList.add('active-row');
    }
});
