// Team Management Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Team Selector
    const teamSelector = document.getElementById('team-selector');
    teamSelector.innerHTML = '';
    data.teams.forEach(team => {
        const option = document.createElement('option');
        option.value = team.id;
        option.textContent = `${team.id} - ${team.name}`;
        teamSelector.appendChild(option);
    });

    // Function to render team usage
    const renderTeamUsage = (teamId) => {
        const usage = data.teamUsage[teamId] || { components: [], machines: [] };
        
        // Render Components
        const componentsBody = document.getElementById('components-body');
        componentsBody.innerHTML = '';
        usage.components.forEach(comp => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td style="color: #6c5ce7; font-weight: 600;">${comp.code}</td>
                <td style="font-weight: 500;">${comp.name}</td>
                <td>${comp.category}</td>
                <td>${comp.issuedDate}</td>
                <td><span class="status-badge issued">${comp.status}</span></td>
                <td>${comp.condition}</td>
                <td>${comp.expectedReturn}</td>
                <td>
                    <button class="view-btn"><i class="far fa-eye"></i> View</button>
                </td>
            `;
            componentsBody.appendChild(row);
        });
        document.getElementById('component-count').textContent = `${usage.components.length} Items`;

        // Render Machines
        const machinesBody = document.getElementById('machines-body');
        machinesBody.innerHTML = '';
        usage.machines.forEach(mch => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td style="color: #6c5ce7; font-weight: 600;">${mch.code}</td>
                <td style="font-weight: 500;">${mch.name}</td>
                <td>${mch.category}</td>
                <td>${mch.bookingDate}</td>
                <td><span class="status-badge in-use">${mch.status}</span></td>
                <td>${mch.usageType}</td>
                <td>${mch.expectedReturn}</td>
                <td>
                    <button class="view-btn"><i class="far fa-eye"></i> View</button>
                </td>
            `;
            machinesBody.appendChild(row);
        });
        document.getElementById('machine-count').textContent = `${usage.machines.length} Items`;
    };

    // Initial Render
    renderTeamUsage(teamSelector.value);

    // Event Listener for Team Selection
    teamSelector.addEventListener('change', (e) => {
        renderTeamUsage(e.target.value);
    });
});
