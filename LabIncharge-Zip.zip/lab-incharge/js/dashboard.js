// Dashboard Logic

document.addEventListener('DOMContentLoaded', () => {
    // Load Data
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('welcome-name').textContent = data.user.name.split(' ')[1];
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Update Stats
    document.getElementById('stat-teams').textContent = data.stats.totalTeams;
    document.getElementById('stat-components').textContent = data.stats.componentsIssued;
    document.getElementById('stat-machines').textContent = data.stats.machinesBooked;
    document.getElementById('stat-pending').textContent = data.stats.pendingRequests;
    
    // Populate Recent Activities
    const activityContainer = document.getElementById('recent-activities');
    data.recentActivities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        
        const iconClass = activity.type === 'request' ? 'fa-file-import' : 
                         activity.type === 'return' ? 'fa-undo' : 'fa-ticket-alt';
        
        item.innerHTML = `
            <div class="activity-icon ${activity.type}">
                <i class="fas ${iconClass}"></i>
            </div>
            <div class="activity-detail">
                <p>${activity.user} <span>${activity.type === 'request' ? 'requested' : 'returned'}</span> ${activity.item}</p>
                <span>${activity.time}</span>
            </div>
        `;
        activityContainer.appendChild(item);
    });
    
    // Populate Upcoming Returns
    const returnsTable = document.getElementById('upcoming-returns');
    data.upcomingReturns.forEach(ret => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${ret.teamId}</strong></td>
            <td>${ret.item}</td>
            <td><span style="color: #6c5ce7; font-weight: 500;">${ret.date}</span></td>
        `;
        returnsTable.appendChild(row);
    });
    
    // Populate Inventory Summary
    const inventoryContainer = document.getElementById('inventory-summary');
    data.inventorySummary.forEach(item => {
        const div = document.createElement('div');
        div.className = 'status-item';
        const badgeClass = item.status.toLowerCase().includes('low') ? 'low' : 'good';
        
        div.innerHTML = `
            <span class="status-label">${item.category}</span>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span class="status-value">${item.count}</span>
                <span class="status-badge ${badgeClass}">${item.status}</span>
            </div>
        `;
        inventoryContainer.appendChild(div);
    });

    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Sidebar active state toggle (already set in HTML but good practice)
    const currentPath = window.location.pathname.split('/').pop();
    document.querySelectorAll('.menu-link').forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        } else {
            // link.classList.remove('active'); // Keep HTML state if JS fails
        }
    });
});
