// Equipment Tracking Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Equipment Table
    const equipmentBody = document.getElementById('equipment-body');
    equipmentBody.innerHTML = '';
    
    data.equipment.forEach(item => {
        const row = document.createElement('tr');
        row.dataset.id = item.id;
        
        let statusClass = '';
        switch(item.status) {
            case 'In Use': statusClass = 'in-use'; break;
            case 'Available': statusClass = 'available'; break;
            case 'Under Maintenance': statusClass = 'maintenance'; break;
            case 'Out of Service': statusClass = 'out-service'; break;
        }

        row.innerHTML = `
            <td style="color: #6c5ce7; font-weight: 600;">${item.id}</td>
            <td style="font-weight: 500;">${item.name}</td>
            <td>${item.category}</td>
            <td>${item.location}</td>
            <td><span class="status-badge ${statusClass}">${item.status}</span></td>
            <td>${item.user}</td>
            <td>${item.till}</td>
            <td>
                <button class="view-btn sm-action"><i class="far fa-eye"></i> View</button>
            </td>
        `;
        
        row.querySelector('.view-btn').addEventListener('click', () => {
            updateDetailsPanel(item);
        });

        equipmentBody.appendChild(row);
    });

    function updateDetailsPanel(item) {
        document.getElementById('panel-eq-id').textContent = item.id;
        document.getElementById('panel-eq-name').textContent = item.name;
        document.getElementById('p-id').textContent = item.id;
        document.getElementById('p-cat').textContent = item.category;
        document.getElementById('p-loc').textContent = item.location;
        
        const statusPill = document.getElementById('panel-eq-status');
        statusPill.textContent = item.status;
        statusPill.className = `status-pill ${item.status.toLowerCase().replace(' ', '-')}`;
        
        // Update user info
        if (item.status === 'In Use') {
            document.getElementById('p-team').textContent = item.user.split('(')[0].trim();
            document.getElementById('p-member').textContent = item.user.match(/\(([^)]+)\)/)[1];
            document.getElementById('p-book-till').textContent = item.till;
        } else {
            document.getElementById('p-team').textContent = '-';
            document.getElementById('p-member').textContent = '-';
            document.getElementById('p-book-till').textContent = '-';
        }

        // Highlight active row
        document.querySelectorAll('#equipment-body tr').forEach(r => r.classList.remove('active-row'));
        const activeRow = [...document.querySelectorAll('#equipment-body tr')].find(r => r.dataset.id === item.id);
        if (activeRow) activeRow.classList.add('active-row');
    }
});
