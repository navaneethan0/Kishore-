// Inventory Management Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Inventory Table
    const inventoryBody = document.getElementById('inventory-body');
    inventoryBody.innerHTML = '';
    
    data.inventory.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td style="color: #6c5ce7; font-weight: 600;">${item.code}</td>
            <td style="font-weight: 500;">${item.name}</td>
            <td>${item.category}</td>
            <td>${item.lab}</td>
            <td>${item.cabinet}</td>
            <td>${item.rack}</td>
            <td>${item.bin}</td>
            <td class="stock-count available-text">${item.available}</td>
            <td class="stock-count reserved-text">${item.reserved}</td>
            <td class="stock-count pending-text">${item.pending}</td>
            <td class="stock-count low-text">${item.lowStock}</td>
            <td><span class="status-badge issued">${item.status}</span></td>
            <td>
                <div class="action-group">
                    <button class="icon-btn" title="View Details"><i class="far fa-eye"></i></button>
                    <button class="icon-btn" title="Update Stock"><i class="far fa-edit"></i></button>
                    <button class="icon-btn delete" title="Delete Item"><i class="far fa-trash-alt"></i></button>
                </div>
            </td>
        `;
        inventoryBody.appendChild(row);
    });
});
