// Profile Management Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update Sidebar User Info
    document.getElementById('sidebar-name').textContent = data.user.name;
    document.getElementById('sidebar-avatar').src = data.user.avatar;
    
    // Update Profile Page Info
    document.getElementById('profile-avatar-large').src = data.user.avatar;
    document.getElementById('profile-name-title').textContent = data.user.name;
    document.getElementById('profile-role-title').textContent = data.user.role;
    document.getElementById('p-email-text').textContent = data.user.email;
    document.getElementById('p-dept-text').textContent = data.user.department;

    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Form submission simulation
    const saveBtn = document.querySelector('.btn-primary');
    saveBtn.addEventListener('click', () => {
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        setTimeout(() => {
            saveBtn.innerHTML = '<i class="fas fa-check"></i> Changes Saved!';
            saveBtn.style.background = '#10b981';
            
            setTimeout(() => {
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
                saveBtn.style.background = '';
            }, 2000);
        }, 1000);
    });
});
