// Tickets Management Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Tickets Table
    const ticketsBody = document.getElementById('tickets-body');
    ticketsBody.innerHTML = '';
    
    data.tickets.forEach(ticket => {
        const row = document.createElement('tr');
        row.dataset.id = ticket.id;
        
        let statusClass = ticket.status === 'Open' ? 'red' : ticket.status === 'In Progress' ? 'blue' : 'green';
        let prioClass = ticket.priority.toLowerCase();

        row.innerHTML = `
            <td style="color: #6c5ce7; font-weight: 600;">${ticket.id}</td>
            <td style="font-weight: 500;">${ticket.team}</td>
            <td>${ticket.title}</td>
            <td>${ticket.category}</td>
            <td><span class="prio-tag ${prioClass}">${ticket.priority}</span></td>
            <td><span class="status-badge ${statusClass}">${ticket.status}</span></td>
            <td>
                <button class="view-btn sm-action"><i class="far fa-eye"></i> View</button>
            </td>
        `;
        
        row.querySelector('.view-btn').addEventListener('click', () => {
            updateDetailsPanel(ticket);
        });

        ticketsBody.appendChild(row);
    });

    function updateDetailsPanel(ticket) {
        document.getElementById('p-ticket-id').textContent = ticket.id;
        document.getElementById('p-ticket-title').textContent = ticket.title;
        document.getElementById('p-team').textContent = ticket.team;
        document.getElementById('p-cat').textContent = ticket.category;
        document.getElementById('p-date').textContent = ticket.date + ', 09:15 AM';
        
        const prioTag = document.getElementById('p-prio');
        prioTag.textContent = ticket.priority;
        prioTag.className = `prio-tag ${ticket.priority.toLowerCase()}`;
        
        const statusBadge = document.getElementById('p-status');
        statusBadge.textContent = ticket.status;
        statusBadge.className = `status-badge ${ticket.status === 'Open' ? 'red' : ticket.status === 'In Progress' ? 'blue' : 'green'}`;

        // Highlight active row
        document.querySelectorAll('#tickets-body tr').forEach(r => r.classList.remove('active-row'));
        const activeRow = [...document.querySelectorAll('#tickets-body tr')].find(r => r.dataset.id === ticket.id);
        if (activeRow) activeRow.classList.add('active-row');
    }
});
