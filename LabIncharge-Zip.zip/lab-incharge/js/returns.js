// Material Returns Logic

document.addEventListener('DOMContentLoaded', () => {
    const data = getData();
    
    // Update User Info
    document.getElementById('user-name').textContent = data.user.name;
    document.getElementById('user-avatar').src = data.user.avatar;
    
    // Set current date
    const dateOptions = { day: '2-digit', month: 'short', year: 'numeric' };
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-GB', dateOptions);

    // Populate Returns Table
    const returnsBody = document.getElementById('returns-body');
    returnsBody.innerHTML = '';
    
    data.returns.forEach(ret => {
        const row = document.createElement('tr');
        row.dataset.id = ret.id;
        
        let statusClass = '';
        switch(ret.status) {
            case 'Pending': statusClass = 'pending'; break;
            case 'Returned': statusClass = 'returned'; break;
            case 'Partially Returned': statusClass = 'partially'; break;
            case 'Overdue': statusClass = 'overdue'; break;
        }

        row.innerHTML = `
            <td style="color: #6c5ce7; font-weight: 600;">${ret.id}</td>
            <td style="font-weight: 500;">${ret.teamId}</td>
            <td>${ret.type}</td>
            <td style="text-align: center;">${ret.items}</td>
            <td>${ret.requestedOn}</td>
            <td>${ret.dueDate}</td>
            <td><span class="status-badge ${statusClass}">${ret.status}</span></td>
            <td>
                <button class="view-btn sm-action"><i class="far fa-eye"></i> View</button>
            </td>
        `;
        
        row.querySelector('.view-btn').addEventListener('click', () => {
            updateDetailsPanel(ret);
        });

        returnsBody.appendChild(row);
    });

    function updateDetailsPanel(ret) {
        document.getElementById('panel-ret-id').textContent = ret.id;
        document.getElementById('p-team-id').textContent = ret.teamId;
        document.getElementById('p-req-on').textContent = ret.requestedOn;
        document.getElementById('p-due').textContent = ret.dueDate;
        document.getElementById('p-type').textContent = ret.type;
        
        const statusBadge = document.getElementById('p-status');
        statusBadge.textContent = ret.status;
        statusBadge.className = `status-badge ${ret.status.toLowerCase().split(' ')[0]}`;

        // Highlight active row
        document.querySelectorAll('#returns-body tr').forEach(r => r.classList.remove('active-row'));
        const activeRow = [...document.querySelectorAll('#returns-body tr')].find(r => r.dataset.id === ret.id);
        if (activeRow) activeRow.classList.add('active-row');
    }
});
