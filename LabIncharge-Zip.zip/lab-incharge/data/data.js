// RPLMS Lab Incharge Module - Dummy Data

const RPLMS_DATA = {
    user: {
        name: "Dr. Priya Sharma",
        role: "Lab Incharge",
        department: "Advanced Engineering Lab",
        email: "priya.sharma@rplms.edu",
        avatar: "https://ui-avatars.com/api/?name=Priya+Sharma&background=6c5ce7&color=fff"
    },
    stats: {
        totalTeams: 24,
        componentsIssued: 156,
        machinesBooked: 8,
        pendingRequests: 12,
        activeTickets: 5,
        materialReturns: 7
    },
    recentActivities: [
        { id: 1, type: 'request', user: 'Rahul Verma', item: 'Arduino Uno', time: '10 mins ago', status: 'pending' },
        { id: 2, type: 'return', user: 'Sneha Kapur', item: '3D Printer-01', time: '45 mins ago', status: 'completed' },
        { id: 3, type: 'ticket', user: 'Admin', item: 'System Update', time: '2 hours ago', status: 'resolved' },
        { id: 4, type: 'issue', user: 'Amit Raj', item: 'Soldering Iron', time: 'Yesterday', status: 'issued' }
    ],
    upcomingReturns: [
        { id: 1, team: 'Team Alpha', item: 'Raspberry Pi 4', date: '04 July 2025', teamId: 'T-001' },
        { id: 2, team: 'Project Delta', item: 'Laser Cutter', date: '05 July 2025', teamId: 'T-012' },
        { id: 3, team: 'Robotics Club', item: 'LiPo Batteries', date: '06 July 2025', teamId: 'T-005' }
    ],
    inventorySummary: [
        { category: 'Microcontrollers', count: 45, status: 'Good' },
        { category: 'Sensors', count: 120, status: 'Low Stock' },
        { category: '3D Printing', count: 12, status: 'Good' },
        { category: 'Hand Tools', count: 85, status: 'Good' }
    ],
    teams: [
        { id: 'TEAM-001', name: 'Smart Irrigation System', lead: 'Aman Verma' },
        { id: 'TEAM-002', name: 'AI Surveillance Drone', lead: 'Sneha Kapur' },
        { id: 'TEAM-003', name: 'Automated Sorting Arm', lead: 'Rahul Mehta' }
    ],
    teamUsage: {
        'TEAM-001': {
            components: [
                { code: 'CMP-0001', name: 'Arduino Uno R3', category: 'Microcontroller', issuedDate: '18 Jun 2025', status: 'Issued', condition: 'Good', expectedReturn: '18 Aug 2025' },
                { code: 'CMP-0005', name: 'Soil Moisture Sensor', category: 'Sensors', issuedDate: '18 Jun 2025', status: 'Issued', condition: 'Good', expectedReturn: '18 Aug 2025' },
                { code: 'CMP-0012', name: '16x2 LCD Display', category: 'Displays', issuedDate: '18 Jun 2025', status: 'Issued', condition: 'Good', expectedReturn: '18 Aug 2025' },
                { code: 'CMP-0023', name: 'Water Pump (5V)', category: 'Actuators', issuedDate: '18 Jun 2025', status: 'Issued', condition: 'Good', expectedReturn: '18 Aug 2025' }
            ],
            machines: [
                { code: 'MCH-0003', name: '3D Printer - Creality Ender 3', category: '3D Printer', bookingDate: '20 Jun 2025', status: 'In Use', usageType: 'Project Work', expectedReturn: '27 Jul 2025' },
                { code: 'MCH-0007', name: 'Laser Cutter - 40W', category: 'Laser Cutter', bookingDate: '22 Jun 2025', status: 'In Use', usageType: 'Project Work', expectedReturn: '29 Jul 2025' }
            ]
        }
    },
    inventory: [
        { code: 'CMP-0001', name: 'Arduino Uno R3', category: 'Microcontroller', lab: 'RPL Lab', cabinet: 'Cabinet A', rack: 'R3 / S2', bin: 'B05', available: 103, reserved: 10, pending: 07, lowStock: 15, status: 'In Stock' },
        { code: 'CMP-0002', name: 'ESP32 Dev Board', category: 'Microcontroller', lab: 'RPL Lab', cabinet: 'Cabinet A', rack: 'R2 / S1', bin: 'B02', available: 80, reserved: 06, pending: 04, lowStock: 10, status: 'In Stock' },
        { code: 'CMP-0003', name: 'IR Sensor', category: 'Sensors', lab: 'RPL Lab', cabinet: 'Cabinet B', rack: 'R1 / S3', bin: 'B01', available: 42, reserved: 05, pending: 03, lowStock: 08, status: 'In Stock' },
        { code: 'CMP-0004', name: 'Servo Motor SG90', category: 'Actuators', lab: 'RPL Lab', cabinet: 'Cabinet B', rack: 'R1 / S2', bin: 'B03', available: 46, reserved: 05, pending: 06, lowStock: 10, status: 'In Stock' },
        { code: 'CMP-0005', name: 'LCD 16x2 Display', category: 'Displays', lab: 'RPL Lab', cabinet: 'Cabinet C', rack: 'R2 / S3', bin: 'B04', available: 34, reserved: 04, pending: 02, lowStock: 06, status: 'In Stock' },
        { code: 'CMP-0006', name: 'Jumper Wires (M-M)', category: 'Accessories', lab: 'RPL Lab', cabinet: 'Cabinet C', rack: 'R3 / S1', bin: 'B01', available: 450, reserved: 20, pending: 30, lowStock: 50, status: 'In Stock' }
    ],
    requests: [
        { id: 'MR-2025-0078', teamId: 'T-011', component: 'Arduino Uno R3', requestedQty: 19, available: 10, status: 'Pending', date: '02 Jul 2025' },
        { id: 'MR-2025-0077', teamId: 'T-004', component: '16x2 LCD Display', requestedQty: 5, available: 5, status: 'Pending', date: '02 Jul 2025' },
        { id: 'MR-2025-0076', teamId: 'T-002', component: 'Soil Moisture Sensor', requestedQty: 8, available: 0, status: 'Pending', date: '01 Jul 2025' },
        { id: 'MR-2025-0075', teamId: 'T-009', component: 'L298N Motor Driver', requestedQty: 3, available: 3, status: 'Approved', date: '01 Jul 2025' },
        { id: 'MR-2025-0074', teamId: 'T-003', component: 'Water Pump (5V)', requestedQty: 2, available: 1, status: 'Partially Issued', date: '30 Jun 2025' },
        { id: 'MR-2025-0073', teamId: 'T-011', component: 'HC-SR04 Sensor', requestedQty: 10, available: 0, status: 'Pending Allocation', date: '30 Jun 2025' },
        { id: 'MR-2025-0072', teamId: 'T-007', component: 'IR Sensor Module', requestedQty: 6, available: 6, status: 'Approved', date: '30 Jun 2025' },
        { id: 'MR-2025-0071', teamId: 'T-006', component: 'Relay Module (5V)', requestedQty: 4, available: 0, status: 'Rejected', date: '29 Jun 2025' }
    ],
    returns: [
        { id: 'RET-2025-0081', teamId: 'T-011', type: 'Components', items: 5, requestedOn: '02 Jul 2025', dueDate: '16 Jul 2025', status: 'Pending' },
        { id: 'RET-2025-0080', teamId: 'T-002', type: 'Machines', items: 1, requestedOn: '01 Jul 2025', dueDate: '10 Jul 2025', status: 'Overdue' },
        { id: 'RET-2025-0079', teamId: 'T-004', type: 'Components', items: 3, requestedOn: '30 Jun 2025', dueDate: '12 Jul 2025', status: 'Pending' },
        { id: 'RET-2025-0078', teamId: 'T-007', type: 'Machines', items: 1, requestedOn: '29 Jun 2025', dueDate: '09 Jul 2025', status: 'Partially Returned' },
        { id: 'RET-2025-0077', teamId: 'T-009', type: 'Components', items: 4, requestedOn: '28 Jun 2025', dueDate: '08 Jul 2025', status: 'Returned' },
        { id: 'RET-2025-0076', teamId: 'T-003', type: 'Components', items: 2, requestedOn: '27 Jun 2025', dueDate: '07 Jul 2025', status: 'Returned' },
        { id: 'RET-2025-0075', teamId: 'T-006', type: 'Machines', items: 2, requestedOn: '27 Jun 2025', dueDate: '07 Jul 2025', status: 'Pending' },
        { id: 'RET-2025-0074', teamId: 'T-001', type: 'Components', items: 6, requestedOn: '26 Jun 2025', dueDate: '06 Jul 2025', status: 'Partially Returned' }
    ],
    equipment: [
        { id: 'EQP-0001', name: '3D Printer - Creality Ender 3', category: '3D Printer', location: 'Lab 1', status: 'In Use', user: 'TEAM-001 (Aman Verma)', till: '02 Jul 2025 05:00 PM' },
        { id: 'EQP-0002', name: 'Laser Cutter - 40W', category: 'Laser Cutter', location: 'Lab 1', status: 'In Use', user: 'TEAM-004 (Rohit Patel)', till: '02 Jul 2025 06:00 PM' },
        { id: 'EQP-0003', name: 'Oscilloscope - DSOX1204G', category: 'Test Equipment', location: 'Lab 2', status: 'Available', user: '-', till: '-' },
        { id: 'EQP-0004', name: 'Function Generator - FG1000', category: 'Test Equipment', location: 'Lab 2', status: 'Available', user: '-', till: '-' },
        { id: 'EQP-0005', name: 'Soldering Station - Hakko FX-951', category: 'Soldering', location: 'Lab 3', status: 'In Use', user: 'TEAM-002 (Neha Singh)', till: '02 Jul 2025 04:30 PM' },
        { id: 'EQP-0006', name: 'Digital Multimeter - Fluke 15B+', category: 'Measuring', location: 'Lab 3', status: 'Available', user: '-', till: '-' },
        { id: 'EQP-0007', name: 'CNC Router - Mini', category: 'CNC Machine', location: 'Fabrication Lab', status: 'Under Maintenance', user: '-', till: '05 Jul 2025' },
        { id: 'EQP-0008', name: 'Hot Air Rework Station', category: 'Soldering', location: 'Lab 2', status: 'Out of Service', user: '-', till: '-' }
    ],
    tickets: [
        { id: 'TIC-0042', team: 'Team-001', title: '3D Printer Nozzle Clogged', category: 'Equipment', priority: 'High', status: 'Open', date: '02 Jul 2025' },
        { id: 'TIC-0041', team: 'Team-004', title: 'Need extra Jumper Wires', category: 'Inventory', priority: 'Medium', status: 'In Progress', date: '02 Jul 2025' },
        { id: 'TIC-0040', team: 'Team-007', title: 'Workstation Login Error', category: 'Software', priority: 'High', status: 'In Progress', date: '01 Jul 2025' },
        { id: 'TIC-0039', team: 'Team-012', title: 'Material return delay', category: 'Procedural', priority: 'Low', status: 'Resolved', date: '01 Jul 2025' },
        { id: 'TIC-0038', team: 'Team-002', title: 'Oscilloscope calibration', category: 'Equipment', priority: 'Medium', status: 'Open', date: '30 Jun 2025' }
    ]
};

// Initialize LocalStorage if not already set
if (!localStorage.getItem('rplms_data')) {
    localStorage.setItem('rplms_data', JSON.stringify(RPLMS_DATA));
}

// Helper to get data
function getData() {
    return JSON.parse(localStorage.getItem('rplms_data'));
}

// Helper to update data
function updateData(newData) {
    localStorage.setItem('rplms_data', JSON.stringify(newData));
}
