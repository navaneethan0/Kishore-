
import os

faculty_deleted = r"""                <div class="header-right">
                    <button class="icon-btn" id="notificationBtn" aria-label="Notifications"><i
                            data-lucide="bell"></i></button>
                    <button class="user-profile-btn" id="profileBtn">
                        <div class="user-info">
                            <span class="user-name" id="headerUserName">Senior Faculty Name</span>
                            <span class="user-role" id="headerUserRole">Senior Faculty</span>
                        </div>
                        <div class="user-avatar" id="headerAvatar"><i data-lucide="user"></i></div>
                    </button>
                </div>
            </header>

            <section class="page-content">
                <!-- Summary Cards -->
                <div class="summary-cards-row">
                    <div class="summary-card">
                        <div class="summary-card-icon total"><i data-lucide="users"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="totalFaculty">0</span>
                            <span class="summary-card-label">Total Faculty</span>
                            <span class="summary-card-desc">Total registered faculty</span>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-card-icon assigned"><i data-lucide="user-check"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="assignedFaculty">0</span>
                            <span class="summary-card-label">Assigned Faculty</span>
                            <span class="summary-card-desc">Currently assigned to teams</span>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-card-icon unassigned"><i data-lucide="user-x"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="unassignedFaculty">0</span>
                            <span class="summary-card-label">Unassigned Faculty</span>
                            <span class="summary-card-desc">Available for assignment</span>
                        </div>
                    </div>
                </div>

                <!-- Controls: Search and Filter -->
                <div class="controls-card table-card card">
                    <div class="filters-row">
                        <div class="search-wrapper">
                            <i data-lucide="search" class="search-icon"></i>
                            <input type="text" id="facultySearch" class="search-input"
                                placeholder="Search by Faculty ID or Name...">
                        </div>

                        <div class="filter-wrapper">
                            <label for="statusFilter" class="filter-label">Status</label>
                            <div class="custom-select-wrapper">
                                <select id="statusFilter" class="custom-select">
                                    <option value="All">All</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <i data-lucide="chevron-down" class="select-icon"></i>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="data-table" id="facultyTable">
                            <thead>
                                <tr>
                                    <th>SI No</th>
                                    <th>Faculty ID</th>
                                    <th>Full Name</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th class="actions-col">Action</th>
                                </tr>
                            </thead>
                            <tbody id="facultyTableBody">
                                <!-- JS inserts here -->
                            </tbody>
                        </table>

                        <div id="emptyState" class="empty-state hidden">
                            <div class="empty-icon"><i data-lucide="search-x"></i></div>
                            <h4>No faculty members found</h4>
                            <p>Try adjusting your search or filters.</p>
                        </div>
                    </div>

                    <div class="pagination">
                        <span class="page-info" id="pageInfo">Page 1 of 1</span>
                        <div class="page-buttons">
                            <button class="page-btn" id="prevPageBtn" disabled><i
                                    data-lucide="chevron-left"></i></button>
                            <button class="page-btn" id="nextPageBtn" disabled><i
                                    data-lucide="chevron-right"></i></button>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- View / Edit Modal -->
    <div class="modal-overlay" id="facultyModal">
        <div class="modal modal-lg">
            <div class="modal-header">
                <h2 id="modalTitle">Faculty Details</h2>
                <button class="modal-close" id="closeFacultyModalBtn"><i data-lucide="x"></i></button>
            </div>

            <!-- View Mode (trimmed fields) -->
            <div class="modal-body" id="viewFacultyMode">
                <div class="details-grid">
                    <div class="detail-item">
                        <span class="detail-label">Faculty ID</span>
                        <span class="detail-value" id="viewId"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Full Name</span>
                        <span class="detail-value" id="viewName"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Email</span>
                        <span class="detail-value" id="viewEmail"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Mobile Number</span>
                        <span class="detail-value" id="viewPhone"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Gender</span>
                        <span class="detail-value" id="viewGender"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Date of Birth</span>
                        <span class="detail-value" id="viewDob"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Role</span>
                        <span class="detail-value" id="viewRole"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Status</span>
                        <span class="detail-value" id="viewStatus"></span>
                    </div>
                </div>
            </div>

            <!-- Edit Mode (trimmed fields) -->
            <div class="modal-body hidden" id="editFacultyMode">
                <form id="editFacultyForm">
                    <div class="form-grid-2">
                        <div class="form-group row-group">
                            <label>Faculty ID</label>
                            <input type="text" id="editId" class="input-readonly" readonly>
                        </div>
                        <div class="form-group row-group">
                            <label>Full Name</label>
                            <input type="text" id="editName" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Email</label>
                            <input type="email" id="editEmail" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Mobile Number</label>
                            <input type="tel" id="editPhone" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Gender</label>
                            <select id="editGender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group row-group">
                            <label>Date of Birth</label>
                            <input type="date" id="editDob" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Role</label>
                            <input type="text" id="editRole" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Status</label>
                            <select id="editStatus" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Actions -->
            <div class="modal-footer" id="viewModalFooter">
                <button class="btn btn-secondary btn-icon" id="editModeBtn"><i data-lucide="edit"></i> Edit</button>
                <button class="btn btn-danger btn-icon" id="deleteBtn"><i data-lucide="trash-2"></i> Delete</button>
            </div>

            <div class="modal-footer hidden" id="editModalFooter">
                <button class="btn btn-secondary btn-icon" id="cancelEditBtn"><i data-lucide="x"></i> Cancel</button>
                <button class="btn btn-primary btn-icon" form="editFacultyForm" id="saveEditBtn"><i
                        data-lucide="save"></i> Save Changes</button>
            </div>
        </div>
    </div>

    <!-- Confirm Delete Modal -->
    <div class="modal-overlay" id="confirmDeleteModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h2>Confirm Deletion</h2>
                <button class="modal-close" id="closeDeleteModalBtn"><i data-lucide="x"></i></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this faculty member? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
                <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
            </div>
        </div>
    </div>
"""

trainee_deleted = r"""                <div class="header-right">
                    <button class="icon-btn" id="notificationBtn" aria-label="Notifications"><i
                            data-lucide="bell"></i></button>
                    <button class="user-profile-btn" id="profileBtn">
                        <div class="user-info">
                            <span class="user-name" id="headerUserName">Senior Faculty Name</span>
                            <span class="user-role" id="headerUserRole">Senior Faculty</span>
                        </div>
                        <div class="user-avatar" id="headerAvatar"><i data-lucide="user"></i></div>
                    </button>
                </div>
            </header>

            <section class="page-content">
                <!-- Summary Cards -->
                <div class="summary-cards-row">
                    <div class="summary-card">
                        <div class="summary-card-icon total"><i data-lucide="users"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="totalTrainees">0</span>
                            <span class="summary-card-label">Total Trainees</span>
                            <span class="summary-card-desc">Total number of trainees</span>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-card-icon assigned"><i data-lucide="user-check"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="assignedTrainees">0</span>
                            <span class="summary-card-label">Assigned Trainees</span>
                            <span class="summary-card-desc">Assigned to a team</span>
                        </div>
                    </div>
                    <div class="summary-card">
                        <div class="summary-card-icon unassigned"><i data-lucide="user-x"></i></div>
                        <div class="summary-card-info">
                            <span class="summary-card-count" id="unassignedTrainees">0</span>
                            <span class="summary-card-label">Unassigned Trainees</span>
                            <span class="summary-card-desc">Not assigned to any team</span>
                        </div>
                    </div>
                </div>

                <!-- Controls: Search and Filter -->
                <div class="controls-card table-card card">
                    <div class="filters-row">
                        <div class="search-wrapper">
                            <i data-lucide="search" class="search-icon"></i>
                            <input type="text" id="traineeSearch" class="search-input"
                                placeholder="Search by Trainee ID or Name...">
                        </div>

                        <div class="filter-wrapper">
                            <label for="statusFilter" class="filter-label">Status</label>
                            <div class="custom-select-wrapper">
                                <select id="statusFilter" class="custom-select">
                                    <option value="All">All</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                <i data-lucide="chevron-down" class="select-icon"></i>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="data-table" id="traineeTable">
                            <thead>
                                <tr>
                                    <th>SI No</th>
                                    <th>Trainee ID</th>
                                    <th>Full Name</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th class="actions-col">Action</th>
                                </tr>
                            </thead>
                            <tbody id="traineeTableBody">
                                <!-- JS inserts here -->
                            </tbody>
                        </table>

                        <div id="emptyState" class="empty-state hidden">
                            <div class="empty-icon"><i data-lucide="search-x"></i></div>
                            <h4>No trainees found</h4>
                            <p>Try adjusting your search or filters.</p>
                        </div>
                    </div>

                    <div class="pagination">
                        <span class="page-info" id="pageInfo">Page 1 of 1</span>
                        <div class="page-buttons">
                            <button class="page-btn" id="prevPageBtn" disabled><i
                                    data-lucide="chevron-left"></i></button>
                            <button class="page-btn" id="nextPageBtn" disabled><i
                                    data-lucide="chevron-right"></i></button>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- View / Edit Modal -->
    <div class="modal-overlay" id="traineeModal">
        <div class="modal modal-lg">
            <div class="modal-header">
                <h2 id="modalTitle">Trainee Details</h2>
                <button class="modal-close" id="closeTraineeModalBtn"><i data-lucide="x"></i></button>
            </div>

            <!-- View Mode (trimmed fields) -->
            <div class="modal-body" id="viewTraineeMode">
                <div class="details-grid">
                    <div class="detail-item">
                        <span class="detail-label">Trainee ID</span>
                        <span class="detail-value" id="viewId"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Full Name</span>
                        <span class="detail-value" id="viewName"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Email</span>
                        <span class="detail-value" id="viewEmail"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Phone Number</span>
                        <span class="detail-value" id="viewPhone"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Gender</span>
                        <span class="detail-value" id="viewGender"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Date of Birth</span>
                        <span class="detail-value" id="viewDob"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Role</span>
                        <span class="detail-value" id="viewRole"></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Status</span>
                        <span class="detail-value" id="viewStatus"></span>
                    </div>
                </div>
            </div>

            <!-- Edit Mode (trimmed fields) -->
            <div class="modal-body hidden" id="editTraineeMode">
                <form id="editTraineeForm">
                    <div class="form-grid-2">
                        <div class="form-group row-group">
                            <label>Trainee ID</label>
                            <input type="text" id="editId" class="input-readonly" readonly>
                        </div>
                        <div class="form-group row-group">
                            <label>Full Name</label>
                            <input type="text" id="editName" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Email</label>
                            <input type="email" id="editEmail" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Phone Number</label>
                            <input type="tel" id="editPhone" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Gender</label>
                            <select id="editGender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group row-group">
                            <label>Date of Birth</label>
                            <input type="date" id="editDob" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Role</label>
                            <input type="text" id="editRole" required>
                        </div>
                        <div class="form-group row-group">
                            <label>Status</label>
                            <select id="editStatus" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Actions -->
            <div class="modal-footer" id="viewModalFooter">
                <button class="btn btn-secondary btn-icon" id="editModeBtn"><i data-lucide="edit"></i> Edit</button>
                <button class="btn btn-danger btn-icon" id="deleteBtn"><i data-lucide="trash-2"></i> Delete</button>
            </div>

            <div class="modal-footer hidden" id="editModalFooter">
                <button class="btn btn-secondary btn-icon" id="cancelEditBtn"><i data-lucide="x"></i> Cancel</button>
                <button class="btn btn-primary btn-icon" form="editTraineeForm" id="saveEditBtn"><i
                        data-lucide="save"></i> Save Changes</button>
            </div>
        </div>
    </div>

    <!-- Confirm Delete Modal -->
    <div class="modal-overlay" id="confirmDeleteModal">
        <div class="modal modal-sm">
            <div class="modal-header">
                <h2>Confirm Deletion</h2>
                <button class="modal-close" id="closeDeleteModalBtn"><i data-lucide="x"></i></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this trainee? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
                <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
            </div>
        </div>
    </div>
"""

with open("pages/faculty.html", "r", encoding="utf-8") as f:
    fc = f.read()
fc = fc.split("""<div class="toast-container" id="toastContainer"></div>""")[0] + faculty_deleted + """
    <div class="toast-container" id="toastContainer"></div>
""" + fc.split("""<div class="toast-container" id="toastContainer"></div>""")[1]
with open("pages/faculty.html", "w", encoding="utf-8") as f:
    f.write(fc)

with open("pages/trainee.html", "r", encoding="utf-8") as f:
    tc = f.read()
tc = tc.split("""<div class="toast-container" id="toastContainer"></div>""")[0] + trainee_deleted + """
    <div class="toast-container" id="toastContainer"></div>
""" + tc.split("""<div class="toast-container" id="toastContainer"></div>""")[1]
with open("pages/trainee.html", "w", encoding="utf-8") as f:
    f.write(tc)

print("Restored!")

