
import os
import glob
for f in glob.glob("js/*.js"):
    with open(f, "r", encoding="utf-8") as file:
        content = file.read()
    
    content = content.replace("Admin Name", "Senior Faculty Name")
    content = content.replace("Administrator", "Senior Faculty")
    
    with open(f, "w", encoding="utf-8") as file:
        file.write(content)

print("Replaced in all JS files")
