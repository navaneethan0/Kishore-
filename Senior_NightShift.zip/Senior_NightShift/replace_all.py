
import os
import glob

files = glob.glob('pages/*.html')
for f in files:
    with open(f, 'r', encoding='utf-8') as file:
        content = file.read()
    
    content = content.replace('ADMIN PORTAL', 'SENIOR FACULTY PORTAL')
    content = content.replace('Admin Portal', 'Senior Faculty Portal')
    content = content.replace('admin portal', 'Senior Faculty Portal')
    content = content.replace('Admin Name', 'Senior Faculty Name')
    content = content.replace('Administrator', 'Senior Faculty')
    
    with open(f, 'w', encoding='utf-8') as file:
        file.write(content)

print('Replaced in all html files')
