Place custom icon files here (emoji icons are used inline by default).
