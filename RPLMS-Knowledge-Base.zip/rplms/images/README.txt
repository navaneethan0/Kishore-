Place project screenshots / thumbnails here.
