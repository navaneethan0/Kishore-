Place static assets (fonts, brand files) here.
