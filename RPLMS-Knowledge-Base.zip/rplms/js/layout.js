/* ==========================================================================
   RPLMS — Shared layout renderer (sidebar + topbar + breadcrumb)
   Each page calls initLayout({ page, title, crumbs }) on load.
   ========================================================================== */

/* Nav items: 'roles' lists which roles see the entry. href is relative to /pages/ */
const NAV_ITEMS = [
  { key: "dashboard",   icon: "🏠", label: "Repository Dashboard", href: "repository-dashboard.html",  roles: ["student","faculty","senior","admin"] },
  { key: "search",      icon: "🔍", label: "Repository Search",    href: "repository-search.html",     roles: ["student","faculty","senior","admin"] },
  { key: "list",        icon: "📚", label: "Repository List",      href: "repository-list.html",       roles: ["student","faculty","senior","admin"] },
  { key: "request",     icon: "📥", label: "Download Request",     href: "download-request.html",      roles: ["student"], section: "Downloads" },
  { key: "history",     icon: "🕒", label: "Download History",     href: "download-history.html",      roles: ["student"] },
  { key: "approval",    icon: "✅", label: "Download Approval",    href: "download-approval.html",     roles: ["faculty"], section: "Approvals" },
  { key: "analytics",   icon: "📊", label: "Repository Analytics", href: "repository-analytics.html",  roles: ["senior","admin"], section: "Insights" },
  { key: "statistics",  icon: "📈", label: "Repository Statistics",href: "repository-statistics.html", roles: ["admin"], section: "Insights" },
  { key: "published",   icon: "📗", label: "Published Projects",   href: "published-projects.html",    roles: ["admin"], section: "Management" },
  { key: "archived",    icon: "🗄️", label: "Archived Projects",    href: "archived-projects.html",     roles: ["admin"], section: "Management" },
  { key: "categories",  icon: "🏷️", label: "Category Management",  href: "category-management.html",   roles: ["admin"], section: "Management" }
];

function renderSidebar(activeKey) {
  const role = getCurrentRole();
  const user = getCurrentUser();
  const items = NAV_ITEMS.filter(i => i.roles.includes(role));

  let lastSection = null;
  const navHtml = items.map(item => {
    let sectionLabel = "";
    if (item.section && item.section !== lastSection) {
      sectionLabel = `<li class="nav-section-label">${item.section}</li>`;
      lastSection = item.section;
    } else if (!item.section) {
      lastSection = null;
    }
    return `${sectionLabel}
      <li class="nav-item">
        <a href="${item.href}" class="${item.key === activeKey ? "active" : ""}">
          <span class="icon">${item.icon}</span><span class="label">${item.label}</span>
        </a>
      </li>`;
  }).join("");

  return `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="logo-mark">🧪</div>
        <div class="brand-text">
          <div class="brand-title">RPLMS</div>
          <div class="brand-sub">Knowledge Base</div>
        </div>
      </div>
      <div class="sidebar-role">${user.portal}</div>
      <ul class="sidebar-nav">${navHtml}</ul>
      <div class="sidebar-footer">
        <a href="../index.html" style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:8px;font-size:14px;font-weight:500;">
          <span class="icon">↩️</span><span class="label">Logout</span>
        </a>
      </div>
    </aside>
    <div class="mobile-overlay" id="mobileOverlay"></div>`;
}

function renderTopbar(title) {
  const role = getCurrentRole();
  const user = getCurrentUser();
  const initials = user.name.split(" ").map(n => n[0]).slice(0, 2).join("");

  return `
    <header class="topbar">
      <button class="menu-toggle" id="menuToggle" aria-label="Toggle sidebar">☰</button>
      <div class="page-title">${title}</div>
      <div class="topbar-search">
        <span class="search-icon">🔍</span>
        <input type="text" id="globalSearch" placeholder="Search repository…" autocomplete="off" />
      </div>
      <div class="topbar-right">
        <div class="role-switcher">
          <select id="roleSelect" aria-label="Switch role">
            <option value="student">Student</option>
            <option value="faculty">Technical Faculty</option>
            <option value="senior">Senior Faculty</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <button class="icon-btn" aria-label="Notifications">🔔<span class="dot">3</span></button>
        <div class="user-chip">
          <div class="user-avatar">${initials}</div>
          <div>
            <div class="user-name">${user.name}</div>
            <div class="user-id">${user.idNo}</div>
          </div>
          <span class="caret">▾</span>
        </div>
      </div>
    </header>`;
}

function renderBreadcrumb(crumbs) {
  const parts = crumbs.map((c, i) => {
    const isLast = i === crumbs.length - 1;
    if (isLast) return `<span class="current">${c.label}</span>`;
    return `<a href="${c.href}">${c.label}</a><span class="sep">›</span>`;
  }).join("");
  return `<nav class="breadcrumb">${parts}</nav>`;
}

/**
 * initLayout({ page, title, crumbs })
 * page   -> nav key to highlight (see NAV_ITEMS)
 * title  -> shown in topbar + page header
 * crumbs -> [{label, href}], last item is current page (href ignored)
 */
function initLayout({ page, title, crumbs }) {
  document.getElementById("sidebarSlot").outerHTML = renderSidebar(page);
  document.getElementById("topbarSlot").outerHTML = renderTopbar(title);
  const bcSlot = document.getElementById("breadcrumbSlot");
  if (bcSlot) bcSlot.outerHTML = renderBreadcrumb(crumbs);

  // Role switcher
  const roleSelect = document.getElementById("roleSelect");
  roleSelect.value = getCurrentRole();
  roleSelect.addEventListener("change", (e) => {
    setCurrentRole(e.target.value);
    showToast("Role switched", `Now viewing as ${ROLES[e.target.value].label}.`, "info");
    setTimeout(() => window.location.href = "repository-dashboard.html", 500);
  });

  // Sidebar mobile toggle
  const menuToggle = document.getElementById("menuToggle");
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("mobileOverlay");
  menuToggle.addEventListener("click", () => {
    if (window.innerWidth <= 900) {
      sidebar.classList.toggle("mobile-open");
      overlay.classList.toggle("open");
    } else {
      sidebar.classList.toggle("collapsed");
      document.body.classList.toggle("sidebar-collapsed");
    }
  });
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("mobile-open");
    overlay.classList.remove("open");
  });

  // Global search -> jump to repository list with query
  const gs = document.getElementById("globalSearch");
  gs.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && gs.value.trim()) {
      window.location.href = `repository-list.html?q=${encodeURIComponent(gs.value.trim())}`;
    }
  });
}
