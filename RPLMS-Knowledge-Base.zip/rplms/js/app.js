/* ==========================================================================
   RPLMS — Core application utilities
   Shared across every page: role state, storage, toasts, modal, helpers.
   ========================================================================== */

/* ---------------------------------------------------------------------
   Role / current user (simulated auth — no backend)
   --------------------------------------------------------------------- */
const ROLES = {
  student:   { label: "Student",           name: "Common Name",  idNo: "22BCS001",  portal: "STUDENT PORTAL" },
  faculty:   { label: "Technical Faculty", name: "Dr. Arvind Deshmukh", idNo: "TF-114", portal: "FACULTY PORTAL" },
  senior:    { label: "Senior Faculty",    name: "Dr. Priya Nair", idNo: "SF-027", portal: "FACULTY PORTAL" },
  admin:     { label: "Admin",             name: "Admin Name",   idNo: "ADMIN001", portal: "ADMIN PORTAL" }
};

function getCurrentRole() {
  return localStorage.getItem("rplms_role") || "student";
}
function setCurrentRole(role) {
  localStorage.setItem("rplms_role", role);
}
function getCurrentUser() {
  return ROLES[getCurrentRole()];
}

/* ---------------------------------------------------------------------
   LocalStorage helpers for demo download requests
   --------------------------------------------------------------------- */
const REQ_KEY = "rplms_download_requests";

function loadRequests() {
  const raw = localStorage.getItem(REQ_KEY);
  if (raw) {
    try { return JSON.parse(raw); } catch (e) { /* fall through to seed */ }
  }
  localStorage.setItem(REQ_KEY, JSON.stringify(SEED_REQUESTS));
  return JSON.parse(JSON.stringify(SEED_REQUESTS));
}
function saveRequests(list) {
  localStorage.setItem(REQ_KEY, JSON.stringify(list));
}
function addRequest(req) {
  const list = loadRequests();
  list.unshift(req);
  saveRequests(list);
  return list;
}
function updateRequest(id, patch) {
  const list = loadRequests();
  const idx = list.findIndex(r => r.id === id);
  if (idx > -1) { list[idx] = { ...list[idx], ...patch }; saveRequests(list); }
  return list;
}
function nextRequestId() {
  const list = loadRequests();
  const max = list.reduce((m, r) => Math.max(m, parseInt(r.id.replace("REQ", ""), 10) || 0), 1000);
  return "REQ" + (max + 1);
}

/* Archived / hidden project id overrides made by admin during this demo session */
const OVERRIDE_KEY = "rplms_status_overrides";
function loadOverrides() {
  const raw = localStorage.getItem(OVERRIDE_KEY);
  return raw ? JSON.parse(raw) : {};
}
function setOverride(projectId, status) {
  const o = loadOverrides();
  o[projectId] = status;
  localStorage.setItem(OVERRIDE_KEY, JSON.stringify(o));
}
function getProjectsWithOverrides() {
  const overrides = loadOverrides();
  return PROJECTS.map(p => overrides[p.id] ? { ...p, status: overrides[p.id] } : p);
}

/* ---------------------------------------------------------------------
   Formatting helpers
   --------------------------------------------------------------------- */
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[s]));
}
function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) +
         ", " + d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
}
function formatDateShort(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
function debounce(fn, wait) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}
function statusBadgeClass(status) {
  switch (status) {
    case "Published": case "Approved": case "Available": case "Active": return "badge-success";
    case "Pending": case "Pending Review": return "badge-warning";
    case "Rejected": case "Expired": return "badge-danger";
    case "Archived": return "badge-neutral";
    case "Hidden": return "badge-info";
    default: return "badge-neutral";
  }
}
function badge(status) {
  return `<span class="badge ${statusBadgeClass(status)}"><span class="badge-dot"></span>${escapeHtml(status)}</span>`;
}
function qs(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/* ---------------------------------------------------------------------
   Toast notifications
   --------------------------------------------------------------------- */
function ensureToastStack() {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}
function showToast(title, message, type = "success") {
  const icons = { success: "✅", error: "⚠️", warning: "🔔", info: "ℹ️" };
  const stack = ensureToastStack();
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `
    <div class="toast-ico">${icons[type] || icons.success}</div>
    <div>
      <div class="toast-title">${escapeHtml(title)}</div>
      <div class="toast-msg">${escapeHtml(message)}</div>
    </div>
    <button class="toast-close" aria-label="Dismiss">✕</button>`;
  el.querySelector(".toast-close").onclick = () => el.remove();
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

/* ---------------------------------------------------------------------
   Modal helpers — works with any .modal-overlay#<id>
   --------------------------------------------------------------------- */
function openModal(id) {
  const overlay = document.getElementById(id);
  if (!overlay) return;
  overlay.classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeModal(id) {
  const overlay = document.getElementById(id);
  if (!overlay) return;
  overlay.classList.remove("open");
  document.body.style.overflow = "";
}
document.addEventListener("click", (e) => {
  if (e.target.classList && e.target.classList.contains("modal-overlay")) {
    e.target.classList.remove("open");
    document.body.style.overflow = "";
  }
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    document.querySelectorAll(".modal-overlay.open").forEach(m => m.classList.remove("open"));
    document.body.style.overflow = "";
  }
});

/* ---------------------------------------------------------------------
   Simulated loading helper — shows a spinner briefly, then calls render()
   --------------------------------------------------------------------- */
function withLoading(container, renderFn, delay = 450) {
  container.innerHTML = `<div class="loading-wrap"><div class="spinner"></div><p>Loading data…</p></div>`;
  setTimeout(renderFn, delay);
}

/* ---------------------------------------------------------------------
   Shared project card / row renderers (used on dashboard, search, list)
   --------------------------------------------------------------------- */
function projectCardHtml(p) {
  const role = getCurrentRole();
  const canRequest = role === "student" && p.status === "Published";
  return `
    <article class="card project-card card-hover">
      <div class="project-card-top">
        <span class="project-card-cat">${escapeHtml(p.category)}</span>
        ${badge(p.status)}
      </div>
      <h3><a href="repository-details.html?id=${p.id}">${escapeHtml(p.title)}</a></h3>
      <p class="abstract">${escapeHtml(p.abstract)}</p>
      <div class="tech-tags">${p.technologies.map(t => `<span class="tech-tag">${escapeHtml(t)}</span>`).join("")}</div>
      <div class="project-meta">
        <span>🧑‍🏫 ${escapeHtml(p.faculty)}</span>
        <span>📅 ${p.year}</span>
        <span>⬇️ ${p.downloads}</span>
      </div>
      <div class="project-card-footer">
        <a href="repository-details.html?id=${p.id}" class="btn btn-secondary btn-sm">View Details</a>
        ${canRequest ? `<button class="btn btn-primary btn-sm request-download-btn" data-id="${p.id}" data-title="${escapeHtml(p.title)}">Request Download</button>` : ""}
      </div>
    </article>`;
}

function projectListRowHtml(p) {
  const role = getCurrentRole();
  const canRequest = role === "student" && p.status === "Published";
  return `
    <div class="project-list-row">
      <div class="file-ico">📄</div>
      <div style="flex:1;min-width:0;">
        <a href="repository-details.html?id=${p.id}" class="cell-title">${escapeHtml(p.title)}</a>
        <div class="cell-sub">${escapeHtml(p.category)} · ${escapeHtml(p.faculty)} · ${p.year} · ⬇ ${p.downloads}</div>
      </div>
      ${badge(p.status)}
      <div class="project-actions">
        <a href="repository-details.html?id=${p.id}" class="btn btn-secondary btn-sm">View</a>
        ${canRequest ? `<button class="btn btn-primary btn-sm request-download-btn" data-id="${p.id}" data-title="${escapeHtml(p.title)}">Request</button>` : ""}
      </div>
    </div>`;
}

/* ---------------------------------------------------------------------
   Download request modal — shared across search / list / details pages.
   Call attachRequestModal() once per page (after DOM ready) to inject it,
   then any button with class "request-download-btn" + data-id/data-title
   will open it automatically via event delegation.
   --------------------------------------------------------------------- */
function attachRequestModal() {
  if (document.getElementById("requestModal")) return;
  const el = document.createElement("div");
  el.className = "modal-overlay";
  el.id = "requestModal";
  el.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>Request Download</h3>
        <button class="modal-close" onclick="closeModal('requestModal')">✕</button>
      </div>
      <div class="modal-body">
        <form id="requestForm" novalidate>
          <div class="form-group">
            <label>Project Name</label>
            <input class="form-control" id="reqProjectName" readonly />
          </div>
          <div class="form-group" id="reqReasonGroup">
            <label>Reason for Download</label>
            <textarea class="form-control" id="reqReason" placeholder="Explain why you need this project's files…"></textarea>
            <div class="form-error">Please provide a reason (at least 10 characters).</div>
          </div>
          <div class="form-group" id="reqDocsGroup">
            <label>Requested Documents</label>
            <div class="checkbox-list">
              <label><input type="checkbox" name="reqDocs" value="Final Report"> Final Report</label>
              <label><input type="checkbox" name="reqDocs" value="Source Code"> Source Code</label>
              <label><input type="checkbox" name="reqDocs" value="Deliverables"> Deliverables / Presentation</label>
              <label><input type="checkbox" name="reqDocs" value="Dataset"> Dataset / Appendix</label>
            </div>
            <div class="form-error">Select at least one document.</div>
          </div>
          <div class="form-group">
            <label>Remarks (optional)</label>
            <textarea class="form-control" id="reqRemarks" placeholder="Anything else the reviewing faculty should know…"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal('requestModal')">Cancel</button>
        <button class="btn btn-primary" id="submitRequestBtn">Submit Request</button>
      </div>
    </div>`;
  document.body.appendChild(el);

  document.body.addEventListener("click", (e) => {
    const btn = e.target.closest(".request-download-btn");
    if (!btn) return;
    document.getElementById("reqProjectName").value = btn.dataset.title;
    document.getElementById("reqProjectName").dataset.projectId = btn.dataset.id;
    document.getElementById("reqReason").value = "";
    document.getElementById("reqRemarks").value = "";
    document.querySelectorAll('input[name="reqDocs"]').forEach(c => c.checked = false);
    document.getElementById("reqReasonGroup").classList.remove("error");
    document.getElementById("reqDocsGroup").classList.remove("error");
    openModal("requestModal");
  });

  document.getElementById("submitRequestBtn").addEventListener("click", () => {
    const reason = document.getElementById("reqReason").value.trim();
    const docs = Array.from(document.querySelectorAll('input[name="reqDocs"]:checked')).map(c => c.value);
    let valid = true;
    document.getElementById("reqReasonGroup").classList.toggle("error", reason.length < 10);
    document.getElementById("reqDocsGroup").classList.toggle("error", docs.length === 0);
    if (reason.length < 10 || docs.length === 0) valid = false;
    if (!valid) return;

    const projectId = document.getElementById("reqProjectName").dataset.projectId;
    const project = PROJECTS.find(p => p.id === projectId);
    const user = getCurrentUser();
    addRequest({
      id: nextRequestId(),
      projectId,
      projectTitle: project ? project.title : document.getElementById("reqProjectName").value,
      studentName: user.name,
      studentId: user.idNo,
      reason,
      documents: docs,
      remarks: document.getElementById("reqRemarks").value.trim(),
      status: "Pending",
      requestedOn: new Date().toISOString()
    });
    closeModal("requestModal");
    showToast("Request submitted", "Your download request has been sent for faculty approval.", "success");
  });
}
