/* Published Projects page logic (Admin) */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "published",
    title: "Published Projects",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Published Projects" }]
  });

  const catSel = document.getElementById("pubCategory");
  CATEGORIES.forEach(c => catSel.insertAdjacentHTML("beforeend", `<option value="${c}">${c}</option>`));

  function render() {
    const term = document.getElementById("pubSearch").value.trim().toLowerCase();
    const category = catSel.value;
    let list = getProjectsWithOverrides().filter(p => p.status === "Published").filter(p => {
      if (term && !p.title.toLowerCase().includes(term)) return false;
      if (category && p.category !== category) return false;
      return true;
    });

    document.getElementById("pubInfo").textContent = `${list.length} published project${list.length !== 1 ? "s" : ""}`;

    const tbody = document.getElementById("pubBody");
    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-ico">📭</div><h3>No published projects found</h3><p>Try a different search or category.</p></div></td></tr>`;
      return;
    }
    tbody.innerHTML = list.map(p => `
      <tr>
        <td><a href="repository-details.html?id=${p.id}" class="cell-title">${escapeHtml(p.title)}</a><div class="cell-sub">${p.id}</div></td>
        <td>${escapeHtml(p.category)}</td>
        <td>${escapeHtml(p.faculty)}</td>
        <td>${p.year}</td>
        <td>${p.downloads}</td>
        <td class="row-actions">
          <button class="btn btn-secondary btn-sm" data-hide="${p.id}">Hide</button>
          <button class="btn btn-danger btn-sm" data-archive="${p.id}">Archive</button>
        </td>
      </tr>`).join("");

    tbody.querySelectorAll("[data-hide]").forEach(b => b.addEventListener("click", () => {
      setOverride(b.dataset.hide, "Hidden");
      showToast("Project hidden", "The project is no longer visible to students.", "success");
      render();
    }));
    tbody.querySelectorAll("[data-archive]").forEach(b => b.addEventListener("click", () => {
      setOverride(b.dataset.archive, "Archived");
      showToast("Project archived", "The project has been moved to the archive.", "success");
      render();
    }));
  }

  document.getElementById("pubSearch").addEventListener("input", debounce(render, 200));
  catSel.addEventListener("change", render);
  render();
});
