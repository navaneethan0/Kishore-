/* Repository Details page logic */
document.addEventListener("DOMContentLoaded", () => {
  const id = qs("id") || PROJECTS[0].id;
  const project = getProjectsWithOverrides().find(p => p.id === id);

  initLayout({
    page: "list",
    title: "Project Details",
    crumbs: [
      { label: "Home", href: "repository-dashboard.html" },
      { label: "Repository List", href: "repository-list.html" },
      { label: project ? project.title : "Not found" }
    ]
  });
  attachRequestModal();

  const root = document.getElementById("detailsRoot");
  if (!project) {
    root.innerHTML = `<div class="card empty-state">
      <div class="empty-ico">❓</div>
      <h3>Project not found</h3>
      <p>The project you're looking for may have been removed or archived.</p>
      <a href="repository-list.html" class="btn btn-primary mt-16">Back to Repository</a>
    </div>`;
    return;
  }

  const role = getCurrentRole();
  const canRequest = role === "student" && project.status === "Published";
  const isAdmin = role === "admin";

  root.innerHTML = `
    <div class="page-header">
      <div class="page-header-row">
        <div>
          <span class="project-card-cat">${escapeHtml(project.category)}</span>
          <h1 class="mt-8">${escapeHtml(project.title)}</h1>
          <p class="page-sub">${project.id} · ${escapeHtml(project.department)} · Academic Year ${project.year}</p>
        </div>
        <div class="flex gap-10">
          ${badge(project.status)}
        </div>
      </div>
    </div>

    <div class="two-col-layout">
      <div>
        <div class="card card-pad mb-16">
          <h3 class="section-title">Abstract</h3>
          <p style="color:var(--gray-700);line-height:1.7;font-size:14px;">${escapeHtml(project.abstract)}</p>
        </div>

        <div class="card card-pad mb-16">
          <h3 class="section-title">Technologies Used</h3>
          <div class="tech-tags">${project.technologies.map(t => `<span class="tech-tag">${escapeHtml(t)}</span>`).join("")}</div>
        </div>

        <div class="card card-pad mb-16">
          <h3 class="section-title">Keywords</h3>
          <div class="tech-tags">${project.keywords.map(t => `<span class="tag-chip">${escapeHtml(t)}</span>`).join("")}</div>
        </div>

        <div class="card card-pad">
          <h3 class="section-title">Project Documents</h3>
          <div class="table-wrap" style="border:none;">
            ${["Final Report","Source Code","Deliverables / Presentation"].map(doc => `
              <div class="project-list-row">
                <div class="file-ico">📄</div>
                <div style="flex:1;">
                  <div class="cell-title">${doc}</div>
                  <div class="cell-sub">Available after approved download request</div>
                </div>
                <span class="badge badge-neutral">🔒 Locked</span>
              </div>`).join("")}
          </div>
        </div>
      </div>

      <div class="side-panel">
        <div class="card card-pad mb-16">
          <h3 class="section-title">Project Info</h3>
          <div class="flex flex-col gap-12 text-sm">
            <div class="flex justify-between"><span class="text-muted">Faculty Guide</span><strong>${escapeHtml(project.faculty)}</strong></div>
            <div class="flex justify-between"><span class="text-muted">Department</span><strong>${escapeHtml(project.department)}</strong></div>
            <div class="flex justify-between"><span class="text-muted">Academic Year</span><strong>${project.year}</strong></div>
            <div class="flex justify-between"><span class="text-muted">Category</span><strong>${escapeHtml(project.category)}</strong></div>
            <div class="flex justify-between"><span class="text-muted">Total Downloads</span><strong>${project.downloads}</strong></div>
            <div class="flex justify-between"><span class="text-muted">Status</span>${badge(project.status)}</div>
          </div>
          <div class="divider"></div>
          ${canRequest
            ? `<button class="btn btn-primary btn-block request-download-btn" data-id="${project.id}" data-title="${escapeHtml(project.title)}">Request Download</button>`
            : role === "student"
              ? `<button class="btn btn-secondary btn-block" disabled>Not Available for Download</button>`
              : `<a href="download-approval.html" class="btn btn-secondary btn-block">Manage via Approvals →</a>`}
        </div>

        ${isAdmin ? `
        <div class="card card-pad">
          <h3 class="section-title">Admin Controls</h3>
          <div class="flex flex-col gap-8">
            <button class="btn btn-secondary btn-block" id="toggleHide">${project.status === "Hidden" ? "Unhide Project" : "Hide Project"}</button>
            <button class="btn btn-secondary btn-block" id="toggleArchive">${project.status === "Archived" ? "Restore Project" : "Archive Project"}</button>
          </div>
        </div>` : ""}
      </div>
    </div>`;

  if (isAdmin) {
    const hideBtn = document.getElementById("toggleHide");
    const archiveBtn = document.getElementById("toggleArchive");
    hideBtn.addEventListener("click", () => {
      const newStatus = project.status === "Hidden" ? "Published" : "Hidden";
      setOverride(project.id, newStatus);
      showToast("Status updated", `Project is now ${newStatus.toLowerCase()}.`, "success");
      setTimeout(() => window.location.reload(), 600);
    });
    archiveBtn.addEventListener("click", () => {
      const newStatus = project.status === "Archived" ? "Published" : "Archived";
      setOverride(project.id, newStatus);
      showToast("Status updated", `Project is now ${newStatus.toLowerCase()}.`, "success");
      setTimeout(() => window.location.reload(), 600);
    });
  }
});
