/* Download Approval page logic (Technical Faculty) */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "approval",
    title: "Download Approval",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Download Approval" }]
  });

  function renderStats() {
    const all = loadRequests();
    const pending = all.filter(r => r.status === "Pending").length;
    const approved = all.filter(r => r.status === "Approved").length;
    const rejected = all.filter(r => r.status === "Rejected").length;
    document.getElementById("approvalStats").innerHTML = `
      <div class="card stat-card">
        <div class="stat-icon icon-bg-amber">⏳</div>
        <div><div class="stat-value">${pending}</div><div class="stat-label">Pending Requests</div></div>
      </div>
      <div class="card stat-card">
        <div class="stat-icon icon-bg-green">✅</div>
        <div><div class="stat-value">${approved}</div><div class="stat-label">Approved</div></div>
      </div>
      <div class="card stat-card">
        <div class="stat-icon icon-bg-red">✖️</div>
        <div><div class="stat-value">${rejected}</div><div class="stat-label">Rejected</div></div>
      </div>
      <div class="card stat-card">
        <div class="stat-icon icon-bg-indigo">📄</div>
        <div><div class="stat-value">${all.length}</div><div class="stat-label">Total Requests</div></div>
      </div>`;
  }

  function render() {
    renderStats();
    const term = document.getElementById("apSearch").value.trim().toLowerCase();
    const statusFilter = document.getElementById("apStatusFilter").value;
    let list = loadRequests().filter(r => {
      if (statusFilter && r.status !== statusFilter) return false;
      if (term && !(r.studentName + r.projectTitle).toLowerCase().includes(term)) return false;
      return true;
    });
    list.sort((a, b) => new Date(b.requestedOn) - new Date(a.requestedOn));

    document.getElementById("apInfo").textContent = `Showing ${list.length} request${list.length !== 1 ? "s" : ""}`;

    const tbody = document.getElementById("approvalBody");
    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-ico">📭</div><h3>No requests found</h3><p>Try adjusting your search or filters.</p></div></td></tr>`;
      return;
    }
    tbody.innerHTML = list.map(r => `
      <tr>
        <td><div class="cell-title">${escapeHtml(r.studentName)}</div><div class="cell-sub">${r.studentId}</div></td>
        <td>${escapeHtml(r.projectTitle)}</td>
        <td>${r.documents.map(d => `<span class="tech-tag">${escapeHtml(d)}</span>`).join(" ")}</td>
        <td>${formatDate(r.requestedOn)}</td>
        <td>${badge(r.status)}</td>
        <td><button class="btn btn-secondary btn-sm" data-review="${r.id}">Review</button></td>
      </tr>`).join("");

    tbody.querySelectorAll("[data-review]").forEach(btn => btn.addEventListener("click", () => openReview(btn.dataset.review)));
  }

  function openReview(id) {
    const req = loadRequests().find(r => r.id === id);
    const body = document.getElementById("decisionModalBody");
    const footer = document.getElementById("decisionModalFooter");
    body.innerHTML = `
      <div class="flex flex-col gap-10 text-sm">
        <div class="flex justify-between"><span class="text-muted">Student</span><strong>${escapeHtml(req.studentName)} (${req.studentId})</strong></div>
        <div class="flex justify-between"><span class="text-muted">Project</span><strong>${escapeHtml(req.projectTitle)}</strong></div>
        <div class="flex justify-between"><span class="text-muted">Requested On</span><strong>${formatDate(req.requestedOn)}</strong></div>
        <div class="flex justify-between"><span class="text-muted">Status</span>${badge(req.status)}</div>
        <div class="divider"></div>
        <div><span class="text-muted">Reason</span><p style="margin-top:6px;">${escapeHtml(req.reason)}</p></div>
        <div><span class="text-muted">Requested Documents</span><div class="tech-tags mt-8">${req.documents.map(d => `<span class="tech-tag">${escapeHtml(d)}</span>`).join("")}</div></div>
        ${req.remarks ? `<div><span class="text-muted">Remarks</span><p style="margin-top:6px;">${escapeHtml(req.remarks)}</p></div>` : ""}
        ${req.status === "Approved" ? `<div><span class="text-muted">Access Until</span><p style="margin-top:6px;font-weight:700;color:var(--success-text);">${formatDate(req.accessUntil)} (24-hour access)</p></div>` : ""}
        ${req.status === "Rejected" && req.rejectReason ? `<div><span class="text-muted">Rejection Reason</span><p style="margin-top:6px;">${escapeHtml(req.rejectReason)}</p></div>` : ""}
      </div>`;

    if (req.status === "Pending") {
      footer.innerHTML = `
        <button class="btn btn-danger" id="rejectBtn">Reject</button>
        <button class="btn btn-success" id="approveBtn">Approve</button>`;
      footer.querySelector("#approveBtn").addEventListener("click", () => {
        const accessUntil = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
        updateRequest(req.id, { status: "Approved", decidedOn: new Date().toISOString(), accessUntil });
        closeModal("decisionModal");
        showToast("Request approved", `${req.studentName} now has 24-hour access.`, "success");
        render();
      });
      footer.querySelector("#rejectBtn").addEventListener("click", () => {
        updateRequest(req.id, { status: "Rejected", decidedOn: new Date().toISOString(), rejectReason: "Does not meet download policy requirements." });
        closeModal("decisionModal");
        showToast("Request rejected", `${req.studentName}'s request has been rejected.`, "warning");
        render();
      });
    } else {
      footer.innerHTML = `<button class="btn btn-secondary" onclick="closeModal('decisionModal')">Close</button>`;
    }
    openModal("decisionModal");
  }

  document.getElementById("apSearch").addEventListener("input", debounce(render, 200));
  document.getElementById("apStatusFilter").addEventListener("change", render);

  render();
});
