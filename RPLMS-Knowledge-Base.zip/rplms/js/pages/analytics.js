/* Repository Analytics page logic */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "analytics",
    title: "Repository Analytics",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Repository Analytics" }]
  });

  const projects = getProjectsWithOverrides();
  const requests = loadRequests();

  document.getElementById("anaStats").innerHTML = `
    <div class="card stat-card"><div class="stat-icon icon-bg-indigo">📁</div><div><div class="stat-value">${projects.length}</div><div class="stat-label">Total Projects</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-green">📗</div><div><div class="stat-value">${projects.filter(p=>p.status==="Published").length}</div><div class="stat-label">Published</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-amber">⬇️</div><div><div class="stat-value">${projects.reduce((s,p)=>s+p.downloads,0).toLocaleString()}</div><div class="stat-label">Total Downloads</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-blue">📨</div><div><div class="stat-value">${requests.length}</div><div class="stat-label">Download Requests</div></div></div>`;

  // Category bar chart
  const catCounts = CATEGORIES.map(c => ({ label: c, count: projects.filter(p => p.category === c).length }));
  const maxCat = Math.max(...catCounts.map(c => c.count), 1);
  document.getElementById("anaCatChart").innerHTML = catCounts.map(c => `
    <div class="bar-col">
      <span class="bar-val">${c.count}</span>
      <div class="bar" style="height:${(c.count / maxCat) * 100}%"></div>
      <span class="bar-label" style="writing-mode:vertical-rl;transform:rotate(180deg);height:70px;">${c.label}</span>
    </div>`).join("");

  // Department donut
  const deptColors = ["#4338ca","#6366f1","#818cf8","#a5b4fc","#c7d2fe"];
  const deptCounts = DEPARTMENTS.map(d => ({ label: d, count: projects.filter(p => p.department === d).length }));
  const totalDept = deptCounts.reduce((s,d)=>s+d.count,0) || 1;
  let acc = 0;
  const deptSeg = deptCounts.map((d,i) => { const pct=(d.count/totalDept)*100; const seg=`${deptColors[i%deptColors.length]} ${acc}% ${acc+pct}%`; acc+=pct; return seg; });
  document.getElementById("anaDeptDonut").style.background = `conic-gradient(${deptSeg.join(",")})`;
  document.getElementById("anaDeptDonut").innerHTML = `<div class="donut-center"><div class="d-val">${totalDept}</div><div class="d-label">Projects</div></div>`;
  document.getElementById("anaDeptLegend").innerHTML = deptCounts.map((d,i)=>`<div class="legend-item"><span class="legend-dot" style="background:${deptColors[i%deptColors.length]}"></span>${d.label} · ${d.count}</div>`).join("");

  // Simulated download trend (deterministic pseudo-data derived from total downloads)
  const months = ["Feb","Mar","Apr","May","Jun","Jul"];
  const totalDl = projects.reduce((s,p)=>s+p.downloads,0);
  const trend = [0.11,0.14,0.15,0.18,0.19,0.23].map(f => Math.round(totalDl * f / 3));
  const maxTrend = Math.max(...trend, 1);
  document.getElementById("anaTrendChart").innerHTML = months.map((m,i) => `
    <div class="bar-col">
      <span class="bar-val">${trend[i]}</span>
      <div class="bar" style="height:${(trend[i]/maxTrend)*100}%;background:#16a34a;"></div>
      <span class="bar-label">${m}</span>
    </div>`).join("");

  // Growth by academic year
  const yearCounts = ACADEMIC_YEARS.slice().reverse().map(y => ({ y, count: projects.filter(p=>p.year===y).length }));
  const maxYear = Math.max(...yearCounts.map(y=>y.count), 1);
  document.getElementById("anaGrowthChart").innerHTML = yearCounts.map(y => `
    <div class="bar-col">
      <span class="bar-val">${y.count}</span>
      <div class="bar" style="height:${(y.count/maxYear)*100}%"></div>
      <span class="bar-label">${y.y}</span>
    </div>`).join("");

  // Top downloaded table
  const top = [...projects].sort((a,b)=>b.downloads-a.downloads).slice(0,8);
  document.getElementById("topDownloadsBody").innerHTML = top.map((p,i) => `
    <tr>
      <td>${i+1}</td>
      <td><a href="repository-details.html?id=${p.id}" class="cell-title">${escapeHtml(p.title)}</a></td>
      <td>${escapeHtml(p.category)}</td>
      <td>${escapeHtml(p.faculty)}</td>
      <td><strong>${p.downloads}</strong></td>
    </tr>`).join("");
});
