/* Repository Dashboard page logic */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "dashboard",
    title: "Repository Dashboard",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Repository Dashboard" }]
  });

  const role = getCurrentRole();
  if (role === "student") {
    document.getElementById("qlAnalytics").classList.add("hidden");
  } else {
    document.getElementById("qlHistory").classList.add("hidden");
  }

  const projects = getProjectsWithOverrides();
  const published = projects.filter(p => p.status === "Published");
  const totalDownloads = projects.reduce((s, p) => s + p.downloads, 0);
  const contributors = new Set(projects.map(p => p.faculty)).size;

  document.getElementById("statGrid").innerHTML = `
    <div class="card stat-card">
      <div class="stat-icon icon-bg-indigo">📁</div>
      <div><div class="stat-value">${projects.length}</div><div class="stat-label">Total Projects</div></div>
    </div>
    <div class="card stat-card">
      <div class="stat-icon icon-bg-green">📗</div>
      <div><div class="stat-value">${published.length}</div><div class="stat-label">Published</div><div class="stat-trend up">↑ Live in repository</div></div>
    </div>
    <div class="card stat-card">
      <div class="stat-icon icon-bg-amber">⬇️</div>
      <div><div class="stat-value">${totalDownloads.toLocaleString()}</div><div class="stat-label">Total Downloads</div></div>
    </div>
    <div class="card stat-card">
      <div class="stat-icon icon-bg-blue">👥</div>
      <div><div class="stat-value">${contributors}</div><div class="stat-label">Contributing Faculty</div></div>
    </div>
    <div class="card stat-card">
      <div class="stat-icon icon-bg-pink">🏷️</div>
      <div><div class="stat-value">${CATEGORIES.length}</div><div class="stat-label">Categories</div></div>
    </div>`;

  const recentRows = [...projects].sort((a, b) => b.year.localeCompare(a.year)).slice(0, 6);
  document.querySelector("#recentTable tbody").innerHTML = recentRows.map(p => `
    <tr>
      <td><a href="repository-details.html?id=${p.id}" class="cell-title">${escapeHtml(p.title)}</a><div class="cell-sub">${p.id}</div></td>
      <td>${escapeHtml(p.category)}</td>
      <td>${escapeHtml(p.faculty)}</td>
      <td>${p.year}</td>
      <td>${p.downloads}</td>
      <td>${badge(p.status)}</td>
    </tr>`).join("");

  // Bar chart — projects per category
  const catCounts = CATEGORIES.map(c => ({ label: c, count: projects.filter(p => p.category === c).length }));
  const maxCount = Math.max(...catCounts.map(c => c.count), 1);
  document.getElementById("catBarChart").innerHTML = catCounts.map(c => `
    <div class="bar-col">
      <span class="bar-val">${c.count}</span>
      <div class="bar" style="height:${(c.count / maxCount) * 100}%"></div>
      <span class="bar-label" style="writing-mode:vertical-rl;transform:rotate(180deg);height:70px;">${c.label}</span>
    </div>`).join("");

  // Growth donut (simulated year-over-year composition)
  const yearCounts = ACADEMIC_YEARS.map(y => ({ year: y, count: projects.filter(p => p.year === y).length })).filter(y => y.count > 0);
  const colors = ["#4338ca", "#6366f1", "#a5b4fc", "#c7d2fe"];
  let acc = 0;
  const total = yearCounts.reduce((s, y) => s + y.count, 0) || 1;
  const segments = yearCounts.map((y, i) => {
    const pct = (y.count / total) * 100;
    const seg = `${colors[i % colors.length]} ${acc}% ${acc + pct}%`;
    acc += pct;
    return seg;
  });
  document.getElementById("growthDonut").style.background = `conic-gradient(${segments.join(",")})`;
  document.getElementById("growthDonut").innerHTML = `<div class="donut-center"><div class="d-val">${total}</div><div class="d-label">Projects</div></div>`;
  document.getElementById("growthLegend").innerHTML = yearCounts.map((y, i) => `
    <div class="legend-item"><span class="legend-dot" style="background:${colors[i % colors.length]}"></span>${y.year} · ${y.count}</div>`).join("");
});
