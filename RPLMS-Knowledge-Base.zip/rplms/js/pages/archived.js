/* Archived Projects page logic (Admin) */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "archived",
    title: "Archived Projects",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Archived Projects" }]
  });

  function render() {
    const term = document.getElementById("arcSearch").value.trim().toLowerCase();
    let list = getProjectsWithOverrides().filter(p => p.status === "Archived" || p.status === "Hidden").filter(p =>
      !term || p.title.toLowerCase().includes(term));

    document.getElementById("arcInfo").textContent = `${list.length} project${list.length !== 1 ? "s" : ""} in archive`;

    const tbody = document.getElementById("arcBody");
    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-ico">🗄️</div><h3>Archive is empty</h3><p>Archived or hidden projects will show up here.</p></div></td></tr>`;
      return;
    }
    tbody.innerHTML = list.map(p => `
      <tr>
        <td><a href="repository-details.html?id=${p.id}" class="cell-title">${escapeHtml(p.title)}</a><div class="cell-sub">${p.id}</div></td>
        <td>${escapeHtml(p.category)}</td>
        <td>${escapeHtml(p.faculty)}</td>
        <td>${p.year}</td>
        <td>${badge(p.status)}</td>
        <td class="row-actions">
          <button class="btn btn-success btn-sm" data-restore="${p.id}">Restore</button>
        </td>
      </tr>`).join("");

    tbody.querySelectorAll("[data-restore]").forEach(b => b.addEventListener("click", () => {
      setOverride(b.dataset.restore, "Published");
      showToast("Project restored", "The project is now published and visible to students.", "success");
      render();
    }));
  }

  document.getElementById("arcSearch").addEventListener("input", debounce(render, 200));
  render();
});
