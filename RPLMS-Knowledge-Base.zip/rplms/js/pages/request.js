/* Download Request page logic */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "request",
    title: "Download Request",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Download Request" }]
  });

  const projectSel = document.getElementById("drProject");
  getProjectsWithOverrides().filter(p => p.status === "Published").forEach(p =>
    projectSel.insertAdjacentHTML("beforeend", `<option value="${p.id}">${escapeHtml(p.title)}</option>`));

  const preselect = qs("id");
  if (preselect) projectSel.value = preselect;

  function renderRecent() {
    const user = getCurrentUser();
    const mine = loadRequests().filter(r => r.studentId === user.idNo).slice(0, 4);
    const list = document.getElementById("recentRequestsList");
    if (mine.length === 0) {
      list.innerHTML = `<p class="text-muted text-sm">No requests submitted yet.</p>`;
      return;
    }
    list.innerHTML = mine.map(r => `
      <div class="flex justify-between items-center" style="padding:10px 0;border-bottom:1px solid var(--gray-100);">
        <div style="min-width:0;">
          <div class="cell-title" style="font-size:13px;">${escapeHtml(r.projectTitle)}</div>
          <div class="cell-sub">${formatDateShort(r.requestedOn)}</div>
        </div>
        ${badge(r.status)}
      </div>`).join("");
  }
  renderRecent();

  function resetErrors() {
    document.getElementById("drProjectGroup").classList.remove("error");
    document.getElementById("drReasonGroup").classList.remove("error");
    document.getElementById("drDocsGroup").classList.remove("error");
  }

  document.getElementById("drSubmit").addEventListener("click", () => {
    resetErrors();
    const projectId = projectSel.value;
    const reason = document.getElementById("drReason").value.trim();
    const docs = Array.from(document.querySelectorAll('input[name="drDocs"]:checked')).map(c => c.value);
    let valid = true;

    if (!projectId) { document.getElementById("drProjectGroup").classList.add("error"); valid = false; }
    if (reason.length < 10) { document.getElementById("drReasonGroup").classList.add("error"); valid = false; }
    if (docs.length === 0) { document.getElementById("drDocsGroup").classList.add("error"); valid = false; }
    if (!valid) { showToast("Missing information", "Please complete all required fields.", "error"); return; }

    const project = PROJECTS.find(p => p.id === projectId);
    const user = getCurrentUser();
    addRequest({
      id: nextRequestId(),
      projectId,
      projectTitle: project.title,
      studentName: user.name,
      studentId: user.idNo,
      reason,
      documents: docs,
      remarks: document.getElementById("drRemarks").value.trim(),
      status: "Pending",
      requestedOn: new Date().toISOString()
    });

    showToast("Request submitted", "Your download request has been sent for faculty approval.", "success");
    document.getElementById("drForm").reset();
    resetErrors();
    renderRecent();
  });

  document.getElementById("drCancel").addEventListener("click", () => {
    document.getElementById("drForm").reset();
    resetErrors();
  });
});
