/* Repository Statistics page logic (Admin) */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "statistics",
    title: "Repository Statistics",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Repository Statistics" }]
  });

  const projects = getProjectsWithOverrides();
  const published = projects.filter(p => p.status === "Published").length;
  const archived = projects.filter(p => p.status === "Archived").length;
  const hidden = projects.filter(p => p.status === "Hidden").length;
  const requests = loadRequests();

  document.getElementById("statPageGrid").innerHTML = `
    <div class="card stat-card"><div class="stat-icon icon-bg-indigo">📁</div><div><div class="stat-value">${projects.length}</div><div class="stat-label">Total Projects</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-green">📗</div><div><div class="stat-value">${published}</div><div class="stat-label">Published</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-red">🗄️</div><div><div class="stat-value">${archived}</div><div class="stat-label">Archived</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-blue">🙈</div><div><div class="stat-value">${hidden}</div><div class="stat-label">Hidden</div></div></div>
    <div class="card stat-card"><div class="stat-icon icon-bg-amber">📨</div><div><div class="stat-value">${requests.length}</div><div class="stat-label">Download Requests</div></div></div>`;

  const statusData = [
    { label: "Published", count: published, color: "#16a34a" },
    { label: "Archived", count: archived, color: "#94a3b8" },
    { label: "Hidden", count: hidden, color: "#2563eb" }
  ].filter(s => s.count > 0);
  const total = statusData.reduce((s, d) => s + d.count, 0) || 1;
  let acc = 0;
  const seg = statusData.map(d => { const pct=(d.count/total)*100; const s=`${d.color} ${acc}% ${acc+pct}%`; acc+=pct; return s; });
  document.getElementById("statusDonut").style.background = `conic-gradient(${seg.join(",")})`;
  document.getElementById("statusDonut").innerHTML = `<div class="donut-center"><div class="d-val">${total}</div><div class="d-label">Projects</div></div>`;
  document.getElementById("statusLegend").innerHTML = statusData.map(d => `<div class="legend-item"><span class="legend-dot" style="background:${d.color}"></span>${d.label} · ${d.count}</div>`).join("");

  document.getElementById("deptSummaryBody").innerHTML = DEPARTMENTS.map(dep => {
    const deptProjects = projects.filter(p => p.department === dep);
    return `
      <tr>
        <td class="cell-title">${escapeHtml(dep)}</td>
        <td>${deptProjects.length}</td>
        <td>${deptProjects.filter(p => p.status === "Published").length}</td>
        <td>${deptProjects.filter(p => p.status === "Archived").length}</td>
        <td>${deptProjects.reduce((s, p) => s + p.downloads, 0)}</td>
      </tr>`;
  }).join("");
});
