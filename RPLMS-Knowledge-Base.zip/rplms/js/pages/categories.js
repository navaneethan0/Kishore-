/* Category Management page logic (Admin) */
const CAT_STORE_KEY = "rplms_categories";
const DEFAULT_DESCRIPTIONS = {
  "AI / ML": "Machine learning, deep learning and intelligent systems projects.",
  "IoT": "Connected devices, sensors and embedded networking projects.",
  "Web Application": "Browser-based full-stack and front-end applications.",
  "Mobile Application": "Native and cross-platform mobile apps.",
  "Embedded Systems": "Microcontroller-based and hardware-integrated projects.",
  "Robotics": "Autonomous and mechatronic robotic systems.",
  "Cyber Security": "Security tooling, threat detection and cryptography projects.",
  "Cloud Computing": "Cloud-native, serverless and distributed systems projects.",
  "Others": "Projects that don't fit into the categories above."
};

function loadCategories() {
  const raw = localStorage.getItem(CAT_STORE_KEY);
  if (raw) return JSON.parse(raw);
  const seeded = CATEGORIES.map(c => ({ name: c, description: DEFAULT_DESCRIPTIONS[c] || "", active: true }));
  localStorage.setItem(CAT_STORE_KEY, JSON.stringify(seeded));
  return seeded;
}
function saveCategories(list) { localStorage.setItem(CAT_STORE_KEY, JSON.stringify(list)); }

document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "categories",
    title: "Category Management",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Category Management" }]
  });

  const projects = getProjectsWithOverrides();
  let editingIndex = null;

  function render() {
    const cats = loadCategories();
    document.getElementById("categoryBody").innerHTML = cats.map((c, i) => {
      const count = projects.filter(p => p.category === c.name).length;
      return `
        <tr>
          <td class="cell-title">${escapeHtml(c.name)}</td>
          <td>${count}</td>
          <td class="cell-sub">${escapeHtml(c.description || "—")}</td>
          <td>${c.active ? badge("Published") : badge("Hidden")}</td>
          <td class="row-actions">
            <button class="btn btn-secondary btn-sm" data-edit="${i}">Edit</button>
            <button class="btn btn-secondary btn-sm" data-toggle="${i}">${c.active ? "Disable" : "Enable"}</button>
          </td>
        </tr>`;
    }).join("");

    document.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => openEdit(parseInt(b.dataset.edit, 10))));
    document.querySelectorAll("[data-toggle]").forEach(b => b.addEventListener("click", () => {
      const cats = loadCategories();
      const i = parseInt(b.dataset.toggle, 10);
      cats[i].active = !cats[i].active;
      saveCategories(cats);
      showToast("Category updated", `${cats[i].name} is now ${cats[i].active ? "active" : "disabled"}.`, "success");
      render();
    }));
  }

  function openEdit(i) {
    editingIndex = i;
    const cats = loadCategories();
    document.getElementById("categoryModalTitle").textContent = "Edit Category";
    document.getElementById("catNameInput").value = cats[i].name;
    document.getElementById("catDescInput").value = cats[i].description;
    openModal("categoryModal");
  }

  document.getElementById("addCategoryBtn").addEventListener("click", () => {
    editingIndex = null;
    document.getElementById("categoryModalTitle").textContent = "Add Category";
    document.getElementById("catNameInput").value = "";
    document.getElementById("catDescInput").value = "";
    openModal("categoryModal");
  });

  document.getElementById("saveCategoryBtn").addEventListener("click", () => {
    const name = document.getElementById("catNameInput").value.trim();
    const description = document.getElementById("catDescInput").value.trim();
    if (!name) { showToast("Category name required", "Please enter a name for the category.", "error"); return; }
    const cats = loadCategories();
    if (editingIndex === null) {
      cats.push({ name, description, active: true });
      showToast("Category added", `"${name}" has been added to the repository.`, "success");
    } else {
      cats[editingIndex].name = name;
      cats[editingIndex].description = description;
      showToast("Category updated", `"${name}" has been saved.`, "success");
    }
    saveCategories(cats);
    closeModal("categoryModal");
    render();
  });

  render();
});
