/* Repository List page logic */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "list",
    title: "Repository List",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Repository List" }]
  });
  attachRequestModal();

  const catSel = document.getElementById("filterCategory");
  const yearSel = document.getElementById("filterYear");
  const deptSel = document.getElementById("filterDept");
  const facSel = document.getElementById("filterFaculty");

  CATEGORIES.forEach(c => catSel.insertAdjacentHTML("beforeend", `<option value="${c}">${c}</option>`));
  ACADEMIC_YEARS.forEach(y => yearSel.insertAdjacentHTML("beforeend", `<option value="${y}">${y}</option>`));
  DEPARTMENTS.forEach(d => deptSel.insertAdjacentHTML("beforeend", `<option value="${d}">${d}</option>`));
  [...new Set(PROJECTS.map(p => p.faculty))].sort().forEach(f => facSel.insertAdjacentHTML("beforeend", `<option value="${f}">${f}</option>`));

  let view = "grid";
  let page = 1;
  const pageSize = 8;

  function getFiltered() {
    const term = document.getElementById("listSearch").value.trim().toLowerCase();
    const category = catSel.value, year = yearSel.value, dept = deptSel.value, faculty = facSel.value;
    const statusFilter = document.getElementById("filterStatus").value;
    const sort = document.getElementById("filterSort").value;

    let results = getProjectsWithOverrides().filter(p => {
      if (statusFilter) return p.status === statusFilter;
      return p.status !== "Hidden" && p.status !== "Archived";
    }).filter(p => {
      const haystack = [p.title, ...p.keywords, ...p.technologies, p.faculty].join(" ").toLowerCase();
      if (term && !haystack.includes(term)) return false;
      if (category && p.category !== category) return false;
      if (year && p.year !== year) return false;
      if (dept && p.department !== dept) return false;
      if (faculty && p.faculty !== faculty) return false;
      return true;
    });

    if (sort === "downloads") results.sort((a, b) => b.downloads - a.downloads);
    else if (sort === "year") results.sort((a, b) => b.year.localeCompare(a.year));
    else if (sort === "title") results.sort((a, b) => a.title.localeCompare(b.title));

    return results;
  }

  function render() {
    const container = document.getElementById("listContainer");
    withLoading(container, () => {
      const all = getFiltered();
      const totalPages = Math.max(1, Math.ceil(all.length / pageSize));
      if (page > totalPages) page = totalPages;
      const start = (page - 1) * pageSize;
      const pageItems = all.slice(start, start + pageSize);

      document.getElementById("resultSummary").textContent =
        all.length === 0 ? "No projects found" : `Showing ${start + 1}–${Math.min(start + pageSize, all.length)} of ${all.length} projects`;

      if (all.length === 0) {
        container.innerHTML = `<div class="card empty-state">
          <div class="empty-ico">📭</div>
          <h3>No projects match these filters</h3>
          <p>Try clearing a filter or searching a different keyword.</p>
        </div>`;
      } else if (view === "grid") {
        container.innerHTML = `<div class="project-grid">${pageItems.map(projectCardHtml).join("")}</div>`;
      } else {
        container.innerHTML = `<div class="table-wrap">${pageItems.map(projectListRowHtml).join("")}</div>`;
      }
      renderPagination(totalPages, all.length, start, pageItems.length);
    }, 300);
  }

  function renderPagination(totalPages, total, start, shown) {
    document.getElementById("pageInfo").textContent = total === 0 ? "" : `Page ${page} of ${totalPages}`;
    const controls = document.getElementById("pageControls");
    let html = `<button class="page-btn" id="prevPage" ${page === 1 ? "disabled" : ""}>‹</button>`;
    for (let i = 1; i <= totalPages; i++) {
      if (totalPages > 7 && Math.abs(i - page) > 2 && i !== 1 && i !== totalPages) {
        if (i === 2 || i === totalPages - 1) html += `<span class="page-btn" style="border:none;">…</span>`;
        continue;
      }
      html += `<button class="page-btn ${i === page ? "active" : ""}" data-page="${i}">${i}</button>`;
    }
    html += `<button class="page-btn" id="nextPage" ${page === totalPages ? "disabled" : ""}>›</button>`;
    controls.innerHTML = html;

    controls.querySelectorAll("[data-page]").forEach(btn => btn.addEventListener("click", () => { page = parseInt(btn.dataset.page, 10); render(); window.scrollTo({top:0,behavior:"smooth"}); }));
    const prev = document.getElementById("prevPage"); if (prev) prev.addEventListener("click", () => { if (page > 1) { page--; render(); } });
    const next = document.getElementById("nextPage"); if (next) next.addEventListener("click", () => { if (page < totalPages) { page++; render(); } });
  }

  document.getElementById("gridViewBtn").addEventListener("click", () => { view = "grid"; document.getElementById("gridViewBtn").classList.add("active"); document.getElementById("listViewBtn").classList.remove("active"); render(); });
  document.getElementById("listViewBtn").addEventListener("click", () => { view = "list"; document.getElementById("listViewBtn").classList.add("active"); document.getElementById("gridViewBtn").classList.remove("active"); render(); });
  document.getElementById("moreFiltersBtn").addEventListener("click", () => document.getElementById("moreFiltersPanel").classList.toggle("open"));

  ["listSearch"].forEach(id => document.getElementById(id).addEventListener("input", debounce(() => { page = 1; render(); }, 250)));
  ["filterCategory","filterYear","filterSort","filterDept","filterFaculty","filterStatus"].forEach(id =>
    document.getElementById(id).addEventListener("change", () => { page = 1; render(); }));

  const q = qs("q");
  if (q) document.getElementById("listSearch").value = q;

  render();
});
