/* Repository Search page logic */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "search",
    title: "Repository Search",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Repository Search" }]
  });
  attachRequestModal();

  const catSel = document.getElementById("advCategory");
  const deptSel = document.getElementById("advDept");
  const yearSel = document.getElementById("advYear");
  const facSel = document.getElementById("advFaculty");

  CATEGORIES.forEach(c => catSel.insertAdjacentHTML("beforeend", `<option value="${c}">${c}</option>`));
  DEPARTMENTS.forEach(d => deptSel.insertAdjacentHTML("beforeend", `<option value="${d}">${d}</option>`));
  ACADEMIC_YEARS.forEach(y => yearSel.insertAdjacentHTML("beforeend", `<option value="${y}">${y}</option>`));
  [...new Set(PROJECTS.map(p => p.faculty))].sort().forEach(f => facSel.insertAdjacentHTML("beforeend", `<option value="${f}">${f}</option>`));

  const grid = document.getElementById("resultsGrid");
  const countEl = document.getElementById("resultCount");

  function runSearch() {
    const term = document.getElementById("advTitle").value.trim().toLowerCase();
    const tech = document.getElementById("advTech").value.trim().toLowerCase();
    const category = catSel.value;
    const dept = deptSel.value;
    const year = yearSel.value;
    const faculty = facSel.value;
    const sort = document.getElementById("advSort").value;

    let results = getProjectsWithOverrides().filter(p => p.status !== "Hidden" && p.status !== "Archived").filter(p => {
      const haystack = [p.title, ...p.keywords, ...p.technologies].join(" ").toLowerCase();
      if (term && !haystack.includes(term)) return false;
      if (tech && !p.technologies.join(" ").toLowerCase().includes(tech)) return false;
      if (category && p.category !== category) return false;
      if (dept && p.department !== dept) return false;
      if (year && p.year !== year) return false;
      if (faculty && p.faculty !== faculty) return false;
      return true;
    });

    if (sort === "downloads") results.sort((a, b) => b.downloads - a.downloads);
    else if (sort === "year") results.sort((a, b) => b.year.localeCompare(a.year));
    else if (sort === "title") results.sort((a, b) => a.title.localeCompare(b.title));

    countEl.textContent = `${results.length} result${results.length !== 1 ? "s" : ""} found`;

    if (results.length === 0) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
        <div class="empty-ico">🔍</div>
        <h3>No projects match your search</h3>
        <p>Try removing a filter or using a broader keyword.</p>
      </div>`;
      return;
    }
    grid.innerHTML = results.map(projectCardHtml).join("");
  }

  document.getElementById("runSearch").addEventListener("click", runSearch);
  document.getElementById("clearSearch").addEventListener("click", () => {
    document.getElementById("advTitle").value = "";
    document.getElementById("advTech").value = "";
    catSel.value = ""; deptSel.value = ""; yearSel.value = ""; facSel.value = "";
    document.getElementById("advSort").value = "relevance";
    runSearch();
  });
  document.getElementById("advTitle").addEventListener("keydown", e => { if (e.key === "Enter") runSearch(); });

  // Pre-fill from global search / query param
  const q = qs("q");
  if (q) document.getElementById("advTitle").value = q;
  runSearch();
});
