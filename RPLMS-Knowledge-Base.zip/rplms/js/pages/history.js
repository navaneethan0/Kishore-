/* Download History page logic (Student) */
document.addEventListener("DOMContentLoaded", () => {
  initLayout({
    page: "history",
    title: "Download History",
    crumbs: [{ label: "Home", href: "repository-dashboard.html" }, { label: "Download History" }]
  });

  let activeTab = "all";

  function effectiveStatus(r) {
    if (r.status === "Approved" && r.accessUntil && new Date(r.accessUntil) < new Date()) return "Expired";
    return r.status;
  }

  function render() {
    const user = getCurrentUser();
    let list = loadRequests().filter(r => r.studentId === user.idNo);
    if (activeTab !== "all") list = list.filter(r => r.status === activeTab);
    list.sort((a, b) => new Date(b.requestedOn) - new Date(a.requestedOn));

    const tbody = document.getElementById("historyBody");
    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-ico">🗂️</div><h3>No requests here</h3><p>Requests you submit from the repository will appear in this list.</p><a href="repository-list.html" class="btn btn-primary mt-16">Browse Repository</a></div></td></tr>`;
      return;
    }

    tbody.innerHTML = list.map(r => {
      const eff = effectiveStatus(r);
      const canDownload = eff === "Approved";
      return `
        <tr>
          <td><div class="cell-title">${escapeHtml(r.projectTitle)}</div><div class="cell-sub">${r.projectId}</div></td>
          <td>${formatDate(r.requestedOn)}</td>
          <td>${r.documents.map(d => `<span class="tech-tag">${escapeHtml(d)}</span>`).join(" ")}</td>
          <td>${badge(eff)}</td>
          <td>${eff === "Approved" ? `<span class="text-sm" style="color:var(--success-text);font-weight:700;">until ${formatDate(r.accessUntil)}</span>` : "—"}</td>
          <td class="row-actions">
            <button class="btn btn-secondary btn-sm" data-view="${r.id}">Details</button>
            <button class="btn btn-primary btn-sm" data-download="${r.id}" ${canDownload ? "" : "disabled"}>Download</button>
          </td>
        </tr>`;
    }).join("");

    tbody.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => openDetail(b.dataset.view)));
    tbody.querySelectorAll("[data-download]").forEach(b => b.addEventListener("click", () => {
      showToast("Download started", "Your files are being prepared (simulated).", "success");
    }));
  }

  function openDetail(id) {
    const r = loadRequests().find(x => x.id === id);
    const eff = effectiveStatus(r);
    document.getElementById("histDetailBody").innerHTML = `
      <div class="flex flex-col gap-10 text-sm">
        <div class="flex justify-between"><span class="text-muted">Project</span><strong>${escapeHtml(r.projectTitle)}</strong></div>
        <div class="flex justify-between"><span class="text-muted">Requested On</span><strong>${formatDate(r.requestedOn)}</strong></div>
        <div class="flex justify-between"><span class="text-muted">Status</span>${badge(eff)}</div>
        <div class="divider"></div>
        <div><span class="text-muted">Reason</span><p style="margin-top:6px;">${escapeHtml(r.reason)}</p></div>
        <div><span class="text-muted">Documents</span><div class="tech-tags mt-8">${r.documents.map(d => `<span class="tech-tag">${escapeHtml(d)}</span>`).join("")}</div></div>
        ${r.remarks ? `<div><span class="text-muted">Remarks</span><p style="margin-top:6px;">${escapeHtml(r.remarks)}</p></div>` : ""}
        ${eff === "Approved" ? `<div><span class="text-muted">Access Until</span><p style="margin-top:6px;font-weight:700;color:var(--success-text);">${formatDate(r.accessUntil)}</p></div>` : ""}
        ${r.status === "Rejected" && r.rejectReason ? `<div><span class="text-muted">Rejection Reason</span><p style="margin-top:6px;">${escapeHtml(r.rejectReason)}</p></div>` : ""}
      </div>`;
    openModal("histDetailModal");
  }

  document.querySelectorAll(".tab-btn").forEach(btn => btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    activeTab = btn.dataset.tab;
    render();
  }));

  render();
});
