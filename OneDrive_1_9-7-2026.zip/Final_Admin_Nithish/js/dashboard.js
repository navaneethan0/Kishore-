/**
 * Dashboard Logic for RPLMS Administrator
 */

document.addEventListener('DOMContentLoaded', () => {
    initDashboard();
});

function initDashboard() {
    console.log('Dashboard initialized');
    // We could load data from LocalStorage here in a real scenario
    setupChartTooltips();
}

/**
 * Setup simple hover effects or tooltips for the donut chart
 */
function setupChartTooltips() {
    const segments = document.querySelectorAll('.donut-chart circle');
    segments.forEach(segment => {
        segment.addEventListener('mouseenter', () => {
            segment.style.opacity = '0.8';
            segment.style.strokeWidth = '14';
        });
        segment.addEventListener('mouseleave', () => {
            segment.style.opacity = '1';
            segment.style.strokeWidth = '12';
        });
    });
}
document.querySelectorAll(".read-btn").forEach(btn => {
    btn.addEventListener("click", function () {
        const item = this.closest(".notification-item");
        item.classList.remove("unread");
    });
});

document.querySelectorAll(".delete-btn").forEach(btn => {
    btn.addEventListener("click", function () {
        this.closest(".notification-item").remove();
    });
});

const notificationBtn = document.getElementById("notificationBtn");
const notificationModal = document.getElementById("notificationModal");
const closeNotification = document.getElementById("closeNotification");

notificationBtn.addEventListener("click", () => {
    notificationModal.style.display = "flex";
});

closeNotification.addEventListener("click", () => {
    notificationModal.style.display = "none";
});

window.addEventListener("click", (e) => {
    if (e.target === notificationModal) {
        notificationModal.style.display = "none";
    }
});
/**
 * Example function to update a stat card value
 */
function updateStat(id, value) {
    const el = document.querySelector(`.stat-card#${id} .stat-value`);
    if (el) {
        el.textContent = value;
    }
}

const profileBtn = document.getElementById("profileBtn");
const profileModal = document.getElementById("profileModal");
const closeModal = document.getElementById("closeModal");
const closeBtn = document.getElementById("closeBtn");

profileBtn.addEventListener("click", () => {
    profileModal.style.display = "flex";
});

closeModal.addEventListener("click", () => {
    profileModal.style.display = "none";
});

closeBtn.addEventListener("click", () => {
    profileModal.style.display = "none";
});

window.addEventListener("click", (e) => {
    if (e.target === profileModal) {
        profileModal.style.display = "none";
    }
});