/* ==========================================
   OPEN TICKET DETAILS MODAL
========================================== */

function openTicket(
    ticketId,
    subject,
    priority,
    raisedDate,
    reason
) {

    document.getElementById("ticketId").textContent = ticketId;
    document.getElementById("subject").textContent = subject;
    document.getElementById("priority").textContent = priority;
    document.getElementById("raisedDate").textContent = raisedDate;
    document.getElementById("reason").textContent = reason;

    document.getElementById("ticketModal").style.display = "flex";
}

/* ==========================================
   CLOSE MODAL
========================================== */

function closeModal() {
    document.getElementById("ticketModal").style.display = "none";
}

/* ==========================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
========================================== */

window.addEventListener("click", function (event) {

    const modal = document.getElementById("ticketModal");

    if (event.target === modal) {
        closeModal();
    }

});

/* ==========================================
   ESC KEY CLOSE MODAL
========================================== */

document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {
        closeModal();
    }

});

/* ==========================================
   STATUS FLOW
   Notified -> Resolved -> View
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    console.log("tickets.js loaded");

    const rows = document.querySelectorAll(".ticket-table tbody tr");

    rows.forEach(row => {

        const notifiedBtn = row.querySelector(".notified");
        const resolvedBtn = row.querySelector(".resolved");
        const viewBtn = row.querySelector(".view-btn");

        /* Initial State */

        if (resolvedBtn) {
            resolvedBtn.style.display = "none";
        }

        if (viewBtn) {
            viewBtn.style.display = "none";
        }

        /* STEP 1 */

        if (notifiedBtn) {

            notifiedBtn.addEventListener("click", function () {

                notifiedBtn.style.display = "none";

                if (resolvedBtn) {
                    resolvedBtn.style.display = "inline-block";
                }

                console.log("Notified clicked");

            });

        }

        /* STEP 2 */

        if (resolvedBtn) {

            resolvedBtn.addEventListener("click", function () {

                resolvedBtn.textContent = "Resolved";

                resolvedBtn.disabled = true;

                resolvedBtn.classList.add("completed");

                if (viewBtn) {
                    viewBtn.style.display = "inline-block";
                }

                console.log("Resolved clicked");

            });

        }

    });

});