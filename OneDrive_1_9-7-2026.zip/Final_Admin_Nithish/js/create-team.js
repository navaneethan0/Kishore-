/**
 * Create Team Logic for RPLMS Administrator
 */

document.addEventListener('DOMContentLoaded', () => {
    initCreateTeam();
});

let selectedLeader = null;
let selectedStaff = null;
let selectedMembers = [];
let memberCount = 3; // Starting with 3 as per wireframe

function initCreateTeam() {

    // Team Leader Search
    setupSearch('leaderSearch', 'leaderResults', 'student', (student) => {
        selectedLeader = student;
        document.getElementById('summaryLeader').textContent = student.name;
    });
    
    // Staff Search
    setupStaffSearch();

    setupMemberSearches();
    setupAddMember();
    setupDeadline();
    setupFinalCreation();
    setupReset();
}
function showSuccessToast(teamID) {

    const toast = document.getElementById('successToast');

    document.getElementById('toastMessage').textContent =
        `Team ID : ${teamID}`;

    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 4000);
}
function setupStaffSearch() {

    const input = document.getElementById('staffSearch');
    const results = document.getElementById('staffResults');

    if (!input || !results) return;

    const staffList = [
        {
            id: 1001,
            staffID: 'STF001',
            name: 'Dr. Arvind Kumar',
            department: 'AI & DS'
        },
        {
            id: 1002,
            staffID: 'STF002',
            name: 'Dr. Meena R',
            department: 'CSE'
        },
        {
            id: 1003,
            staffID: 'STF003',
            name: 'Dr. Karthik S',
            department: 'IT'
        },
        {
            id: 1004,
            staffID: 'STF004',
            name: 'Dr. Lakshmi N',
            department: 'ECE'
        },
        {
            id: 1005,
            staffID: 'STF005',
            name: 'Dr. Naveen P',
            department: 'AI & DS'
        },
        {
            id: 1006,
            staffID: 'STF006',
            name: 'Dr. Suresh M',
            department: 'CSE'
        },
        {
            id: 1007,
            staffID: 'STF007',
            name: 'Dr. Deepa V',
            department: 'IT'
        },
        {
            id: 1008,
            staffID: 'STF008',
            name: 'Dr. Vijay K',
            department: 'ECE'
        },
        {
            id: 1009,
            staffID: 'STF009',
            name: 'Dr. Anitha S',
            department: 'AI & DS'
        },
        {
            id: 1010,
            staffID: 'STF010',
            name: 'Dr. Ramesh T',
            department: 'CSE'
        }
    ];

    input.addEventListener('input', function () {

        const query = this.value.trim().toLowerCase();

        if (query.length < 1) {
            results.innerHTML = '';
            results.classList.remove('show');
            return;
        }

        const filtered = staffList.filter(staff =>
            staff.name.toLowerCase().includes(query) ||
            staff.staffID.toLowerCase().includes(query)
        );

        if (filtered.length === 0) {

            results.innerHTML = `
                <div class="result-item">
                    <span class="result-sub">
                        No results found
                    </span>
                </div>
            `;

        } else {

            results.innerHTML = filtered.map(staff => `
                <div class="result-item"
                     data-id="${staff.id}">
                    <span class="result-name">
                        ${staff.name}
                    </span>
                    <span class="result-sub">
                        ${staff.staffID} | ${staff.department}
                    </span>
                </div>
            `).join('');

            results.querySelectorAll('.result-item').forEach(item => {

                item.addEventListener('click', () => {

                    const selectedId =
                        parseInt(item.dataset.id);

                    const selected =
                        staffList.find(
                            s => s.id === selectedId
                        );

                    selectedStaff = selected;

                    input.value = selected.name;

                    document.getElementById('summaryStaff').textContent =
    selected.name;

                    results.classList.remove('show');
                });

            });

        }

        results.classList.add('show');

    });

    document.addEventListener('click', function (e) {

        if (
            !input.contains(e.target) &&
            !results.contains(e.target)
        ) {
            results.classList.remove('show');
        }

    });

}
function setupSearch(inputId, resultsId, type, onSelect) {
    const input = document.getElementById(inputId);
    const results = document.getElementById(resultsId);

    if (!input || !results) return;

    input.addEventListener('input', () => {

        const query = input.value.trim().toLowerCase();

        if (query.length < 2) {
            results.innerHTML = '';
            results.classList.remove('show');
            return;
        }

        const profiles = JSON.parse(
            localStorage.getItem('profiles') || '[]'
        );

        let filtered = [];

        if (type === 'student') {

            filtered = profiles.filter(profile => {

                const role = (profile.role || '').toLowerCase();

                return (
                    role.includes('student') &&
                    (
                        (profile.name || '')
                            .toLowerCase()
                            .includes(query) ||

                        (profile.rollNumber || '')
                            .toLowerCase()
                            .includes(query)
                    )
                );
            });

        } else if (type === 'staff') {

            filtered = profiles.filter(profile => {

                const role = (profile.role || '').toLowerCase();

                return (
                    role.includes('staff') ||
                    role.includes('faculty') ||
                    role.includes('technical')
                );

            }).filter(profile => {

                return (
                    (profile.name || '')
                        .toLowerCase()
                        .includes(query) ||

                    (profile.staffId || '')
                        .toLowerCase()
                        .includes(query) ||

                    (profile.employeeId || '')
                        .toLowerCase()
                        .includes(query)
                );

            });
        }

        renderResults(results, filtered, item => {

            input.value = item.name;

            results.classList.remove('show');

            onSelect(item);

        });

    });

    document.addEventListener('click', e => {

        if (
            !input.contains(e.target) &&
            !results.contains(e.target)
        ) {
            results.classList.remove('show');
        }

    });

}

function renderResults(container, items, onSelect) {

    if (!items || items.length === 0) {

        container.innerHTML = `
            <div class="result-item">
                <span class="result-sub">
                    No results found
                </span>
            </div>
        `;

        container.classList.add('show');
        return;
    }

    container.innerHTML = '';

    items.forEach(item => {

        const div = document.createElement('div');

        div.className = 'result-item';

        div.innerHTML = `
            <span class="result-name">
                ${item.name || 'Unnamed'}
            </span>

            <span class="result-sub">
                ${item.department || ''}
                ${item.rollNumber ? ' | ' + item.rollNumber : ''}
                ${item.staffId ? ' | ' + item.staffId : ''}
                ${item.employeeId ? ' | ' + item.employeeId : ''}
            </span>
        `;

        div.addEventListener('click', () => {
            onSelect(item);
        });

        container.appendChild(div);

    });

    container.classList.add('show');

}

/**
 * Member Specific Logic
 */
function setupMemberSearches() {
    const memberSearches = document.querySelectorAll('.member-search');
    memberSearches.forEach(input => {
        const results = input.nextElementSibling;
        const index = input.getAttribute('data-index');

        input.addEventListener('input', () => {
            const query = input.value.toLowerCase();
            if (query.length < 2) {
                results.classList.remove('show');
                return;
            }

            const profiles = JSON.parse(localStorage.getItem('profiles') || '[]');
            const filtered = profiles.filter(p => 
                p.role.toLowerCase() === 'student' && 
                (p.name.toLowerCase().includes(query) || (p.rollNumber && p.rollNumber.toLowerCase().includes(query)))
            );

            renderResults(results, filtered, (item) => {
                input.value = item.name;
                results.classList.remove('show');
                selectedMembers[index - 1] = item;
                updateMemberSummary();
            });
        });
    });
}

function updateMemberSummary() {
    const count = selectedMembers.filter(m => m).length;
    document.getElementById('summaryMembers').textContent = count > 0 ? `${count} members added` : 'No members added';
    document.getElementById('memberCountBadge').textContent = `${count} / 15 members added`;
}

function setupAddMember() {
    const addBtn = document.getElementById('addMemberBtn');
    addBtn.addEventListener('click', () => {
        if (memberCount >= 15) {
            alert('Maximum 15 members allowed');
            return;
        }

        memberCount++;
        const container = document.getElementById('memberInputsContainer');
        const row = document.createElement('div');
        row.className = 'member-input-row';
        row.id = `row-${memberCount}`;
        row.innerHTML = `
            <span class="member-label">Member ${memberCount}</span>
            <div class="search-container">
                <input type="text" class="search-input member-search" placeholder="Search by name or roll number..." data-index="${memberCount}">
                <div class="dropdown-results"></div>
            </div>
        `;
        container.appendChild(row);
        setupMemberSearches(); // Re-bind for new input
    });
}

/**
 * Deadline Logic
 */
function setupDeadline() {
    const input = document.getElementById('deadlineDate');
    input.addEventListener('change', () => {
        document.getElementById('summaryDeadline').textContent = input.value || 'Not selected';
    });
}

/**
 * Team Creation logic
 */
function setupFinalCreation() {
    document.getElementById('createTeamBtn').addEventListener('click', () => {
        const leaderSearchEl = document.getElementById('leaderSearch');
        const staffSearchEl = document.getElementById('staffSearch');
        const deadlineEl = document.getElementById('deadlineDate');

        const teamContainer = document.querySelector('.steps-scroll-container');

        if (!runValidations([
            () => selectedLeader
                ? { valid: true }
                : { valid: false, message: 'Please select a Team Leader.', field: leaderSearchEl },
            () => selectedMembers.filter(m => m).length > 0
                ? { valid: true }
                : { valid: false, message: 'Please add at least one member.', field: document.querySelector('.member-search') },
            () => selectedStaff
                ? { valid: true }
                : { valid: false, message: 'Please assign a Technical Staff.', field: staffSearchEl },
            () => validateDate(deadlineEl.value, 'Deadline', deadlineEl, { required: true, notPast: true })
        ], teamContainer)) {
            return;
        }

        const teamID = `TEAM-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
        
        const team = {
            id: Date.now(),
            teamID: teamID,
            leader: selectedLeader,
            members: selectedMembers.filter(m => m),
            staff: selectedStaff,
            deadline: document.getElementById('deadlineDate').value,
            status: 'In Progress',
            createdAt: new Date().toISOString()
        };

        // Save to LocalStorage
        let teams = JSON.parse(localStorage.getItem('teams') || '[]');
        teams.unshift(team);
        localStorage.setItem('teams', JSON.stringify(teams));

        // Show Success
        document.getElementById('generatedTeamID').textContent = teamID;
        clearFormValidation(teamContainer);
        showSuccessToast(teamID);
    });
}

function closeModal() {
    document.getElementById('successModal').classList.remove('show');
    // window.location.href = 'dashboard.html'; // Optional redirect
}

function setupReset() {
    document.getElementById('resetBtn').addEventListener('click', () => {
        if(confirm('Are you sure you want to reset all fields?')) {
            window.location.reload();
        }
    });
}
