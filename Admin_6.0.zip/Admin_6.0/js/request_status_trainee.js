﻿/**
 * ============================================================
 * ILP RAPID PROTOTYPING LAB – REQUEST STATUS MANAGEMENT
 * request_status.js
 * ============================================================
 */

'use strict';

// Ensure window.__RPL_DB__ is initialized
if (!window.__RPL_DB__) {
    // Fallback if mock_data.js was not loaded first
    try {
        const stored = localStorage.getItem('__RPL_DB__');
        if (stored) {
            window.__RPL_DB__ = JSON.parse(stored);
        } else {
            window.__RPL_DB__ = {};
        }
    } catch (e) {
        window.__RPL_DB__ = {};
    }
}

// Initialize database requests if not exists
if (!window.__RPL_DB__.requests) {
    window.__RPL_DB__.requests = [
        {
            id: 1,
            requestId: 'REQ-001',
            requesterName: 'Rahul Sharma',
            userType: 'Trainee',
            assetName: '3D Printer',
            category: 'equipment',
            quantity: 1,
            requestDate: '2026-07-10',
            status: 'Pending',
            remarks: 'For team project enclosure printing'
        },
        {
            id: 2,
            requestId: 'REQ-002',
            requesterName: 'Dr. Anand',
            userType: 'Faculty',
            assetName: 'Arduino Uno',
            category: 'components',
            quantity: 5,
            requestDate: '2026-07-11',
            status: 'Approved',
            remarks: 'Sensor expansion pack testing'
        },
        {
            id: 3,
            requestId: 'REQ-003',
            requesterName: 'Amit Kumar',
            userType: 'Trainee',
            assetName: 'Screw Driver Set',
            category: 'tools',
            quantity: 2,
            requestDate: '2026-07-12',
            status: 'Rejected',
            remarks: 'Tool already in possession'
        },
        {
            id: 4,
            requestId: 'REQ-004',
            requesterName: 'Dr. Sophia',
            userType: 'Faculty',
            assetName: 'Laser Cutter',
            category: 'equipment',
            quantity: 1,
            requestDate: '2026-07-12',
            status: 'Pending',
            remarks: 'Acrylic panels engraving'
        },
        {
            id: 5,
            requestId: 'REQ-005',
            requesterName: 'Priya Patel',
            userType: 'Trainee',
            assetName: 'Raspberry Pi 4',
            category: 'components',
            quantity: 2,
            requestDate: '2026-07-12',
            status: 'Pending',
            remarks: 'Smart mirror dashboard assembly'
        }
    ];
    localStorage.setItem('__RPL_DB__', JSON.stringify(window.__RPL_DB__));
}

// Local references to requests
let requestsData = window.__RPL_DB__.requests;

function saveData() {
    window.__RPL_DB__.requests = requestsData;
    localStorage.setItem('__RPL_DB__', JSON.stringify(window.__RPL_DB__));
}

/* ============================================================
   STATE
   ============================================================ */
let currentCategory = 'equipment'; // 'equipment' | 'components' | 'tools'
let editingId = null;               // null = add mode, integer = edit mode
let currentPage = 1;
const ROWS_PER_PAGE = 5;

/* ============================================================
   DOM REFERENCES
   ============================================================ */
const searchInput = document.getElementById('searchInput');
const traineeFilter = document.getElementById('traineeFilter');
const facultyFilter = document.getElementById('facultyFilter');
const addAssetBtn = document.getElementById('addAssetBtn');
const addAssetBtnText = document.getElementById('addAssetBtnText');
const tableHead = document.getElementById('tableHead');
const tableBody = document.getElementById('tableBody');
const emptyState = document.getElementById('emptyState');
const tableTitle = document.getElementById('tableTitle');
const tableCount = document.getElementById('tableCount');
const paginationInfo = document.getElementById('paginationInfo');
const paginationCtrl = document.getElementById('paginationControls');

// Modal DOM
const equipmentModal = document.getElementById('equipmentModal');
const modalHeading = document.getElementById('modalHeading');
const modalSubheading = document.getElementById('modalSubheading');
const closeModalBtn = document.getElementById('closeModalBtn');
const cancelModalBtn = document.getElementById('cancelModalBtn');
const submitModalBtn = document.getElementById('submitModalBtn');
const submitBtnLabel = document.getElementById('submitBtnLabel');
const equipmentForm = document.getElementById('equipmentForm');

// Form fields
const fEqpTypeId = document.getElementById('fEqpTypeId'); // Request ID
const fMake = document.getElementById('fMake');           // Requester Name select
const fSpecification = document.getElementById('fSpecification'); // Requester Role
const fName = document.getElementById('fName');           // Asset Name
const fQuantity = document.getElementById('fQuantity');   // Qty
const fLab = document.getElementById('fLab');             // Date
const fComponentType = document.getElementById('fComponentType'); // Status select
const fRemarks = document.getElementById('fRemarks');     // Purpose

// Error spans
const errEqpTypeId = document.getElementById('errEqpTypeId');
const errMake = document.getElementById('errMake');
const errName = document.getElementById('errName');
const errQuantity = document.getElementById('errQuantity');
const errLab = document.getElementById('errLab');

// Toast
const toastContainer = document.getElementById('toastContainer');

// Sidebar (Mobile hamburger toggle)
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const hamburgerBtn = document.getElementById('hamburgerBtn');

/* ============================================================
   COLUMN DEFINITIONS
   ============================================================ */
const REQUEST_COLUMNS = [
    { key: 'id', label: 'Sl No' },
    { key: 'requestId', label: 'Request ID' },
    { key: 'requesterName', label: 'Requester Name' },
    { key: 'userType', label: 'Role' },
    { key: 'assetName', label: 'Asset Name' },
    { key: 'quantity', label: 'Qty' },
    { key: 'requestDate', label: 'Request Date' },
    { key: 'status', label: 'Status' },
    { key: 'remarks', label: 'Purpose' },
    { key: '_actions', label: 'Actions' },
];

/* ============================================================
   UTILITY
   ============================================================ */

/** Returns data filtered by category */
function getActiveData() {
    return requestsData.filter(r => r.category === currentCategory);
}

/** Returns the human-readable category title */
function getCategoryTitle() {
    if (currentCategory === 'equipment') return 'Equipment Requests';
    if (currentCategory === 'components') return 'Component Requests';
    return 'Tool Requests';
}

/** Show a toast message */
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? 'check-circle' : 'x-circle';
    toast.innerHTML = `<i data-lucide="${icon}"></i><span>${message}</span>`;
    toastContainer.appendChild(toast);
    lucide.createIcons();
    setTimeout(() => toast.remove(), 3200);
}

/** Escape HTML to prevent XSS */
function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/* ============================================================
   SEARCH AND FILTER LOGIC
   ============================================================ */

/** Filter dataset using search query and Trainee/Faculty dropdowns */
function getFilteredData() {
    let data = getActiveData().filter(row => row.userType === 'Trainee');

    // 1. Search Query filter
    const q = searchInput.value.trim().toLowerCase();
    if (q) {
        data = data.filter(row =>
            Object.values(row).some(v => String(v).toLowerCase().includes(q))
        );
    }

    return data;
}

/* ============================================================
   TABLE RENDERING
   ============================================================ */

function renderHead() {
    tableHead.innerHTML = `
    <tr>
      ${REQUEST_COLUMNS.map(c => `<th>${c.label}</th>`).join('')}
    </tr>
  `;
}

function renderCell(col, row) {
    if (col.key === '_actions') {
        return `
      <td>
        <button class="edit-btn" aria-label="Edit request" onclick="openEditModal(${row.id})">
          <i data-lucide="pencil"></i>
        </button>
      </td>
    `;
    }
    if (col.key === 'status') {
        const val = row[col.key] || 'Pending';
        let cls = 'badge-warning';
        if (val === 'Approved') cls = 'badge-success';
        else if (val === 'Rejected') cls = 'badge-danger';
        return `<td><span class="badge ${cls}">${esc(val)}</span></td>`;
    }
    return `<td>${esc(row[col.key])}</td>`;
}

function renderTable() {
    const filtered = getFilteredData();

    // Clamp currentPage
    const totalPages = Math.max(1, Math.ceil(filtered.length / ROWS_PER_PAGE));
    if (currentPage > totalPages) currentPage = totalPages;

    const start = (currentPage - 1) * ROWS_PER_PAGE;
    const pageRows = filtered.slice(start, start + ROWS_PER_PAGE);

    renderHead();

    tableTitle.textContent = getCategoryTitle();
    tableCount.textContent = `Showing ${filtered.length} record${filtered.length !== 1 ? 's' : ''}`;

    if (filtered.length === 0) {
        tableBody.innerHTML = '';
        emptyState.classList.remove('hidden');
        document.querySelector('.table-responsive table').style.display = 'none';
    } else {
        emptyState.classList.add('hidden');
        document.querySelector('.table-responsive table').style.display = '';

        tableBody.innerHTML = pageRows.map((row, idx) => {
            const displayRow = { ...row, id: start + idx + 1 };
            // Ensure the raw ID matches for onclick actions
            displayRow._rawId = row.id;
            return `<tr>${REQUEST_COLUMNS.map(c => {
                if (c.key === '_actions') {
                    return `
                      <td>
                        <button class="edit-btn" aria-label="Edit request" onclick="openEditModal(${row.id})">
                          <i data-lucide="pencil"></i>
                        </button>
                      </td>
                    `;
                }
                return renderCell(c, displayRow);
            }).join('')}</tr>`;
        }).join('');
    }

    lucide.createIcons();
    renderPagination(filtered.length, totalPages);
}

/* ============================================================
   PAGINATION
   ============================================================ */

function renderPagination(total, totalPages) {
    const start = (currentPage - 1) * ROWS_PER_PAGE + 1;
    const end = Math.min(currentPage * ROWS_PER_PAGE, total);

    paginationInfo.textContent = total > 0
        ? `Showing ${start}–${end} of ${total} records`
        : 'No records';

    let html = '';

    html += `
    <button class="page-btn" id="prevPageBtn" ${currentPage <= 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">
      <i data-lucide="chevron-left"></i>
    </button>
  `;

    for (let p = 1; p <= totalPages; p++) {
        if (
            p === 1 || p === totalPages ||
            (p >= currentPage - 1 && p <= currentPage + 1)
        ) {
            html += `<button class="page-btn${p === currentPage ? ' active' : ''}" onclick="changePage(${p})">${p}</button>`;
        } else if (p === currentPage - 2 || p === currentPage + 2) {
            html += `<span style="padding:0 4px;color:var(--text-muted)">…</span>`;
        }
    }

    html += `
    <button class="page-btn" ${currentPage >= totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">
      <i data-lucide="chevron-right"></i>
    </button>
  `;

    paginationCtrl.innerHTML = html;
    lucide.createIcons();
}

window.changePage = function (page) {
    currentPage = page;
    renderTable();
};

/* ============================================================
   CATEGORY TOGGLE
   ============================================================ */

document.getElementById('categoryToggle').addEventListener('click', e => {
    const btn = e.target.closest('.toggle-btn');
    if (!btn) return;

    document.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    currentCategory = btn.dataset.category;
    currentPage = 1;
    searchInput.value = '';

    // Reset filters
    if (traineeFilter) traineeFilter.value = 'All';
    if (facultyFilter) facultyFilter.value = 'All';

    // Update Add button text
    if (currentCategory === 'equipment') {
        addAssetBtnText.textContent = 'Raise Request';
    } else if (currentCategory === 'components') {
        addAssetBtnText.textContent = 'Raise Request';
    } else {
        addAssetBtnText.textContent = 'Raise Request';
    }

    renderTable();
    updateStats();
});

/* ============================================================
   LIVE FILTERS EVENT HANDLERS
   ============================================================ */

// Live Search
searchInput.addEventListener('input', () => {
    currentPage = 1;
    renderTable();
});

// Trainee Dropdown Change
if (traineeFilter) {
    traineeFilter.addEventListener('change', () => {
        currentPage = 1;
        if (traineeFilter.value !== 'All' && facultyFilter) {
            facultyFilter.value = 'All'; // mutually exclusive filter reset
        }
        renderTable();
    });
}

// Faculty Dropdown Change
if (facultyFilter) {
    facultyFilter.addEventListener('change', () => {
        currentPage = 1;
        if (facultyFilter.value !== 'All' && traineeFilter) {
            traineeFilter.value = 'All'; // mutually exclusive filter reset
        }
        renderTable();
    });
}

/* ============================================================
   MODAL - OPEN / CLOSE & ACTIONS
   ============================================================ */

/** Clear modal form fields */
function clearForm() {
    fEqpTypeId.value = 'REQ-' + String(Math.floor(100 + Math.random() * 900));
    fMake.value = '';
    fSpecification.value = 'Trainee';
    fName.value = '';
    fQuantity.value = '1';
    fLab.value = new Date().toISOString().split('T')[0];
    fComponentType.value = 'Pending';
    fRemarks.value = '';

    const countSpan = document.getElementById('charCount');
    if (countSpan) countSpan.textContent = '0';
}

/** Hides/clear error borders */
function clearErrors() {
    [fEqpTypeId, fMake, fName, fQuantity, fLab].forEach(el => {
        if (el) el.classList.remove('error');
    });
    [errEqpTypeId, errMake, errName, errQuantity, errLab].forEach(span => {
        if (span) span.textContent = '';
    });
}

function validateField(el, span, text) {
    if (!el.value.trim()) {
        el.classList.add('error');
        if (span) span.textContent = text;
        return false;
    }
    if (el === fQuantity && (isNaN(Number(el.value)) || Number(el.value) <= 0)) {
        el.classList.add('error');
        if (span) span.textContent = 'Quantity must be positive';
        return false;
    }
    el.classList.remove('error');
    if (span) span.textContent = '';
    return true;
}

function validateForm() {
    let isValid = true;
    if (!validateField(fEqpTypeId, errEqpTypeId, 'Request ID is required')) isValid = false;
    if (!validateField(fMake, errMake, 'Requester is required')) isValid = false;
    if (!validateField(fName, errName, 'Asset Name is required')) isValid = false;
    if (!validateField(fQuantity, errQuantity, 'Quantity is required')) isValid = false;
    if (!validateField(fLab, errLab, 'Request Date is required')) isValid = false;
    return isValid;
}

// Auto-fill requester role on selection
fMake.addEventListener('change', () => {
    fSpecification.value = 'Trainee';
});

// Character Counter
fRemarks.addEventListener('input', () => {
    const countSpan = document.getElementById('charCount');
    if (countSpan) countSpan.textContent = fRemarks.value.length;
});

// Open Add modal
addAssetBtn.addEventListener('click', () => {
    editingId = null;
    modalHeading.textContent = 'Raise Request';
    modalSubheading.textContent = 'Request Information · Create new Request';
    submitBtnLabel.textContent = 'Submit Request';

    clearForm();
    clearErrors();

    // Set auto-generated request ID
    const maxId = requestsData.length > 0 ? Math.max(...requestsData.map(r => r.id)) + 1 : 1;
    fEqpTypeId.value = `REQ-` + String(maxId).padStart(3, '0');

    equipmentModal.classList.add('active');
    lucide.createIcons();
    fMake.focus();
});

// Close modal handlers
function closeModal() {
    equipmentModal.classList.remove('active');
    editingId = null;
}

closeModalBtn.addEventListener('click', closeModal);
cancelModalBtn.addEventListener('click', closeModal);

equipmentModal.addEventListener('click', e => {
    if (e.target === equipmentModal) closeModal();
});

document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && equipmentModal.classList.contains('active')) closeModal();
});

// Edit modal open script
window.openEditModal = function (id) {
    editingId = id;
    const row = requestsData.find(r => r.id === id);
    if (!row) return;

    modalHeading.textContent = 'Update Request';
    modalSubheading.textContent = 'Request Information · Modify Request Details';
    submitBtnLabel.textContent = 'Save Changes';

    clearErrors();

    // Populate fields
    fEqpTypeId.value = row.requestId || '';
    fMake.value = row.requesterName || '';
    fSpecification.value = row.userType || '';
    fName.value = row.assetName || '';
    fQuantity.value = row.quantity || '';
    fLab.value = row.requestDate || '';
    fComponentType.value = row.status || 'Pending';
    fRemarks.value = row.remarks || '';

    const countSpan = document.getElementById('charCount');
    if (countSpan) countSpan.textContent = (row.remarks || '').length;

    equipmentModal.classList.add('active');
    lucide.createIcons();
};

/* ============================================================
   SUBMIT FORM ACTION
   ============================================================ */

submitModalBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    const reqData = {
        requestId: fEqpTypeId.value.trim(),
        requesterName: fMake.value.trim(),
        userType: 'Trainee',
        assetName: fName.value.trim(),
        category: currentCategory,
        quantity: parseInt(fQuantity.value.trim(), 10),
        requestDate: fLab.value.trim(),
        status: fComponentType.value,
        remarks: fRemarks.value.trim()
    };

    if (editingId === null) {
        // Add new
        const newId = requestsData.length > 0 ? Math.max(...requestsData.map(r => r.id)) + 1 : 1;
        requestsData.push({
            id: newId,
            ...reqData
        });
        showToast('Request submitted successfully!', 'success');
    } else {
        // Edit existing
        const idx = requestsData.findIndex(r => r.id === editingId);
        if (idx !== -1) {
            requestsData[idx] = {
                ...requestsData[idx],
                ...reqData
            };
            showToast('Request updated successfully!', 'success');
        }
    }

    saveData();
    closeModal();
    renderTable();
    updateStats();
});

/* ============================================================
   STATS UPDATE
   ============================================================ */

function updateStats() {
    const activeRequests = requestsData.filter(r => r.category === currentCategory && r.userType === 'Trainee');

    // Total requests in current category
    document.getElementById('statTotal').textContent = activeRequests.length;

    // Approved requests in current category
    document.getElementById('statAvailable').textContent = activeRequests.filter(r => r.status === 'Approved').length;

    // Pending requests in current category
    document.getElementById('statMaintenance').textContent = activeRequests.filter(r => r.status === 'Pending').length;
}

/* ============================================================
   INITIALISATION ON LOAD
   ============================================================ */

// Register sidebar layout toggle listener
if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
    });
}
if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('active');
    });
}

// Register dropdown menu toggles
document.querySelectorAll('.dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const targetId = btn.getAttribute('aria-controls');
        const group = btn.closest('.nav-group') || btn.closest('.nav-dropdown');
        const menu = document.getElementById(targetId) || (group ? group.querySelector('.dropdown-menu') : null);
        const isActive = btn.classList.contains('active');

        document.querySelectorAll('.dropdown-toggle').forEach(t => {
            t.classList.remove('active');
            t.setAttribute('aria-expanded', 'false');
        });
        document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));
        document.querySelectorAll('.sub-dropdown-toggle').forEach(t => {
            t.classList.remove('active');
            t.setAttribute('aria-expanded', 'false');
        });
        document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));

        if (!isActive) {
            btn.classList.add('active');
            btn.setAttribute('aria-expanded', 'true');
            if (menu) menu.classList.add('active');
        }
    });
});

// Register sub-dropdown menu toggles
document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const targetId = btn.getAttribute('aria-controls');
        const group = btn.closest('.nav-subgroup');
        const menu = document.getElementById(targetId) || (group ? group.querySelector('.sub-dropdown-menu') : null);
        const isActive = btn.classList.contains('active');

        if (menu) {
            if (isActive) {
                btn.classList.remove('active');
                btn.setAttribute('aria-expanded', 'false');
                menu.classList.remove('active');
            } else {
                btn.classList.add('active');
                btn.setAttribute('aria-expanded', 'true');
                menu.classList.add('active');
            }
        }
    });
});

// Run initial rendering
renderTable();
updateStats();
