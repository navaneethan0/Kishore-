// Equipment Approvals Redesigned Controller

document.addEventListener("DOMContentLoaded", () => {
    let db = getDB();

    const cardsGrid = document.getElementById("trackingCardsGrid");

    function getTeamOverallStatus(requests) {
        if (requests.some(r => r.status === "Rejected")) {
            return "rejected";
        }
        if (requests.every(r => r.status === "Approved")) {
            return "approved";
        }
        return "pending";
    }

    function renderCards() {
        db = getDB();
        const requests = db.equipmentRequests || [];

        if (requests.length === 0) {
            cardsGrid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 48px; background: #fff; border-radius: 12px; box-shadow: var(--shadow);">
                    <div style="font-size: 48px; margin-bottom: 16px;">📋</div>
                    <h3 style="margin: 0; font-size: 18px; color: #1F2937;">No Equipment Requests Found</h3>
                    <p style="color: #6B7280; margin: 8px 0 0 0;">There are no active team equipment requests at this time.</p>
                </div>
            `;
            return;
        }

        cardsGrid.innerHTML = requests.map(team => {
            const overallStatus = getTeamOverallStatus(team.requests);
            let badgeClass = "pending";
            if (overallStatus === "approved") badgeClass = "approved";
            if (overallStatus === "rejected") badgeClass = "rejected";

            return `
                <div class="req-card">
                    <div class="card-header">
                        <span class="team-id-badge">${team.teamId}</span>
                        <span class="badge ${badgeClass}">${overallStatus}</span>
                    </div>
                    <div class="card-body">
                        <h3 class="team-name">${team.teamName}</h3>
                    </div>
                    <div class="card-actions">
                        <a href="equipment-details.html?teamId=${team.teamId}" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            `;
        }).join("");
    }

    renderCards();
});