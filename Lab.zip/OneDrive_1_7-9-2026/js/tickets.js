// Enquiry Management Controller Redesigned

document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("ticketsTableBody");

  function getEnquiryRequiredItems(db) {
    const list = [];

    // Cost/value lookup dictionary for items
    const costMap = {
      "3d printer": 25000,
      "cnc milling machine": 32000,
      "cnc machine": 32000,
      "laser cutter": 18000,
      "3d scanner": 35000,
      "digital oscilloscope": 15000,
      "bench multimeter": 12000,
      "soldering station": 8500,
      "hot air rework station": 14000,
      "variable dc power supply": 6500,
      "arduino uno": 850,
      "arduino uno r3": 850,
      "raspberry pi 4": 7000,
      "ultrasonic sensor": 250,
      "soil moisture sensor": 150,
      "dc motor 12v": 350,
      "16x2 lcd display": 250,
      "li-ion battery 18650": 300,
      "bipolar nema 17": 1250,
      "lipo battery 11.1v": 2200,
      "pir motion sensor": 180,
      "co2 laser tube": 9500,
      "screw driver set": 2500,
      "soldering iron": 3200
    };

    function getItemCost(name) {
      const cleanName = name.toLowerCase().trim();
      if (costMap[cleanName]) return costMap[cleanName];

      // Also check DB components/tools
      const comp = db.components.find(c => c.componentName.toLowerCase() === cleanName);
      if (comp && comp.cost) return comp.cost;

      const tool = db.tools.find(t => t.componentName.toLowerCase() === cleanName);
      if (tool && tool.cost) return tool.cost;

      return 500; // default generic fallback cost
    }

    function getItemIdAndType(name) {
      const cleanName = name.toLowerCase().trim();
      // Check db.inventory
      let inv = db.inventory.find(i => i.name.toLowerCase() === cleanName);
      if (inv) {
        return { id: inv.id, type: inv.type };
      }
      // Check db.components
      let comp = db.components.find(c => c.componentName.toLowerCase() === cleanName);
      if (comp) {
        return { id: comp.cid, type: "Component" };
      }
      // Check db.tools
      let tool = db.tools.find(t => t.componentName.toLowerCase() === cleanName);
      if (tool) {
        return { id: tool.toolid, type: "Tool" };
      }
      // Check db.equipment
      let eqp = db.equipment.find(e => (e.name || e.componentName || "").toLowerCase() === cleanName);
      if (eqp) {
        return { id: eqp.eqpid, type: "Equipment" };
      }
      return { id: "EQ-N/A", type: "Component" };
    }

    // 1. Sourcing from materialReturns (items not returned or damaged)
    (db.materialReturns || []).forEach(r => {
      const isNotReturned = r.status !== "Returned";
      const isDamaged = r.isGood === false;

      if (isNotReturned || isDamaged) {
        const { id: itemId, type: itemType } = getItemIdAndType(r.item);
        const amount = getItemCost(r.item);

        list.push({
          source: "return",
          refId: r.id,
          teamId: r.teamId,
          teamName: r.teamName,
          itemType: itemType,
          itemId: itemId,
          itemName: r.item,
          amount: amount,
          ticketRaised: r.ticketRaised || false
        });
      }
    });

    // 2. Sourcing from equipmentRequests (rejected equipment requests)
    (db.equipmentRequests || []).forEach(team => {
      (team.requests || []).forEach(req => {
        if (req.status === "Rejected") {
          const amount = getItemCost(req.equipmentName);

          list.push({
            source: "equipment_request",
            refId: req.id,
            teamId: team.teamId,
            teamName: team.teamName,
            itemType: "Equipment",
            itemId: req.equipmentId,
            itemName: req.equipmentName,
            amount: amount,
            ticketRaised: req.ticketRaised || false
          });
        }
      });
    });

    return list;
  }

  function renderTable() {
    const db = getDB();
    const items = getEnquiryRequiredItems(db);

    if (items.length === 0) {
      tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 48px 16px; color: #6B7280; font-weight: 500;">
                        No items require enquiry at this time.
                    </td>
                </tr>
            `;
      return;
    }

    tableBody.innerHTML = items.map(item => {
      const actionButton = item.ticketRaised
        ? `<button class="btn btn-disabled" disabled>Ticket Raised</button>`
        : `<button class="btn btn-primary" onclick="raiseTicketForItem('${item.source}', '${item.refId}', '${item.teamId}', '${item.itemName}')">Raise Ticket</button>`;

      return `
                <tr>
                    <td style="font-weight: 700; color: #4B5563;">${item.teamId}</td>
                    <td style="font-weight: 600; color: #111827;">${item.teamName}</td>
                    <td>${item.itemType}</td>
                    <td style="font-family: monospace; font-weight: 700; color: #374151;">${item.itemId}</td>
                    <td style="font-weight: 600; color: #1F2937;">${item.itemName}</td>
                    <td style="font-weight: 700; color: #10B981;">&#8377; ${item.amount.toLocaleString()}</td>
                    <td style="text-align: center;">${actionButton}</td>
                </tr>
            `;
    }).join("");
  }

  window.raiseTicketForItem = function (source, refId, teamId, itemName) {
    let db = getDB();

    // 1. Mark corresponding item as ticketRaised = true
    if (source === "return") {
      const rIndex = db.materialReturns.findIndex(r => r.id === refId);
      if (rIndex > -1) {
        db.materialReturns[rIndex].ticketRaised = true;
      }
    } else if (source === "equipment_request") {
      db.equipmentRequests.forEach(team => {
        const req = team.requests.find(r => r.id === refId);
        if (req) {
          req.ticketRaised = true;
        }
      });
    }

    // 2. Append new ticket under db.tickets
    const nextNum = db.tickets.length + 1;
    const newId = `TKT-${String(nextNum).padStart(3, "0")}`;
    const today = new Date();
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const dateStr = `${String(today.getDate()).padStart(2, "0")} ${months[today.getMonth()]} ${today.getFullYear()}`;
    const timeStr = today.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });

    const teamName = db.teams.find(t => t.id === teamId)?.name || "Smart Irrigation System";

    const newTicket = {
      id: newId,
      type: "Damage",
      assignedTo: teamId,
      subject: `${itemName} Enquiry`,
      priority: "High",
      date: dateStr,
      status: "Open",
      teamName: teamName,
      equipmentName: itemName,
      raisedBy: "Lab Incharge",
      time: timeStr,
      damageDescription: `Enquiry generated for outstanding/faulty/rejected item: ${itemName}.`,
      fineAmount: "0",
      dueDate: "",
      remarks: "Auto-generated Enquiry ticket.",
      teamResponse: "",
      lastUpdated: `${dateStr}, ${timeStr}`
    };

    db.tickets.push(newTicket);
    setDB(db);

    // 3. Display Toast and Refresh Table
    showToast("Ticket Raised Successfully.", "success");
    renderTable();
  };

  renderTable();
});
