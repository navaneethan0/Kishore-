import re

with open("/Users/nandhu/Downloads/Admin_6.0 2/js/ticket_management.js", "r") as f:
    text = f.read()

mock_data_js = """
  // Ensure mock data exists so dropdowns and tables aren't empty
  (function initMockData() {
    var db = getDB();
    let updated = false;
    
    if (!db.teams || db.teams.length === 0) {
      db.teams = [
        { id: "TEAM-001", name: "Alpha Squad" },
        { id: "TEAM-002", name: "Beta Innovators" },
        { id: "TEAM-003", name: "Gamma Creators" }
      ];
      updated = true;
    }
    
    if (!db.inventory || db.inventory.length === 0) {
      db.inventory = [];
      // Combine equipment/components/tools as inventory for the mock
      (db.equipment || []).forEach(e => db.inventory.push({ id: e.eqpid, name: e.componentName || e.name, type: "Equipment", status: e.status }));
      (db.components || []).forEach(c => db.inventory.push({ id: c.cid, name: c.componentName || c.name, type: "Component", status: c.status }));
      (db.tools || []).forEach(t => db.inventory.push({ id: t.toolid, name: t.componentName || t.name, type: "Tool", status: t.status }));
      
      // Fallback if common.js is also empty
      if (db.inventory.length === 0) {
        db.inventory = [
          { id: "EQP-001", name: "3D Printer", type: "Equipment", status: "Available" },
          { id: "EQP-002", name: "Laser Cutter", type: "Equipment", status: "Maintenance" },
          { id: "TL-055", name: "Soldering Station", type: "Tool", status: "Available" }
        ];
      }
      updated = true;
    }
    
    if (!db.tickets || db.tickets.length === 0) {
      db.tickets = [
        {
          id: "TKT-001", type: "Damage", assignedTo: "TEAM-001", subject: "3D Printer Jam", 
          priority: "High", date: "10 Jul 2026", status: "Open", teamName: "Alpha Squad", 
          equipmentName: "3D Printer", raisedBy: "Lab Incharge", time: "10:30 AM", 
          damageDescription: "Nozzle is clogged completely.", fineAmount: "0", 
          dueDate: "17 Jul 2026", remarks: "", lastUpdated: "10 Jul 2026, 10:30 AM", timeSlot: "10:00 - 11:00"
        }
      ];
      updated = true;
    }
    
    if (updated && typeof setDB === 'function') setDB(db);
  })();

"""

text = re.sub(r'(document\.addEventListener\("DOMContentLoaded", function\s*\(\)\s*\{)', r'\1\n' + mock_data_js, text, 1)

with open("/Users/nandhu/Downloads/Admin_6.0 2/js/ticket_management.js", "w") as f:
    f.write(text)

print("Injected successfully")
