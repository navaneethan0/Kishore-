import re

with open("/Users/nandhu/Downloads/low-stock-alerts (1).html", "r") as f:
    text = f.read()

# find everything after </main>
match = re.search(r'</main>(.*?)<script>', text, re.DOTALL)
if match:
    with open("/Users/nandhu/Downloads/Admin_6.0 2/pages/low_stock_extra.html", "w") as f:
        f.write(match.group(1).strip())
