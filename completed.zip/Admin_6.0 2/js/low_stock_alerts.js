/* =========================================================
   DATA MODEL
   ========================================================= */
function mulberry32(seed){
  return function(){
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20260709);
function pick(arr){ return arr[Math.floor(rnd()*arr.length)]; }
function randInt(min,max){ return Math.floor(rnd()*(max-min+1))+min; }

const LABS = ["Electronics Lab","Mechanical Lab","Robotics Lab","Fabrication Lab","IoT Lab"];
const LOCATIONS = ["Rack A-1","Rack A-3","Cabinet B-1","Cabinet B-4","Shelf C-2","Bin D-4","Store Room E-1","Drawer F-2"];

const ITEM_TEMPLATES = [
  {name:"PLA Filament (Black) 1kg", cat:"3D Printing", unit:"spools"},
  {name:"PETG Filament (White) 1kg", cat:"3D Printing", unit:"spools"},
  {name:"Resin — Standard Clear 500ml", cat:"3D Printing", unit:"bottles"},
  {name:"3D Printer Nozzle 0.4mm Brass", cat:"3D Printing", unit:"pcs"},
  {name:"Build Plate Adhesive Spray", cat:"3D Printing", unit:"cans"},
  {name:"Arduino Uno R3", cat:"Electronics", unit:"pcs"},
  {name:"ESP32 DevKit V1", cat:"Electronics", unit:"pcs"},
  {name:"Raspberry Pi 4 (4GB)", cat:"Electronics", unit:"pcs"},
  {name:"Resistor Kit (1/4W Assorted)", cat:"Electronics", unit:"kits"},
  {name:"Jumper Wires (M-M) 40pc Pack", cat:"Electronics", unit:"packs"},
  {name:"Breadboard Full-size", cat:"Electronics", unit:"pcs"},
  {name:"Soldering Wire 60/40 100g", cat:"Electronics", unit:"rolls"},
  {name:"Ultrasonic Sensor (HC-SR04)", cat:"Sensors", unit:"pcs"},
  {name:"IR Proximity Sensor", cat:"Sensors", unit:"pcs"},
  {name:"Load Cell 5kg", cat:"Sensors", unit:"pcs"},
  {name:"IMU Module MPU6050", cat:"Sensors", unit:"pcs"},
  {name:"Servo Motor SG90", cat:"Mechanical", unit:"pcs"},
  {name:"M3 Hex Bolts (20mm) Pack", cat:"Mechanical", unit:"packs"},
  {name:"Ball Bearing 608ZZ", cat:"Mechanical", unit:"pcs"},
  {name:"Aluminium Extrusion 2020 (1m)", cat:"Mechanical", unit:"pcs"},
  {name:"Timing Belt GT2 (1m)", cat:"Mechanical", unit:"pcs"},
  {name:"Linear Rod 8mm (300mm)", cat:"Mechanical", unit:"pcs"},
  {name:"Nitrile Gloves (M) Box", cat:"Safety", unit:"boxes"},
  {name:"Safety Goggles", cat:"Safety", unit:"pcs"},
  {name:"First Aid Kit Refill", cat:"Safety", unit:"kits"},
  {name:"Hot Glue Sticks (7mm)", cat:"Consumables", unit:"packs"},
  {name:"Sandpaper 220 Grit Sheets", cat:"Consumables", unit:"sheets"},
  {name:"Craft Knife Blades (Pack of 10)", cat:"Consumables", unit:"packs"},
  {name:"Cutting Mat A3", cat:"Consumables", unit:"pcs"},
  {name:"Double-Sided Tape 18mm", cat:"Consumables", unit:"rolls"},
];

let assets = [];
let idCounter = 1;
ITEM_TEMPLATES.forEach(t=>{
  const labCount = randInt(2,4);
  const shuffledLabs = [...LABS].sort(()=>rnd()-0.5).slice(0,labCount);
  shuffledLabs.forEach(lab=>{
    const min = randInt(10, t.unit==="pcs" ? 60 : 30);
    const tier = rnd();
    let available, priority;
    if(tier < 0.22){ available = Math.round(min*rnd()*0.3); priority="critical"; }
    else if(tier < 0.52){ available = Math.round(min*(0.31+rnd()*0.29)); priority="high"; }
    else { available = Math.round(min*(0.6+rnd()*0.38)); priority="medium"; }
    if(available>=min) available = Math.max(0, min-1); // ensure it stays "low stock"
    assets.push({
      id: "AST-" + String(idCounter++).padStart(3,"0"),
      name: t.name, category: t.cat, unit: t.unit, lab,
      location: pick(LOCATIONS) + ", " + lab,
      available, min, priority,
      requestId: null,
      supplier: pick(["TechSource Supplies","MakerHub Distributors","PrimeParts India","CircuitBay Traders","FabWorks Vendor Co."]),
      lastRestocked: `${randInt(1,28)} ${pick(["Jan","Feb","Mar","Apr","May","Jun"])} 2026`
    });
  });
});

/* Seed a few active procurement requests so some rows show status instead of checkbox */
let requests = [];
let prCounter = 1;
function newReqId(){ return "PR-" + String(prCounter++).padStart(3,"0"); }

function seedRequest(status, itemCount, priorityPref){
  const pool = assets.filter(a=>!a.requestId && (!priorityPref || a.priority===priorityPref));
  const chosen = pool.sort(()=>rnd()-0.5).slice(0, itemCount);
  if(!chosen.length) return;
  const id = newReqId();
  chosen.forEach(a=>{ a.requestId = id; });
  requests.push({
    id, status, createdDate: `${randInt(1,8)} Jul 2026`,
    items: chosen.map(a=>({assetId:a.id, orderQty: Math.max(a.min*2 - a.available, a.min)})),
    notes: "Routine replenishment for active projects."
  });
}
seedRequest("Pending Approval", 3, "critical");
seedRequest("Approved", 4, "high");
seedRequest("Procured", 2, "high");
seedRequest("Pending Approval", 2, "medium");

/* =========================================================
   STATE
   ========================================================= */
const state = {
  search:"", priority:"all", category:"all", lab:"all",
  expanded:{critical:true, high:false, medium:false},
  selected: new Set(),
};

const PRIORITY_META = {
  critical:{label:"Critical", dot:"var(--red)", badgeBg:"var(--red-bg)", badgeFg:"var(--red)", gauge:"var(--red)"},
  high:{label:"High Priority", dot:"var(--orange)", badgeBg:"var(--orange-bg)", badgeFg:"#B4600F", gauge:"var(--orange)"},
  medium:{label:"Medium Priority", dot:"var(--amber)", badgeBg:"var(--amber-bg)", badgeFg:"var(--amber)", gauge:"var(--amber)"},
};
const STATUS_META = {
  "Pending Approval":{bg:"var(--amber-bg)", fg:"var(--amber)"},
  "Approved":{bg:"var(--blue-bg)", fg:"var(--blue)"},
  "Procured":{bg:"var(--purple-bg)", fg:"var(--purple)"},
  "Restocked":{bg:"var(--green-bg)", fg:"var(--green)"},
};
const STATUS_ORDER = ["Pending Approval","Approved","Procured","Restocked"];

/* =========================================================
   POPULATE FILTER DROPDOWNS
   ========================================================= */
function initFilters(){
  const cats = [...new Set(ITEM_TEMPLATES.map(t=>t.cat))].sort();
  const catSel = document.getElementById('categoryFilter');
  cats.forEach(c=>{ const o=document.createElement('option'); o.value=c; o.textContent=c; catSel.appendChild(o); });

  const labSel = document.getElementById('labFilter');
  LABS.forEach(l=>{ const o=document.createElement('option'); o.value=l; o.textContent=l; labSel.appendChild(o); });
}

/* =========================================================
   HELPERS
   ========================================================= */
function requestById(id){ return requests.find(r=>r.id===id); }
function isLowStock(a){ return a.available < a.min; }
function visibleAssets(){
  return assets.filter(a=>{
    if(!isLowStock(a)) return false;
    if(state.search && !a.name.toLowerCase().includes(state.search.toLowerCase())) return false;
    if(state.priority!=="all" && a.priority!==state.priority) return false;
    if(state.category!=="all" && a.category!==state.category) return false;
    if(state.lab!=="all" && a.lab!==state.lab) return false;
    return true;
  });
}

/* =========================================================
   RENDER: KPIs
   ========================================================= */
function renderKpis(){
  const low = assets.filter(isLowStock);
  document.getElementById('kpiTotal').textContent = low.length;
  document.getElementById('kpiCritical').textContent = low.filter(a=>a.priority==="critical").length;
  document.getElementById('kpiHigh').textContent = low.filter(a=>a.priority==="high").length;
  document.getElementById('kpiMedium').textContent = low.filter(a=>a.priority==="medium").length;

  document.querySelectorAll('.kpi-card').forEach(c=>{
    const k = c.dataset.kpi;
    const match = (k==="all" && state.priority==="all") || (k===state.priority);
    c.classList.toggle('active-filter', match);
  });
}

/* =========================================================
   RENDER: GROUPS
   ========================================================= */
function gaugeHtml(a){
  const meta = PRIORITY_META[a.priority];
  const scaleMax = Math.max(a.min*1.3, a.available*1.15, 1);
  const fillPct = Math.min(100, (a.available/scaleMax)*100);
  const tickPct = Math.min(100, (a.min/scaleMax)*100);
  return `
    <div class="gauge-wrap">
      <div class="gauge-nums"><span>${a.available} ${a.unit}</span><span class="min">min ${a.min}</span></div>
      <div class="gauge-track">
        <div class="gauge-fill" style="width:${fillPct}%;background:${meta.gauge};"></div>
        <div class="gauge-tick" style="left:calc(${tickPct}% - 1px);"></div>
      </div>
    </div>`;
}

function rowHtml(a){
  const meta = PRIORITY_META[a.priority];
  const req = a.requestId ? requestById(a.requestId) : null;

  let leftCell, statusCell;
  if(req){
    leftCell = `<div class="cb-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></div>`;
    const sm = STATUS_META[req.status];
    statusCell = `<div class="status-cell">
        <span class="badge" style="background:${sm.bg};color:${sm.fg};">${req.status}</span>
        <span class="pr-id">${req.id}</span>
      </div>`;
  } else {
    leftCell = `<input type="checkbox" class="cb" data-id="${a.id}" ${state.selected.has(a.id)?'checked':''}>`;
    statusCell = `<span class="badge" style="background:${meta.badgeBg};color:${meta.badgeFg};">${meta.label.replace(' Priority','')}</span>`;
  }

  return `
    <div class="row" data-asset="${a.id}">
      ${leftCell}
      <div>
        <div class="r-name">${a.name}</div>
        <div class="r-meta">${a.category} • ${a.lab}</div>
      </div>
      <div>
        <div class="r-loc">${a.location.split(', ')[0]}</div>
        <div class="r-loc-tag">${a.lab}</div>
      </div>
      ${gaugeHtml(a)}
      <div class="badge-cell">${statusCell}</div>
      <button class="view-link" data-view="${a.id}">
        View <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </button>
    </div>`;
}

function renderGroups(){
  const container = document.getElementById('groups');
  const list = visibleAssets();
  const order = ["critical","high","medium"];
  container.innerHTML = order.map(p=>{
    const items = list.filter(a=>a.priority===p).sort((a,b)=> (a.available/a.min) - (b.available/b.min));
    const meta = PRIORITY_META[p];
    const selectableCount = items.filter(a=>!a.requestId).length;
    const selectedInGroup = items.filter(a=>state.selected.has(a.id)).length;
    return `
      <div class="group ${state.expanded[p] ? 'expanded':''}" data-group="${p}">
        <button class="group-header" data-toggle="${p}">
          <div class="gh-left">
            <span class="gh-dot" style="background:${meta.dot};"></span>
            <span class="gh-title">${meta.label}</span>
            <span class="gh-count" style="background:${meta.badgeBg};color:${meta.badgeFg};">${items.length}</span>
            ${selectedInGroup ? `<span class="gh-selected">${selectedInGroup} selected</span>` : ''}
          </div>
          <svg class="gh-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
        <div class="group-body">
          ${items.length ? items.map(rowHtml).join('') : `<div class="empty-group">No ${meta.label.toLowerCase()} assets match your filters.</div>`}
        </div>
      </div>`;
  }).join('');

  container.querySelectorAll('[data-toggle]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const p = btn.dataset.toggle;
      state.expanded[p] = !state.expanded[p];
      renderGroups();
    });
  });
  container.querySelectorAll('.cb').forEach(cb=>{
    cb.addEventListener('click', e=>e.stopPropagation());
    cb.addEventListener('change', ()=>{
      const id = cb.dataset.id;
      if(cb.checked) state.selected.add(id); else state.selected.delete(id);
      renderFooter();
      renderGroups();
    });
  });
  container.querySelectorAll('[data-view]').forEach(btn=>{
    btn.addEventListener('click', ()=>openDetail(btn.dataset.view));
  });
}

/* =========================================================
   FOOTER
   ========================================================= */
function renderFooter(){
  const n = state.selected.size;
  const footer = document.getElementById('stickyFooter');
  footer.classList.toggle('show', n>0);
  document.getElementById('sfCount').textContent = n;
  document.getElementById('sfCountText').textContent = `${n} asset${n===1?'':'s'}`;
}

/* =========================================================
   DETAIL MODAL
   ========================================================= */
function openDetail(id){
  const a = assets.find(x=>x.id===id);
  if(!a) return;
  document.getElementById('detailName').textContent = a.name;
  document.getElementById('detailSub').textContent = `${a.category} · ${a.lab}`;
  const req = a.requestId ? requestById(a.requestId) : null;
  document.getElementById('detailGrid').innerHTML = `
    <div class="detail-item"><div class="k">Asset ID</div><div class="v">${a.id}</div></div>
    <div class="detail-item"><div class="k">Storage Location</div><div class="v">${a.location}</div></div>
    <div class="detail-item"><div class="k">Available Quantity</div><div class="v">${a.available} ${a.unit}</div></div>
    <div class="detail-item"><div class="k">Minimum Threshold</div><div class="v">${a.min} ${a.unit}</div></div>
    <div class="detail-item"><div class="k">Priority</div><div class="v">${PRIORITY_META[a.priority].label}</div></div>
    <div class="detail-item"><div class="k">Preferred Supplier</div><div class="v">${a.supplier}</div></div>
    <div class="detail-item"><div class="k">Last Restocked</div><div class="v">${a.lastRestocked}</div></div>
    <div class="detail-item"><div class="k">Procurement Status</div><div class="v">${req ? req.status+" ("+req.id+")" : "Not requested yet"}</div></div>
  `;
  document.getElementById('detailModal').classList.add('show');
}

/* =========================================================
   CREATE REQUEST MODAL
   ========================================================= */
function openCreateModal(){
  if(state.selected.size===0){
    showToast("Select at least one asset to create a request.", false);
    return;
  }
  const items = [...state.selected].map(id=>assets.find(a=>a.id===id));
  document.getElementById('createSubtitle').textContent = `${items.length} asset${items.length===1?'':'s'} selected for replenishment`;
  document.getElementById('createItemsList').innerHTML = items.map(a=>{
    const suggested = Math.max(a.min*2 - a.available, a.min);
    return `
      <div class="mini-row">
        <div>
          <div class="mini-name">${a.name}</div>
          <div class="mini-meta">${a.category} • ${a.lab} · Available ${a.available}/${a.min} ${a.unit}</div>
        </div>
        <div>
          <input type="number" class="qty-input" id="qty-${a.id}" value="${suggested}" min="1">
          <div class="qty-label">Order qty</div>
        </div>
      </div>`;
  }).join('');
  document.getElementById('createModal').classList.add('show');
}

document.getElementById('submitRequest').addEventListener('click', ()=>{
  const ids = [...state.selected];
  if(!ids.length) return;
  const id = newReqId();
  const items = ids.map(aid=>{
    const qtyEl = document.getElementById('qty-'+aid);
    return {assetId: aid, orderQty: parseInt(qtyEl.value)||1};
  });
  requests.push({
    id, status:"Pending Approval", createdDate: "9 Jul 2026",
    items, notes: document.getElementById('requestNotes').value.trim()
  });
  ids.forEach(aid=>{ const a=assets.find(x=>x.id===aid); a.requestId=id; });
  state.selected.clear();
  document.getElementById('requestNotes').value = "";

  document.getElementById('createModal').classList.remove('show');
  document.getElementById('successReqId').textContent = `${id} created`;
  document.getElementById('successDesc').textContent = `${items.length} asset${items.length===1?'':'s'} sent to Admin for approval. They're now marked as pending and won't create duplicate requests.`;
  document.getElementById('successModal').classList.add('show');
  document.getElementById('successModal').dataset.reqId = id;

  renderAll();
});

document.getElementById('exportExcelBtn').addEventListener('click', ()=>{
  const id = document.getElementById('successModal').dataset.reqId;
  exportRequestExcel(id);
});

function exportRequestExcel(reqId){
  const req = requestById(reqId);
  if(!req) return;
  const rows = req.items.map(it=>{
    const a = assets.find(x=>x.id===it.assetId);
    return {
      "Request ID": req.id,
      "Asset ID": a.id,
      "Asset Name": a.name,
      "Category": a.category,
      "Lab": a.lab,
      "Storage Location": a.location,
      "Available Qty": a.available,
      "Min Threshold": a.min,
      "Order Qty": it.orderQty,
      "Unit": a.unit,
      "Priority": PRIORITY_META[a.priority].label,
      "Status": req.status,
      "Preferred Supplier": a.supplier
    };
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, req.id);
  XLSX.writeFile(wb, `${req.id}_procurement_request.xlsx`);
  showToast(`${req.id} exported to Excel.`, true);
}

/* =========================================================
   REQUESTS PANEL / LIFECYCLE
   ========================================================= */
function renderPanel(){
  document.getElementById('reqBadge').textContent = requests.filter(r=>r.status!=="Restocked").length;
  const body = document.getElementById('panelBody');
  if(!requests.length){
    body.innerHTML = `<div class="empty-group">No procurement requests yet.</div>`;
    return;
  }
  body.innerHTML = [...requests].reverse().map(r=>{
    const stepIdx = STATUS_ORDER.indexOf(r.status);
    const sm = STATUS_META[r.status];
    const stepsHtml = STATUS_ORDER.map((s,i)=>`<div class="step ${i<=stepIdx?'done':''}"></div>`).join('');
    const itemNames = r.items.map(it=>{
      const a = assets.find(x=>x.id===it.assetId);
      return a ? a.name : it.assetId;
    }).join(', ');

    let actions = `<button class="btn btn-outline btn-sm" data-export="${r.id}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Excel
      </button>`;
    let demoNote = "";
    if(r.status==="Procured"){
      actions += `<button class="btn btn-primary btn-sm" data-restock="${r.id}">Restock Now</button>`;
    } else if(r.status!=="Restocked"){
      actions += `<button class="btn btn-outline btn-sm" data-advance="${r.id}">Advance Status →</button>`;
      demoNote = `<div class="demo-note">Demo control — simulates Admin / Procurement team action</div>`;
    }

    return `
      <div class="req-card">
        <div class="req-top">
          <div><div class="req-id">${r.id}</div><div class="req-date">Created ${r.createdDate} · ${r.items.length} item${r.items.length===1?'':'s'}</div></div>
          <span class="badge" style="background:${sm.bg};color:${sm.fg};">${r.status}</span>
        </div>
        <div class="steps">${stepsHtml}</div>
        <div class="req-status-row">
          <span style="font-size:11px;color:var(--muted-2);font-weight:600;">Pending</span>
          <span style="font-size:11px;color:var(--muted-2);font-weight:600;">Approved</span>
          <span style="font-size:11px;color:var(--muted-2);font-weight:600;">Procured</span>
          <span style="font-size:11px;color:var(--muted-2);font-weight:600;">Restocked</span>
        </div>
        <div class="req-items">${itemNames}</div>
        <div class="req-actions">${actions}</div>
        ${demoNote}
      </div>`;
  }).join('');

  body.querySelectorAll('[data-advance]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const r = requestById(btn.dataset.advance);
      const idx = STATUS_ORDER.indexOf(r.status);
      if(idx < STATUS_ORDER.length-2){ // stop before auto-jumping to Restocked; that's a real action
        r.status = STATUS_ORDER[idx+1];
        showToast(`${r.id} moved to "${r.status}".`, true);
        renderAll();
      }
    });
  });
  body.querySelectorAll('[data-restock]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const r = requestById(btn.dataset.restock);
      r.items.forEach(it=>{
        const a = assets.find(x=>x.id===it.assetId);
        if(a){
          a.available += it.orderQty;
          if(a.available >= a.min){ a.requestId = null; }
        }
      });
      r.status = "Restocked";
      showToast(`${r.id} restocked — inventory updated.`, true);
      renderAll();
    });
  });
  body.querySelectorAll('[data-export]').forEach(btn=>{
    btn.addEventListener('click', ()=> exportRequestExcel(btn.dataset.export));
  });
}

/* =========================================================
   TOAST
   ========================================================= */
let toastTimer;
function showToast(msg, ok=true){
  const t = document.getElementById('toast');
  document.getElementById('toastText').textContent = msg;
  t.querySelector('svg').style.color = ok ? '#4ADE80' : '#F87171';
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> t.classList.remove('show'), 3200);
}

/* =========================================================
   EVENTS
   ========================================================= */
document.getElementById('searchInput').addEventListener('input', e=>{
  state.search = e.target.value;
  if(state.search){ state.expanded = {critical:true, high:true, medium:true}; }
  renderGroups();
});
document.getElementById('priorityFilter').addEventListener('change', e=>{ state.priority = e.target.value; renderKpis(); renderGroups(); });
document.getElementById('categoryFilter').addEventListener('change', e=>{ state.category = e.target.value; renderGroups(); });
document.getElementById('labFilter').addEventListener('change', e=>{ state.lab = e.target.value; renderGroups(); });
document.getElementById('clearFilters').addEventListener('click', ()=>{
  state.search=""; state.priority="all"; state.category="all"; state.lab="all";
  document.getElementById('searchInput').value="";
  document.getElementById('priorityFilter').value="all";
  document.getElementById('categoryFilter').value="all";
  document.getElementById('labFilter').value="all";
  renderKpis(); renderGroups();
});
document.querySelectorAll('.kpi-card').forEach(c=>{
  c.addEventListener('click', ()=>{
    const k = c.dataset.kpi;
    state.priority = k==="all" ? "all" : k;
    document.getElementById('priorityFilter').value = state.priority;
    if(k!=="all") state.expanded[k]=true;
    renderKpis(); renderGroups();
  });
});

document.getElementById('headerCta').addEventListener('click', openCreateModal);
document.getElementById('sfCreate').addEventListener('click', openCreateModal);
document.getElementById('sfClear').addEventListener('click', ()=>{ state.selected.clear(); renderFooter(); renderGroups(); });

document.querySelectorAll('[data-close]').forEach(b=>{
  b.addEventListener('click', ()=> b.closest('.overlay').classList.remove('show'));
});
document.querySelectorAll('.overlay').forEach(o=>{
  o.addEventListener('click', e=>{ if(e.target===o) o.classList.remove('show'); });
});

document.getElementById('openRequestsPanel').addEventListener('click', ()=>{
  document.getElementById('requestsPanel').classList.add('show');
  document.getElementById('panelOverlay').classList.add('show');
});
document.getElementById('closePanel').addEventListener('click', closePanel);
document.getElementById('panelOverlay').addEventListener('click', closePanel);
function closePanel(){
  document.getElementById('requestsPanel').classList.remove('show');
  document.getElementById('panelOverlay').classList.remove('show');
}

document.addEventListener('keydown', e=>{
  if(e.key==="Escape"){
    document.querySelectorAll('.overlay.show').forEach(o=>o.classList.remove('show'));
    closePanel();
  }
});

/* =========================================================
   INIT
   ========================================================= */
function renderAll(){
  renderKpis();
  renderGroups();
  renderFooter();
  renderPanel();
}
initFilters();
renderAll();