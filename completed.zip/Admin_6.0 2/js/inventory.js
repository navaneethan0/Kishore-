// Inventory Page Logic (pagination, filtering, sorting, delete)

document.addEventListener("DOMContentLoaded", () => {
    let db = getDB();

    let currentFilters = {
        type: "All",
        search: ""
    };
    let sortField = "id";
    let sortOrder = "asc";
    let currentPage = 1;
    let currentView = "equipment";

    const itemsPerPage = 20;

    const TABLE_SCHEMAS = {
        equipment: [
            "Sl No",
            "Component Name",
            "Make",
            "Specification/Version",
            "Total Count",
            "Component Type",
            "Lab",
            "Remarks",
            "Actions"
        ],
        components: [
            "Sl No",
            "Component Name",
            "Make",
            "Specification/Version",
            "Cost",
            "Return Timeline",
            "Total Count",
            "Component Type",
            "Lab",
            "Cupboard Stored in",
            "Shelf1",
            "Count 1",
            "Shelf2",
            "Count 2",
            "Purpose",
            "Comments",
            "Actions"
        ],
        tools: [
            "Sl No",
            "Component Name",
            "Make",
            "Specification/Version",
            "Cost",
            "Return Timeline",
            "Total Count",
            "Component Type",
            "Lab",
            "Cupboard Stored in",
            "Shelf1",
            "Count 1",
            "Shelf2",
            "Count 2",
            "Purpose",
            "Comments",
            "Actions"
        ]
    };

    const tableBody = document.getElementById("inventoryTableBody");
    const tableInfo = document.getElementById("inventoryTableInfo");
    const paginationContainer = document.getElementById("inventoryPagination");
    const searchInput = document.getElementById("searchInventoryInput");

    const kpiTotal = document.getElementById("kpiTotalInventory");
    const kpiAvailable = document.getElementById("kpiAvailableInventory");
    const kpiMaintenance = document.getElementById("kpiMaintenanceInventory");

    function updateKPIs() {
        const list = db[currentView] || [];
        kpiTotal.textContent = String(list.length).padStart(2, '0');
        kpiAvailable.textContent = String(list.filter(item => item.status === "Available").length).padStart(2, '0');
        kpiMaintenance.textContent = String(list.filter(item => item.status === "Maintenance" || item.status === "Repairing").length).padStart(2, '0');
    }

    function renderHeader() {
        const head = document.getElementById("inventoryTableHead");
        head.innerHTML = `<tr>${TABLE_SCHEMAS[currentView].map(col => `<th>${col}</th>`).join("")}</tr>`;
    }

    function switchView(view) {
        currentView = view;
        currentPage = 1;

        document.querySelectorAll(".view-btn").forEach(btn => {
            const isActive = btn.dataset.view === view;
            btn.classList.toggle("active", isActive);
            btn.classList.toggle("btn-primary", isActive);
            btn.classList.toggle("btn-secondary", !isActive);
        });

        const actEq = document.getElementById("actionsEquipment");
        const actCp = document.getElementById("actionsComponents");
        const actTl = document.getElementById("actionsTools");
        if (actEq) actEq.style.display = currentView === "equipment" ? "" : "none";
        if (actCp) actCp.style.display = currentView === "components" ? "" : "none";
        if (actTl) actTl.style.display = currentView === "tools" ? "" : "none";

        renderHeader();
        renderTable();
        updateKPIs();
    }

    function renderTable() {
        const colCount = TABLE_SCHEMAS[currentView].length;

        tableBody.innerHTML = `
            <tr>
                ${Array(colCount).fill('<td class="skeleton" style="height:48px;"></td>').join("")}
            </tr>
        `;

        setTimeout(() => {
            let filteredData = (db[currentView] || []).filter(item => {
                const searchText = currentFilters.search.toLowerCase();
                return Object.values(item).join(" ").toLowerCase().includes(searchText);
            });

            const totalItems = filteredData.length;
            const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;

            if (currentPage > totalPages) currentPage = totalPages;
            const startIndex = (currentPage - 1) * itemsPerPage;
            const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
            const paginatedData = filteredData.slice(startIndex, endIndex);

            if (paginatedData.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="${colCount}" style="text-align:center;padding:48px 16px;">
                            <div class="empty-state">
                                <span class="empty-state-icon">&#10065;</span>
                                <span class="empty-state-title">No Inventory Items Found</span>
                                <p class="empty-state-desc">Try widening your search query or choosing a different filter tab.</p>
                            </div>
                        </td>
                    </tr>
                `;
                tableInfo.textContent = "Showing 0 to 0 of 0 entries";
                renderPagination(1, 1);
                return;
            }

            if (currentView === "equipment") {
                tableBody.innerHTML = paginatedData.map(item => `
                    <tr>
                        <td>${item.sno}</td>
                        <td>${item.name || item.componentName || ""}</td>
                        <td>${item.make}</td>
                        <td>${item.specification || ""}</td>
                        <td>${item.totalCount || item.avail || ""}</td>
                        <td>${item.componentType || ""}</td>
                        <td>${item.lab}</td>
                        <td>${item.remarks || ""}</td>
                        <td class="col-action">
                            <a href="javascript:void(0)" onclick="openEditAssetModal('equipment','${item.eqpid}')" class="action-link" title="Edit">&#9998;</a>
                            <a href="javascript:void(0)" onclick="deleteEquipment('${item.eqpid}','${(item.name || item.componentName || '').replace(/'/g, "\\'")}')" class="action-link action-delete" title="Delete">&#128465;</a>
                        </td>
                    </tr>
                `).join("");
            } else if (currentView === "components") {
                tableBody.innerHTML = paginatedData.map(item => `
                    <tr>
                        <td>${item.sno}</td>
                        <td>${item.componentName}</td>
                        <td>${item.make}</td>
                        <td>${item.specification || ""}</td>
                        <td>${item.cost || ""}</td>
                        <td>${item.returnTimeline || ""}</td>
                        <td>${item.totalCount || ""}</td>
                        <td>${item.componentType || ""}</td>
                        <td>${item.lab || ""}</td>
                        <td>${item.cupboard || ""}</td>
                        <td>${item.shelf1 || ""}</td>
                        <td>${item.count1 || ""}</td>
                        <td>${item.shelf2 || ""}</td>
                        <td>${item.count2 || ""}</td>
                        <td>${item.purpose || ""}</td>
                        <td>${item.comments || ""}</td>
                        <td class="col-action">
                            <a href="javascript:void(0)" onclick="openEditAssetModal('components','${item.cid}')" class="action-link" title="Edit">&#9998;</a>
                            <a href="javascript:void(0)" onclick="deleteComponent('${item.cid}','${(item.componentName || '').replace(/'/g, "\\'")}')" class="action-link action-delete" title="Delete">&#128465;</a>
                        </td>
                    </tr>
                `).join("");
            } else if (currentView === "tools") {
                tableBody.innerHTML = paginatedData.map(item => `
                    <tr>
                        <td>${item.sno}</td>
                        <td>${item.componentName}</td>
                        <td>${item.make}</td>
                        <td>${item.specification || ""}</td>
                        <td>${item.cost || ""}</td>
                        <td>${item.returnTimeline || ""}</td>
                        <td>${item.totalCount || ""}</td>
                        <td>${item.componentType || ""}</td>
                        <td>${item.lab || ""}</td>
                        <td>${item.cupboard || ""}</td>
                        <td>${item.shelf1 || ""}</td>
                        <td>${item.count1 || ""}</td>
                        <td>${item.shelf2 || ""}</td>
                        <td>${item.count2 || ""}</td>
                        <td>${item.purpose || ""}</td>
                        <td>${item.comments || ""}</td>
                        <td class="col-action">
                            <a href="javascript:void(0)" onclick="openEditAssetModal('tools','${item.toolid}')" class="action-link" title="Edit">&#9998;</a>
                            <a href="javascript:void(0)" onclick="deleteTool('${item.toolid}','${(item.componentName || '').replace(/'/g, "\\'")}')" class="action-link action-delete" title="Delete">&#128465;</a>
                        </td>
                    </tr>
                `).join("");
            }

            tableInfo.textContent = `Showing ${totalItems === 0 ? 0 : startIndex + 1} to ${endIndex} of ${totalItems} entries`;
            renderPagination(currentPage, totalPages);
        }, 200);
    }

    function renderPagination(current, total) {
        paginationContainer.innerHTML = "";

        const prevItem = document.createElement("li");
        prevItem.className = `page-item ${current === 1 ? 'disabled' : ''}`;
        prevItem.innerHTML = `<button class="page-link" ${current === 1 ? 'disabled' : ''}>&lt;</button>`;
        if (current > 1) {
            prevItem.querySelector("button").addEventListener("click", () => {
                currentPage--;
                renderTable();
            });
        }
        paginationContainer.appendChild(prevItem);

        for (let i = 1; i <= total; i++) {
            const pageItem = document.createElement("li");
            pageItem.className = `page-item ${current === i ? 'active' : ''}`;
            pageItem.innerHTML = `<button class="page-link">${i}</button>`;
            pageItem.querySelector("button").addEventListener("click", () => {
                currentPage = i;
                renderTable();
            });
            paginationContainer.appendChild(pageItem);
        }

        const nextItem = document.createElement("li");
        nextItem.className = `page-item ${current === total ? 'disabled' : ''}`;
        nextItem.innerHTML = `<button class="page-link" ${current === total ? 'disabled' : ''}>&gt;</button>`;
        if (current < total) {
            nextItem.querySelector("button").addEventListener("click", () => {
                currentPage++;
                renderTable();
            });
        }
        paginationContainer.appendChild(nextItem);
    }

    window.deleteEquipment = function (id, name) {
        createConfirmationModal(
            "Confirm Equipment Deletion",
            `Are you sure you want to delete <strong>${name} (${id})</strong> from the inventory system? This action is permanent and cannot be undone.`,
            () => {
                db.equipment = db.equipment.filter(item => item.eqpid !== id);
                setDB(db);
                showToast(`Item ${id} deleted successfully`, "success");
                updateKPIs();
                renderTable();
            },
            "Delete Item",
            true
        );
    };

    window.deleteComponent = function (id, name) {
        createConfirmationModal(
            "Confirm Component Deletion",
            `Are you sure you want to delete <strong>${name} (${id})</strong>? This action cannot be undone.`,
            () => {
                db.components = db.components.filter(item => item.cid !== id);
                setDB(db);
                showToast(`Component ${id} deleted successfully`, "success");
                updateKPIs();
                renderTable();
            },
            "Delete Component",
            true
        );
    };

    window.deleteTool = function (id, name) {
        createConfirmationModal(
            "Confirm Tool Deletion",
            `Are you sure you want to delete <strong>${name} (${id})</strong>? This action cannot be undone.`,
            () => {
                db.tools = db.tools.filter(item => item.toolid !== id);
                setDB(db);
                showToast(`Tool ${id} deleted successfully`, "success");
                updateKPIs();
                renderTable();
            },
            "Delete Tool",
            true
        );
    };

    searchInput.addEventListener("input", debounce((e) => {
        currentFilters.search = e.target.value.trim();
        currentPage = 1;
        renderTable();
    }, 250));

    document.querySelectorAll(".view-btn").forEach(btn => {
        btn.addEventListener("click", () => switchView(btn.dataset.view));
    });

    document.querySelectorAll(".btn-download").forEach(btn => {
        btn.addEventListener("click", () => downloadTemplate(btn.dataset.type));
    });

    const fileInput = document.getElementById("bulkUploadFileInput");
    if (fileInput) {
        fileInput.addEventListener("change", function (e) {
            const file = e.target.files[0];
            if (!file) return;

            const uploadType = this.dataset.uploadType;
            const updateDuplicates = document.getElementById("updateDuplicateCheck")?.checked || false;

            const reader = new FileReader();
            reader.onload = function (evt) {
                try {
                    const data = new Uint8Array(evt.target.result);
                    const workbook = XLSX.read(data, { type: "array" });
                    const firstSheetName = workbook.SheetNames[0];
                    const sheet = workbook.Sheets[firstSheetName];
                    const rows = XLSX.utils.sheet_to_json(sheet);

                    if (!rows || rows.length === 0) {
                        showToast("Excel/CSV file is empty.", "warn");
                        return;
                    }

                    processImport(rows, uploadType, updateDuplicates);
                } catch (err) {
                    console.error(err);
                    showToast("Error parsing file. Ensure it is a valid Excel or CSV file.", "error");
                }
            };
            reader.readAsArrayBuffer(file);
        });
    }

    function processImport(rows, type, updateDuplicates) {
        const freshDb = getDB();
        let successCount = 0;
        let failCount = 0;
        const details = [];

        let listArr = [];
        let idKey = "";
        let altIdKeys = [];
        let altNameKeys = [];

        if (type === "equipment") {
            listArr = freshDb.equipment || [];
            idKey = "eqpid";
            altIdKeys = ["Equipment ID", "eqpid", "id"];
            altNameKeys = ["Equipment Name", "name", "componentName"];
        } else if (type === "components") {
            listArr = freshDb.components || [];
            idKey = "cid";
            altIdKeys = ["Component ID", "cid", "id"];
            altNameKeys = ["Component Name", "name", "componentName"];
        } else if (type === "tools") {
            listArr = freshDb.tools || [];
            idKey = "toolid";
            altIdKeys = ["Tool ID", "toolid", "id"];
            altNameKeys = ["Tool Name", "name", "componentName"];
        }

        const getProp = (row, alternativeKeys) => {
            for (const k of alternativeKeys) {
                if (row[k] !== undefined) return String(row[k]).trim();
                const foundKey = Object.keys(row).find(rk => rk.toLowerCase().trim() === k.toLowerCase().trim());
                if (foundKey && row[foundKey] !== undefined) return String(row[foundKey]).trim();
            }
            return "";
        };

        rows.forEach((row, idx) => {
            const sheetRowIndex = idx + 2;

            const itemId = getProp(row, altIdKeys);
            const itemName = getProp(row, altNameKeys);
            const make = getProp(row, ["Make", "manufacturer"]);
            const lab = getProp(row, ["Lab", "location"]);

            if (!itemId) {
                failCount++;
                details.push({ row: sheetRowIndex, id: "N/A", status: "Failed", reason: "Missing unique Item ID column." });
                return;
            }
            if (!itemName) {
                failCount++;
                details.push({ row: sheetRowIndex, id: itemId, status: "Failed", reason: "Missing Item Name." });
                return;
            }
            if (!make) {
                failCount++;
                details.push({ row: sheetRowIndex, id: itemId, status: "Failed", reason: "Missing Make." });
                return;
            }
            if (!lab) {
                failCount++;
                details.push({ row: sheetRowIndex, id: itemId, status: "Failed", reason: "Missing Lab location." });
                return;
            }

            const existingIdx = listArr.findIndex(item => String(item[idKey]).trim().toLowerCase() === itemId.toLowerCase());

            if (existingIdx > -1) {
                if (updateDuplicates) {
                    if (type === "equipment") {
                        listArr[existingIdx] = {
                            ...listArr[existingIdx],
                            name: itemName,
                            componentName: itemName,
                            make: make,
                            specification: getProp(row, ["Specification", "model"]),
                            totalCount: parseInt(getProp(row, ["Total Count", "qty"])) || listArr[existingIdx].totalCount || 1,
                            componentType: getProp(row, ["Component Type", "type"]) || listArr[existingIdx].componentType || "Equipment",
                            lab: lab,
                            remarks: getProp(row, ["Remarks", "description"]) || listArr[existingIdx].remarks || "Working Fine"
                        };
                    } else {
                        listArr[existingIdx] = {
                            ...listArr[existingIdx],
                            componentName: itemName,
                            make: make,
                            specification: getProp(row, ["Specification", "model"]),
                            cost: parseFloat(getProp(row, ["Cost"])) || listArr[existingIdx].cost || 0,
                            returnTimeline: getProp(row, ["Return Timeline"]) || listArr[existingIdx].returnTimeline || "Daily",
                            totalCount: parseInt(getProp(row, ["Total Count", "qty"])) || listArr[existingIdx].totalCount || 1,
                            componentType: getProp(row, ["Component Type", "Tool Type", "type"]) || listArr[existingIdx].componentType || "Electronics",
                            lab: lab,
                            cupboard: getProp(row, ["Cupboard", "cupboard"]) || listArr[existingIdx].cupboard || "",
                            shelf1: getProp(row, ["Shelf 1", "shelf1"]) || listArr[existingIdx].shelf1 || "",
                            count1: parseInt(getProp(row, ["Count 1", "count1"])) || listArr[existingIdx].count1 || 0,
                            shelf2: getProp(row, ["Shelf 2", "shelf2"]) || listArr[existingIdx].shelf2 || "",
                            count2: parseInt(getProp(row, ["Count 2", "count2"])) || listArr[existingIdx].count2 || 0,
                            purpose: getProp(row, ["Purpose"]) || listArr[existingIdx].purpose || "Student Projects",
                            comments: getProp(row, ["Comments"]) || listArr[existingIdx].comments || ""
                        };
                    }
                    successCount++;
                    details.push({ row: sheetRowIndex, id: itemId, status: "Updated", reason: "Existing item updated." });
                } else {
                    failCount++;
                    details.push({ row: sheetRowIndex, id: itemId, status: "Skipped", reason: "Unique Item ID already exists, update duplicates disabled." });
                }
            } else {
                let newItem = {};
                if (type === "equipment") {
                    newItem = {
                        sno: listArr.length + 1,
                        eqpid: itemId,
                        name: itemName,
                        componentName: itemName,
                        make: make,
                        specification: getProp(row, ["Specification", "model"]),
                        totalCount: parseInt(getProp(row, ["Total Count", "qty"])) || 1,
                        componentType: getProp(row, ["Component Type", "type"]) || "Equipment",
                        lab: lab,
                        remarks: getProp(row, ["Remarks", "description"]) || "Working Fine",
                        status: "Available"
                    };
                } else {
                    newItem = {
                        sno: listArr.length + 1,
                        [idKey]: itemId,
                        componentName: itemName,
                        make: make,
                        specification: getProp(row, ["Specification", "model"]),
                        cost: parseFloat(getProp(row, ["Cost"])) || 0,
                        returnTimeline: getProp(row, ["Return Timeline"]) || "Daily",
                        totalCount: parseInt(getProp(row, ["Total Count", "qty"])) || 1,
                        componentType: getProp(row, ["Component Type", "Tool Type", "type"]) || "Electronics",
                        lab: lab,
                        cupboard: getProp(row, ["Cupboard", "cupboard"]) || "",
                        shelf1: getProp(row, ["Shelf 1", "shelf1"]) || "",
                        count1: parseInt(getProp(row, ["Count 1", "count1"])) || 0,
                        shelf2: getProp(row, ["Shelf 2", "shelf2"]) || "",
                        count2: parseInt(getProp(row, ["Count 2", "count2"])) || 0,
                        purpose: getProp(row, ["Purpose"]) || "Student Projects",
                        comments: getProp(row, ["Comments"]) || "",
                        status: "Available"
                    };
                }
                listArr.push(newItem);
                successCount++;
                details.push({ row: sheetRowIndex, id: itemId, status: "Created", reason: "Successfully imported." });
            }
        });

        if (type === "equipment") freshDb.equipment = listArr;
        else if (type === "components") freshDb.components = listArr;
        else if (type === "tools") freshDb.tools = listArr;

        setDB(freshDb);
        db = freshDb;

        renderTable();
        updateKPIs();

        document.getElementById("summaryTotalRows").textContent = rows.length;
        document.getElementById("summarySuccessRows").textContent = successCount;
        document.getElementById("summaryFailedRows").textContent = failCount;

        const tbody = document.getElementById("uploadSummaryTableBody");
        tbody.innerHTML = details.map(d => {
            const rowClass = d.status === "Failed" || d.status === "Skipped" ? "text-danger" : "text-success";
            return `
                <tr>
                    <td>Row ${d.row}</td>
                    <td><strong>${d.id}</strong></td>
                    <td><span class="${rowClass}">${d.status}</span> - ${d.reason}</td>
                </tr>
            `;
        }).join("");

        document.getElementById("uploadSummaryModalOverlay").classList.add("show");
        document.getElementById("uploadSummaryModal").classList.add("show");
    }

    window.closeUploadSummaryModal = function () {
        document.getElementById("uploadSummaryModalOverlay").classList.remove("show");
        document.getElementById("uploadSummaryModal").classList.remove("show");
    };

    window.downloadTemplate = function (type) {
        let headers = "";
        let filename = "";
        if (type === "equipment") {
            headers = "Equipment ID,Equipment Name,Make,Specification,Total Count,Component Type,Lab,Remarks\nEQP201,3D Printer Pro,Creality,Ender 5,3,Manufacturing Equipment,Mechanical Lab,Working Fine";
            filename = "equipment_template.csv";
        } else if (type === "components") {
            headers = "Component ID,Component Name,Make,Specification,Cost,Return Timeline,Total Count,Component Type,Lab,Cupboard,Shelf 1,Count 1,Shelf 2,Count 2,Purpose,Comments\nCID201,Arduino Uno R4,Arduino,Uno R4 Minima,1200,Project Completion,20,Electronics,Embedded Lab,CUP-1,A1,10,A2,10,Workshop,New Stock";
            filename = "components_template.csv";
        } else if (type === "tools") {
            headers = "Tool ID,Tool Name,Make,Specification,Cost,Return Timeline,Total Count,Tool Type,Lab,Cupboard,Shelf 1,Count 1,Shelf 2,Count 2,Purpose,Comments\nT201,Digital Multimeter,Fluke,Model 115,4500,Daily,5,Electronics Tool,Embedded Lab,CUP-5,A1,2,A2,3,Lab Testing,Calibrated";
            filename = "tools_template.csv";
        }

        const blob = new Blob([headers], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.setAttribute("download", filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    /* ---- Sidebar (same behavior as other admin pages) ---- */
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');

    function toggleSidebar() {
        if (!sidebar || !sidebarOverlay) return;
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
    }

    if (sidebarToggleBtn) {
        sidebarToggleBtn.addEventListener('click', toggleSidebar);
    }
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
        });
    }

    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const targetId = btn.getAttribute('aria-controls');
            const group = btn.closest('.nav-group') || btn.closest('.nav-dropdown');
            const menu = document.getElementById(targetId) || (group ? group.querySelector('.dropdown-menu') : null);
            const isActive = btn.classList.contains('active');

            document.querySelectorAll('.dropdown-toggle').forEach(t => {
                t.classList.remove('active');
                t.setAttribute('aria-expanded', 'false');
            });
            document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));
            document.querySelectorAll('.sub-dropdown-toggle').forEach(t => {
                t.classList.remove('active');
                t.setAttribute('aria-expanded', 'false');
            });
            document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));

            if (menu && !isActive) {
                btn.classList.add('active');
                btn.setAttribute('aria-expanded', 'true');
                menu.classList.add('active');
            }
        });
    });

    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const targetId = btn.getAttribute('aria-controls');
            const group = btn.closest('.nav-subgroup');
            const menu = document.getElementById(targetId) || (group ? group.querySelector('.sub-dropdown-menu') : null);
            const isActive = btn.classList.contains('active');

            if (menu) {
                if (isActive) {
                    btn.classList.remove('active');
                    btn.setAttribute('aria-expanded', 'false');
                    menu.classList.remove('active');
                } else {
                    btn.classList.add('active');
                    btn.setAttribute('aria-expanded', 'true');
                    menu.classList.add('active');
                }
            }
        });
    });

    const dateWidget = document.querySelector('.header-date-widget');
    if (dateWidget) {
        const now = new Date();
        dateWidget.innerHTML = `
            <div class="header-date-text">
                <span class="header-date-day">${now.toLocaleDateString('en-IN', { weekday: 'short' })}</span>
                <span class="header-date-full">${now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
            </div>
        `;
    }

    /* ---- Add / Edit Asset Modal ---- */
    const TYPE_LABELS = { equipment: 'Equipment', components: 'Component', tools: 'Tool' };
    const ID_KEYS = { equipment: 'eqpid', components: 'cid', tools: 'toolid' };
    let editingId = null;
    let modalView = 'equipment';

    const equipmentModal = document.getElementById('equipmentModal');
    const modalHeading = document.getElementById('modalHeading');
    const modalSubheading = document.getElementById('modalSubheading');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const cancelModalBtn = document.getElementById('cancelModalBtn');
    const submitModalBtn = document.getElementById('submitModalBtn');
    const submitBtnLabel = document.getElementById('submitBtnLabel');

    const fEqpTypeId = document.getElementById('fEqpTypeId');
    const fName = document.getElementById('fName');
    const fQuantity = document.getElementById('fQuantity');
    const fMake = document.getElementById('fMake');
    const fSpecification = document.getElementById('fSpecification');
    const fComponentType = document.getElementById('fComponentType');
    const fLab = document.getElementById('fLab');
    const fRemarks = document.getElementById('fRemarks');
    const charCount = document.getElementById('charCount');
    const fCost = document.getElementById('fCost');
    const fReturnTimeline = document.getElementById('fReturnTimeline');
    const fCupboard = document.getElementById('fCupboard');
    const fShelf1 = document.getElementById('fShelf1');
    const fCount1 = document.getElementById('fCount1');
    const fShelf2 = document.getElementById('fShelf2');
    const fCount2 = document.getElementById('fCount2');
    const fPurpose = document.getElementById('fPurpose');
    const fComments = document.getElementById('fComments');

    const errEqpTypeId = document.getElementById('errEqpTypeId');
    const errName = document.getElementById('errName');
    const errQuantity = document.getElementById('errQuantity');
    const errMake = document.getElementById('errMake');
    const errLab = document.getElementById('errLab');

    const REQUIRED_FIELDS = [
        { el: fEqpTypeId, err: errEqpTypeId, label: 'Item ID is required' },
        { el: fName, err: errName, label: 'Name is required' },
        { el: fQuantity, err: errQuantity, label: 'Available Quantity is required' },
        { el: fMake, err: errMake, label: 'Make is required' },
        { el: fLab, err: errLab, label: 'Lab is required' }
    ];

    function toggleModalFields(view) {
        const eqpFields = document.querySelectorAll('.eqp-field');
        const extraFields = document.querySelectorAll('.extra-field');
        if (view === 'equipment') {
            eqpFields.forEach(el => { el.style.display = 'block'; });
            extraFields.forEach(el => { el.style.display = 'none'; });
        } else {
            eqpFields.forEach(el => { el.style.display = 'none'; });
            extraFields.forEach(el => { el.style.display = 'block'; });
        }
    }

    function clearFormErrors() {
        REQUIRED_FIELDS.forEach(({ el, err }) => {
            err.textContent = '';
            el.classList.remove('error');
        });
    }

    function clearAssetForm() {
        fEqpTypeId.value = '';
        fName.value = '';
        fQuantity.value = '';
        fMake.value = '';
        fSpecification.value = '';
        fComponentType.value = '';
        fLab.value = '';
        fRemarks.value = '';
        charCount.textContent = '0';
        fCost.value = '';
        fReturnTimeline.value = '';
        fCupboard.value = '';
        fShelf1.value = '';
        fCount1.value = '';
        fShelf2.value = '';
        fCount2.value = '';
        fPurpose.value = '';
        fComments.value = '';
    }

    function validateAssetField(field) {
        const { el, err, label } = field;
        const val = el.value.trim();
        if (!val) {
            err.textContent = label;
            el.classList.add('error');
            return false;
        }
        if (el === fQuantity && (isNaN(Number(val)) || Number(val) < 0)) {
            err.textContent = 'Enter a valid non-negative number';
            el.classList.add('error');
            return false;
        }
        err.textContent = '';
        el.classList.remove('error');
        return true;
    }

    function validateAssetForm() {
        return REQUIRED_FIELDS.map(validateAssetField).every(Boolean);
    }

    function closeAssetModal() {
        equipmentModal.classList.remove('active');
        editingId = null;
        clearFormErrors();
    }

    function setSubmitModalIcon(iconName) {
        submitModalBtn.querySelector('svg')?.remove();
        let iconEl = submitModalBtn.querySelector('i');
        if (!iconEl) {
            iconEl = document.createElement('i');
            submitModalBtn.insertBefore(iconEl, submitBtnLabel);
        }
        iconEl.setAttribute('data-lucide', iconName);
    }

    function openAddAssetModal(view) {
        modalView = view;
        editingId = null;
        const label = TYPE_LABELS[view];

        modalHeading.textContent = `Add ${label}`;
        modalSubheading.textContent = `Asset Information · Create new ${label}`;
        submitBtnLabel.textContent = `Create ${label}`;
        setSubmitModalIcon('plus-circle');
        fEqpTypeId.removeAttribute('readonly');

        toggleModalFields(view);
        clearAssetForm();
        clearFormErrors();
        equipmentModal.classList.add('active');
        if (typeof lucide !== 'undefined') lucide.createIcons();
        fEqpTypeId.focus();
    }

    function fillAssetForm(item, view) {
        const idKey = ID_KEYS[view];
        fEqpTypeId.value = item[idKey] || '';
        fName.value = item.name || item.componentName || '';
        fQuantity.value = item.totalCount || '';
        fMake.value = item.make || '';
        fSpecification.value = item.specification || '';
        fComponentType.value = item.componentType || '';
        fLab.value = item.lab || '';
        fRemarks.value = item.remarks || '';
        charCount.textContent = (item.remarks || '').length;
        fCost.value = item.cost || '';
        fReturnTimeline.value = item.returnTimeline || '';
        fCupboard.value = item.cupboard || '';
        fShelf1.value = item.shelf1 || '';
        fCount1.value = item.count1 || '';
        fShelf2.value = item.shelf2 || '';
        fCount2.value = item.count2 || '';
        fPurpose.value = item.purpose || '';
        fComments.value = item.comments || '';
    }

    window.openEditAssetModal = function (view, id) {
        modalView = view;
        const idKey = ID_KEYS[view];
        const item = (db[view] || []).find(row => String(row[idKey]) === String(id));
        if (!item) return;

        editingId = id;
        const label = TYPE_LABELS[view];

        modalHeading.textContent = `Edit ${label}`;
        modalSubheading.textContent = `Asset Information · Update existing ${label}`;
        submitBtnLabel.textContent = `Update ${label}`;
        setSubmitModalIcon('save');
        fEqpTypeId.setAttribute('readonly', 'readonly');

        toggleModalFields(view);
        clearFormErrors();
        fillAssetForm(item, view);
        equipmentModal.classList.add('active');
        if (typeof lucide !== 'undefined') lucide.createIcons();
        fName.focus();
    };

    document.querySelectorAll('.btn-add-asset').forEach(btn => {
        btn.addEventListener('click', () => openAddAssetModal(btn.dataset.type));
    });

    if (closeModalBtn) closeModalBtn.addEventListener('click', closeAssetModal);
    if (cancelModalBtn) cancelModalBtn.addEventListener('click', closeAssetModal);

    if (equipmentModal) {
        equipmentModal.addEventListener('click', (e) => {
            if (e.target === equipmentModal) closeAssetModal();
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && equipmentModal.classList.contains('active')) {
            closeAssetModal();
        }
    });

    if (fRemarks) {
        fRemarks.addEventListener('input', () => {
            charCount.textContent = fRemarks.value.length;
        });
    }

    REQUIRED_FIELDS.forEach(field => {
        field.el.addEventListener('blur', () => validateAssetField(field));
        field.el.addEventListener('input', () => {
            if (field.el.classList.contains('error')) validateAssetField(field);
        });
    });

    if (submitModalBtn) {
        submitModalBtn.addEventListener('click', () => {
            if (!validateAssetForm()) return;

            const freshDb = getDB();
            const list = freshDb[modalView] || [];
            const idKey = ID_KEYS[modalView];
            const itemId = fEqpTypeId.value.trim();
            const itemName = fName.value.trim();
            const totalCount = Number(fQuantity.value.trim());

            const baseItem = {
                make: fMake.value.trim(),
                specification: fSpecification.value.trim(),
                componentType: fComponentType.value.trim(),
                lab: fLab.value.trim(),
                totalCount: totalCount,
                status: 'Available'
            };

            if (modalView === 'equipment') {
                Object.assign(baseItem, {
                    eqpid: itemId,
                    name: itemName,
                    componentName: itemName,
                    remarks: fRemarks.value.trim()
                });
            } else {
                Object.assign(baseItem, {
                    [idKey]: itemId,
                    componentName: itemName,
                    cost: fCost.value ? parseFloat(fCost.value) : 0,
                    returnTimeline: fReturnTimeline.value.trim(),
                    cupboard: fCupboard.value.trim(),
                    shelf1: fShelf1.value.trim(),
                    count1: fCount1.value ? parseInt(fCount1.value, 10) : 0,
                    shelf2: fShelf2.value.trim(),
                    count2: fCount2.value ? parseInt(fCount2.value, 10) : 0,
                    purpose: fPurpose.value.trim(),
                    comments: fComments.value.trim()
                });
            }

            if (editingId === null) {
                const duplicate = list.some(row => String(row[idKey]).toLowerCase() === itemId.toLowerCase());
                if (duplicate) {
                    showToast(`Item ID "${itemId}" already exists.`, 'error');
                    return;
                }
                baseItem.sno = list.length + 1;
                list.push(baseItem);
                showToast(`${TYPE_LABELS[modalView]} "${itemName}" added successfully.`, 'success');
            } else {
                const idx = list.findIndex(row => String(row[idKey]) === String(editingId));
                if (idx !== -1) {
                    list[idx] = { ...list[idx], ...baseItem, [idKey]: list[idx][idKey], sno: list[idx].sno };
                }
                showToast(`${TYPE_LABELS[modalView]} "${itemName}" updated successfully.`, 'success');
            }

            freshDb[modalView] = list;
            setDB(freshDb);
            db = freshDb;

            closeAssetModal();
            updateKPIs();
            renderTable();
        });
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    renderHeader();
    updateKPIs();
    renderTable();
});
