/* ============================================================
   SHARED UTILITIES & BASE LAYOUT
   ============================================================ */

const DB_KEY = 'ilp_inventory_db';

const DEFAULT_DB = {
    equipment: [
        {
            sno: 1,
            eqpid: 'EQP-001',
            name: '3D Printer',
            componentName: '3D Printer',
            make: 'Creality',
            specification: 'Ender 3 V2',
            totalCount: 3,
            componentType: 'Manufacturing Equipment',
            lab: 'Mechanical Lab',
            remarks: 'Working Fine',
            status: 'Available'
        },
        {
            sno: 2,
            eqpid: 'EQP-002',
            name: 'Laser Cutter',
            componentName: 'Laser Cutter',
            make: 'Ortur',
            specification: 'Laser Master 2',
            totalCount: 10,
            componentType: 'Manufacturing Equipment',
            lab: 'Mechanical Lab',
            remarks: 'Service Due',
            status: 'Maintenance'
        },
        {
            sno: 3,
            eqpid: 'EQP-003',
            name: 'CNC Machine',
            componentName: 'CNC Machine',
            make: 'Genmitsu',
            specification: '3018-PRO',
            totalCount: 5,
            componentType: 'Manufacturing Equipment',
            lab: 'Manufacturing Lab',
            remarks: 'Operational',
            status: 'Available'
        }
    ],
    components: [
        {
            sno: 1,
            cid: 'CMP-001',
            componentName: 'Arduino Uno',
            make: 'Arduino',
            specification: 'ATmega328P',
            cost: 850,
            returnTimeline: 'Project Completion',
            totalCount: 40,
            componentType: 'Electronics',
            lab: 'Embedded Lab',
            cupboard: 'CUP-1',
            shelf1: 'A1',
            count1: 20,
            shelf2: 'A2',
            count2: 20,
            purpose: 'Student Projects',
            comments: 'Available',
            status: 'Available'
        },
        {
            sno: 2,
            cid: 'CMP-002',
            componentName: 'Raspberry Pi 4',
            make: 'Raspberry',
            specification: '8GB RAM',
            cost: 7000,
            returnTimeline: 'Project Completion',
            totalCount: 15,
            componentType: 'Embedded',
            lab: 'IoT Lab',
            cupboard: 'CUP-2',
            shelf1: 'B1',
            count1: 8,
            shelf2: 'B2',
            count2: 7,
            purpose: 'Research',
            comments: 'Limited',
            status: 'Available'
        }
    ],
    tools: [
        {
            sno: 1,
            toolid: 'TLS-001',
            componentName: 'Screw Driver Set',
            make: 'Bosch',
            specification: 'Professional Kit',
            cost: 2500,
            returnTimeline: 'Project Completion',
            totalCount: 10,
            componentType: 'Hand Tool',
            lab: 'Mechanical Lab',
            cupboard: 'CUP-5',
            shelf1: 'A1',
            count1: 5,
            shelf2: 'A2',
            count2: 5,
            purpose: 'Maintenance',
            comments: 'Good Condition',
            status: 'Available'
        },
        {
            sno: 2,
            toolid: 'TLS-002',
            componentName: 'Soldering Iron',
            make: 'Hakko',
            specification: '60W',
            cost: 3200,
            returnTimeline: 'Project Completion',
            totalCount: 12,
            componentType: 'Electronic Tool',
            lab: 'Embedded Lab',
            cupboard: 'CUP-6',
            shelf1: 'B1',
            count1: 6,
            shelf2: 'B2',
            count2: 6,
            purpose: 'PCB Assembly',
            comments: 'Available',
            status: 'Repairing'
        }
    ]
};

function getDB() {
    try {
        const raw = localStorage.getItem(DB_KEY);
        if (!raw) {
            setDB(DEFAULT_DB);
            return structuredClone(DEFAULT_DB);
        }
        return JSON.parse(raw);
    } catch (err) {
        console.error('Failed to read DB', err);
        return structuredClone(DEFAULT_DB);
    }
}

function setDB(db) {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
}

function debounce(fn, delay = 250) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const icons = {
        success: '&#10003;',
        error: '&#10007;',
        warn: '&#9888;',
        info: '&#8505;'
    };

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${icons[type] || icons.info}</span>
            <span class="toast-message">${message}</span>
        </div>
        <button class="toast-close" aria-label="Close">&times;</button>
    `;

    container.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('show'));

    const remove = () => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.toast-close').addEventListener('click', remove);
    setTimeout(remove, 3500);
}

function createConfirmationModal(title, message, onConfirm, confirmLabel = 'Confirm', isDanger = false) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop show';
    backdrop.innerHTML = `
        <div class="modal-container" style="width: 480px;">
            <div class="modal-header">
                <div class="modal-header-left">
                    <div>
                        <h2 style="font-size:16px;font-weight:700;">${title}</h2>
                        <p style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${message}</p>
                    </div>
                </div>
                <button class="modal-close-btn" data-action="close" aria-label="Close">&times;</button>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-action="cancel">Cancel</button>
                <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'}" data-action="confirm">${confirmLabel}</button>
            </div>
        </div>
    `;

    const close = () => backdrop.remove();

    backdrop.querySelector('[data-action="close"]').addEventListener('click', close);
    backdrop.querySelector('[data-action="cancel"]').addEventListener('click', close);
    backdrop.querySelector('[data-action="confirm"]').addEventListener('click', () => {
        close();
        onConfirm();
    });
    backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) close();
    });

    document.body.appendChild(backdrop);
}

const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', href: 'dashboard.html' },
    { id: 'profiles', label: 'Add Profiles', href: 'add_profiles.html' },
    { id: 'faculty', label: 'Faculty List', href: 'faculty.html' },
    { id: 'trainee', label: 'Trainee List', href: 'trainee.html' },
    { id: 'inventory', label: 'Lab Asset Management', href: 'lab_asset_management.html' },
    { id: 'lowstock', label: 'Low Stock Alerts', href: 'low_stock_alerts.html' },
    { id: 'tickets', label: 'Raise damage Tickets', href: 'ticket_management.html' },
    { id: 'projects', label: 'Project Details', href: 'project_details.html' }
];

function renderBaseLayout(activePage) {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    const navHtml = NAV_ITEMS.map(item => `
        <li class="nav-item${item.id === activePage ? ' active' : ''}">
            <a href="${item.href}">${item.label}</a>
        </li>
    `).join('');

    sidebar.innerHTML = `
        <div class="sidebar-top">
            <div class="logo-container">
                <div class="logo-title">ILP</div>
                <div class="logo-subtitle">Rapid Prototyping Lab</div>
            </div>
            <div class="sidebar-category">Admin Portal</div>
            <ul class="nav-links">${navHtml}</ul>
        </div>
        <div class="sidebar-bottom">
            <ul class="logout-nav">
                <li><a href="dashboard.html">Sign Out</a></li>
            </ul>
        </div>
    `;

    const dateWidget = document.querySelector('.header-date-widget');
    if (dateWidget) {
        const now = new Date();
        dateWidget.innerHTML = `
            <div class="header-date-text">
                <span class="header-date-day">${now.toLocaleDateString('en-IN', { weekday: 'short' })}</span>
                <span class="header-date-full">${now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
            </div>
        `;
    }

    const toggleBtn = document.getElementById('sidebarToggleBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }
}
