/**
 * Request Status Trainee – Component Request Management
 * Integrated into Admin Portal sidebar layout
 */

'use strict';

const stages = [
    'Problem Statement',
    'Ideation & Concept Development',
    'Design Phase',
    'Product Development',
    'Testing & Validation',
    'Iteration & Improvement',
    'Advanced Prototype & MVP',
    'Evaluation & Demonstration',
    'Documentation',
    'Deployment'
];

const defaultTeams = [
    {
        id: 'PRJ-2025-01',
        name: 'Team Alpha',
        project: 'AI-Powered Inventory Management System',
        leader: 'Arun Kumar',
        faculty: 'Dr. Faculty Name',
        department: 'AI & DS'
    },
    {
        id: 'PRJ-2025-02',
        name: 'Team Beta',
        project: 'Smart Attendance Monitoring System',
        leader: 'Kavin Raj',
        faculty: 'Dr. Faculty Name',
        department: 'CSE'
    },
    {
        id: 'PRJ-2025-03',
        name: 'Team Gamma',
        project: 'IoT Based Energy Monitoring System',
        leader: 'Ramesh M',
        faculty: 'Dr. Faculty Name',
        department: 'ECE'
    },
    {
        id: 'PRJ-2025-04',
        name: 'Team Delta',
        project: 'Online Complaint Management Portal',
        leader: 'Sanjay T',
        faculty: 'Dr. Faculty Name',
        department: 'IT'
    },
    {
        id: 'PRJ-2025-05',
        name: 'Team Epsilon',
        project: 'Smart Library Book Tracking System',
        leader: 'Manoj K',
        faculty: 'Dr. Faculty Name',
        department: 'CSE'
    }
];

let appData = JSON.parse(localStorage.getItem('facultyReviewSeparateData'));
if (!appData || !appData.teams || !appData.teams.length) {
    appData = { teams: defaultTeams };
    localStorage.setItem('facultyReviewSeparateData', JSON.stringify(appData));
}

function saveAppData() {
    localStorage.setItem('facultyReviewSeparateData', JSON.stringify(appData));
}

const REQUESTS_KEY = 'facultyComponentRequests';

function getInitialRequests() {
    return [
        {
            id: 'CRQ-2025-001',
            team: 'Team Alpha',
            purpose: 'For IoT gateway development',
            status: 'Pending',
            requestedOn: '15 May 2025',
            deadline: '15 Jul 2025 (60 days left)',
            components: [
                { name: 'Raspberry Pi 4 Model B', quantity: 2, status: 'Pending' },
                { name: 'Jumper Wires Set', quantity: 2, status: 'Approved' },
                { name: '5V 3A Power Supply', quantity: 2, status: 'Pending' }
            ]
        },
        {
            id: 'CRQ-2025-002',
            team: 'Team Beta',
            purpose: 'For hardware interfacing and display',
            status: 'Approved',
            requestedOn: '10 May 2025',
            deadline: '10 Jun 2025 (Completed)',
            components: [
                { name: 'Arduino Mega 2560', quantity: 3, status: 'Approved' },
                { name: 'LCD Display 16x2', quantity: 2, status: 'Approved' }
            ]
        },
        {
            id: 'CRQ-2025-003',
            team: 'Team Gamma',
            purpose: 'For wireless communication prototyping',
            status: 'Pending',
            requestedOn: '18 May 2025',
            deadline: '20 Jul 2025 (65 days left)',
            components: [
                { name: 'ESP32 Dev Kit', quantity: 5, status: 'Pending' },
                { name: 'Breadboard Large', quantity: 3, status: 'Pending' }
            ]
        },
        {
            id: 'CRQ-2025-004',
            team: 'Team Delta',
            purpose: 'For image processing edge module',
            status: 'Rejected',
            requestedOn: '12 May 2025',
            deadline: '25 Jul 2025 (70 days left)',
            rejectionComment: 'Camera module unavailable this semester',
            components: [
                { name: 'Camera Module (Pi Cam)', quantity: 1, status: 'Rejected' }
            ]
        },
        {
            id: 'CRQ-2025-005',
            team: 'Team Epsilon',
            purpose: 'AI processing at the edge and tracking',
            status: 'Pending',
            requestedOn: '20 May 2025',
            deadline: '30 Aug 2025 (90 days left)',
            components: [
                { name: 'Nvidia Jetson Nano', quantity: 1, status: 'Pending' },
                { name: 'RFID RC522 Module', quantity: 4, status: 'Pending' },
                { name: 'RFID Tags (Card/Key)', quantity: 20, status: 'Pending' }
            ]
        }
    ];
}

function ensureComponentRequests() {
    const existing = localStorage.getItem(REQUESTS_KEY);
    let needsReset = false;

    if (existing) {
        try {
            const parsed = JSON.parse(existing);
            if (!parsed.length || !parsed[0].hasOwnProperty('components')) {
                needsReset = true;
            }
        } catch (e) {
            needsReset = true;
        }
    } else {
        needsReset = true;
    }

    if (needsReset) {
        localStorage.setItem(REQUESTS_KEY, JSON.stringify(getInitialRequests()));
    }
}

ensureComponentRequests();

let activeRequestForApproval = null;

const compTotalRequests = document.getElementById('compTotalRequests');
const compPendingRequests = document.getElementById('compPendingRequests');
const compApprovedRequests = document.getElementById('compApprovedRequests');
const compRejectedRequests = document.getElementById('compRejectedRequests');
const compSearch = document.getElementById('compSearch');
const compTeamFilter = document.getElementById('compTeamFilter');
const compStatusFilter = document.getElementById('compStatusFilter');
const compClearFilterBtn = document.getElementById('compClearFilterBtn');
const componentsRequestsTeamContainer = document.getElementById('componentsRequestsTeamContainer');

const viewComponentsModal = document.getElementById('viewComponentsModal');
const closeCompModalBtn = document.getElementById('closeCompModalBtn');
const compModalReqId = document.getElementById('compModalReqId');
const compModalTeam = document.getElementById('compModalTeam');
const compModalDate = document.getElementById('compModalDate');
const compModalDeadline = document.getElementById('compModalDeadline');
const compModalPurpose = document.getElementById('compModalPurpose');
const compModalTableBody = document.getElementById('compModalTableBody');
const selectAllComponents = document.getElementById('selectAllComponents');
const approveSelectedCompBtn = document.getElementById('approveSelectedCompBtn');
const rejectSelectedCompBtn = document.getElementById('rejectSelectedCompBtn');
const rejectReasonModal = document.getElementById('rejectReasonModal');
const rejectReasonInput = document.getElementById('rejectReasonInput');
const closeRejectReasonBtn = document.getElementById('closeRejectReasonBtn');
const cancelRejectReasonBtn = document.getElementById('cancelRejectReasonBtn');
const confirmRejectReasonBtn = document.getElementById('confirmRejectReasonBtn');
const toast = document.getElementById('toast');

const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const hamburgerBtn = document.getElementById('hamburgerBtn');

function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function renderCompTeamFilterOptions() {
    if (!compTeamFilter) return;
    const currentVal = compTeamFilter.value;
    compTeamFilter.innerHTML = '<option value="all">All Teams</option>';

    const requests = JSON.parse(localStorage.getItem(REQUESTS_KEY)) || [];
    const uniqueTeams = [...new Set(requests.map(r => r.team))];

    uniqueTeams.forEach(team => {
        const option = document.createElement('option');
        option.value = team;
        option.textContent = team;
        compTeamFilter.appendChild(option);
    });

    compTeamFilter.value = currentVal || 'all';
}

function renderComponentsRequest() {
    if (!componentsRequestsTeamContainer) return;

    const requests = JSON.parse(localStorage.getItem(REQUESTS_KEY)) || [];
    const query = compSearch.value.toLowerCase();
    const selectedTeam = compTeamFilter.value;
    const selectedStatus = compStatusFilter.value;

    const filtered = requests.filter(req => {
        const componentsText = req.components ? req.components.map(c => c.name).join(' ').toLowerCase() : '';
        const matchesSearch = componentsText.includes(query) ||
            req.team.toLowerCase().includes(query) ||
            req.id.toLowerCase().includes(query);
        const matchesTeam = selectedTeam === 'all' || req.team === selectedTeam;
        const matchesStatus = selectedStatus === 'all' || req.status === selectedStatus;
        return matchesSearch && matchesTeam && matchesStatus;
    });

    componentsRequestsTeamContainer.innerHTML = '';

    const total = filtered.length;
    const pending = filtered.filter(r => r.status === 'Pending').length;
    const approved = filtered.filter(r => r.status === 'Approved').length;
    const rejected = filtered.filter(r => r.status === 'Rejected').length;

    if (compTotalRequests) compTotalRequests.textContent = total;
    if (compPendingRequests) compPendingRequests.textContent = pending;
    if (compApprovedRequests) compApprovedRequests.textContent = approved;
    if (compRejectedRequests) compRejectedRequests.textContent = rejected;

    if (filtered.length === 0) {
        componentsRequestsTeamContainer.innerHTML =
            '<p class="muted comp-empty-state">No component requests found matching the filters.</p>';
        return;
    }

    const requestsByTeam = {};
    filtered.forEach(req => {
        if (!requestsByTeam[req.team]) requestsByTeam[req.team] = [];
        requestsByTeam[req.team].push(req);
    });

    Object.keys(requestsByTeam).forEach(teamName => {
        const teamRequests = requestsByTeam[teamName];
        const teamObj = appData.teams.find(t => t.name.toLowerCase() === teamName.toLowerCase()) || {};
        const projectDesc = teamObj.project || 'Active Rapid Prototyping Project';

        const card = document.createElement('div');
        card.className = 'panel team-request-card';

        let requestsTableRows = '';

        teamRequests.forEach(req => {
            const componentsSummary = req.components ? req.components.map(c => {
                let pillClass = 'status-pill status-draft';
                if (c.status === 'Pending') pillClass = 'status-pill status-review';
                if (c.status === 'Approved') pillClass = 'status-pill status-approved';
                if (c.status === 'Rejected') pillClass = 'status-pill status-rejected';
                return `<span class="${pillClass} comp-pill">${esc(c.name)} (${c.quantity})</span>`;
            }).join('') : '-';

            let overallBadgeClass = 'status-pill status-draft';
            if (req.status === 'Pending') overallBadgeClass = 'status-pill status-review';
            if (req.status === 'Approved') overallBadgeClass = 'status-pill status-approved';
            if (req.status === 'Rejected') overallBadgeClass = 'status-pill status-rejected';

            const reasonHtml = (req.status === 'Rejected' && req.rejectionComment)
                ? `<div class="rejection-reason">Reason: ${esc(req.rejectionComment)}</div>`
                : '';

            requestsTableRows += `
                <tr>
                    <td><b>${esc(req.id)}</b></td>
                    <td><div class="comp-summary-wrap">${componentsSummary}</div></td>
                    <td>${esc(req.purpose)}</td>
                    <td><span class="${overallBadgeClass}">${esc(req.status)}</span>${reasonHtml}</td>
                    <td>${esc(req.requestedOn)}</td>
                    <td>${esc(req.deadline || '-')}</td>
                    <td>
                        <button type="button" class="review-btn" data-req-id="${esc(req.id)}">View Components</button>
                    </td>
                </tr>
            `;
        });

        card.innerHTML = `
            <div class="panel-title team-request-header">
                <div>
                    <h3 class="team-request-title"><i class="fa-solid fa-users"></i> ${esc(teamName)}</h3>
                    <p class="muted team-request-project">Project: ${esc(projectDesc)}</p>
                </div>
                <span class="status-pill status-approved team-request-count">${teamRequests.length} Request(s)</span>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Requested Components</th>
                            <th>Purpose</th>
                            <th>Overall Status</th>
                            <th>Requested On</th>
                            <th>Deadline</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>${requestsTableRows}</tbody>
                </table>
            </div>
        `;

        card.querySelectorAll('.review-btn').forEach(btn => {
            btn.addEventListener('click', () => openComponentRequestModal(btn.dataset.reqId));
        });

        componentsRequestsTeamContainer.appendChild(card);
    });
}

function openComponentRequestModal(reqId) {
    const requests = JSON.parse(localStorage.getItem(REQUESTS_KEY)) || [];
    const req = requests.find(r => r.id === reqId);
    if (!req) return;

    activeRequestForApproval = reqId;

    compModalReqId.textContent = req.id;
    compModalTeam.textContent = req.team;
    compModalDate.textContent = req.requestedOn;
    compModalDeadline.textContent = req.deadline || '-';
    compModalPurpose.textContent = req.purpose;

    compModalTableBody.innerHTML = '';
    selectAllComponents.checked = false;

    const hasPendingComponents = req.components.some(c => c.status === 'Pending');
    const actionsDiv = document.getElementById('compModalActions');
    if (actionsDiv) {
        actionsDiv.style.display = hasPendingComponents ? 'flex' : 'none';
    }

    selectAllComponents.disabled = !hasPendingComponents;
    document.getElementById('compModalSubTitle').innerHTML =
        `<span class="comp-modal-subtitle"><i class="fa-solid fa-circle-info"></i> Manage components for ${esc(req.team)}</span>`;

    req.components.forEach((c, index) => {
        const row = document.createElement('tr');

        let checkboxHtml = '';
        if (c.status === 'Pending') {
            checkboxHtml = `<input type="checkbox" class="comp-item-checkbox" data-index="${index}">`;
        } else {
            checkboxHtml = '<input type="checkbox" disabled class="comp-item-checkbox-disabled">';
        }

        let qtyHtml = '';
        if (c.status === 'Pending') {
            qtyHtml = `<input type="number" class="comp-qty-input" data-index="${index}" value="${c.quantity}" min="1">`;
        } else {
            qtyHtml = `<span class="comp-qty-readonly">${c.quantity}</span>`;
        }

        let badgeClass = 'status-pill status-draft';
        if (c.status === 'Pending') badgeClass = 'status-pill status-review';
        if (c.status === 'Approved') badgeClass = 'status-pill status-approved';
        if (c.status === 'Rejected') badgeClass = 'status-pill status-rejected';

        row.innerHTML = `
            <td class="comp-checkbox-cell">${checkboxHtml}</td>
            <td><b>${esc(c.name)}</b></td>
            <td>${qtyHtml}</td>
            <td><span class="${badgeClass}">${esc(c.status)}</span></td>
        `;

        compModalTableBody.appendChild(row);

        const qtyInput = row.querySelector('.comp-qty-input');
        if (qtyInput) {
            qtyInput.addEventListener('change', function (e) {
                const qtyVal = parseInt(e.target.value, 10) || 1;
                const stored = JSON.parse(localStorage.getItem(REQUESTS_KEY)) || [];
                const reqIndex = stored.findIndex(r => r.id === reqId);
                if (reqIndex !== -1) {
                    stored[reqIndex].components[index].quantity = qtyVal;
                    localStorage.setItem(REQUESTS_KEY, JSON.stringify(stored));
                    req.components[index].quantity = qtyVal;
                }
            });
        }
    });

    selectAllComponents.onchange = function () {
        const checkboxes = compModalTableBody.querySelectorAll('.comp-item-checkbox:not(:disabled)');
        checkboxes.forEach(cb => { cb.checked = selectAllComponents.checked; });
    };

    viewComponentsModal.classList.add('show');
}

function bulkActionComponentRequests(action, rejectionComment = '') {
    if (!activeRequestForApproval) return;

    const requests = JSON.parse(localStorage.getItem(REQUESTS_KEY)) || [];
    const reqIndex = requests.findIndex(r => r.id === activeRequestForApproval);
    if (reqIndex === -1) return;

    const req = requests[reqIndex];
    const checkboxes = compModalTableBody.querySelectorAll('.comp-item-checkbox:checked');

    if (checkboxes.length === 0) {
        showToast('Please select at least one component first.');
        return;
    }

    if (action === 'Rejected') {
        rejectionComment = rejectionComment.trim();
        if (!rejectionComment) {
            showToast('Rejection comment is required to reject a request.');
            return;
        }
        req.rejectionComment = rejectionComment;
    } else {
        delete req.rejectionComment;
    }

    checkboxes.forEach(cb => {
        const index = parseInt(cb.dataset.index, 10);
        req.components[index].status = action;
    });

    const hasPending = req.components.some(c => c.status === 'Pending');
    if (hasPending) {
        req.status = 'Pending';
    } else if (req.components.some(c => c.status === 'Approved')) {
        req.status = 'Approved';
    } else {
        req.status = 'Rejected';
    }

    requests[reqIndex] = req;
    localStorage.setItem(REQUESTS_KEY, JSON.stringify(requests));

    showToast(`Selected components have been ${action.toLowerCase()}.`);
    viewComponentsModal.classList.remove('show');
    if (rejectReasonModal) rejectReasonModal.classList.remove('show');
    renderComponentsRequest();
}

function openRejectReasonModal() {
    if (!activeRequestForApproval) return;

    const checkboxes = compModalTableBody.querySelectorAll('.comp-item-checkbox:checked');
    if (checkboxes.length === 0) {
        showToast('Please select at least one component first.');
        return;
    }

    if (rejectReasonInput) rejectReasonInput.value = '';
    if (rejectReasonModal) rejectReasonModal.classList.add('show');
    if (rejectReasonInput) rejectReasonInput.focus();
}

function closeRejectReasonModal() {
    if (rejectReasonModal) rejectReasonModal.classList.remove('show');
    if (rejectReasonInput) rejectReasonInput.value = '';
}

function initSidebar() {
    if (hamburgerBtn && sidebar && sidebarOverlay) {
        hamburgerBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
        });
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
        });
    }

    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const targetId = btn.getAttribute('aria-controls');
            const group = btn.closest('.nav-group');
            const menu = document.getElementById(targetId) || (group ? group.querySelector('.dropdown-menu') : null);
            const isActive = btn.classList.contains('active');

            document.querySelectorAll('.dropdown-toggle').forEach(t => {
                t.classList.remove('active');
                t.setAttribute('aria-expanded', 'false');
            });
            document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));
            document.querySelectorAll('.sub-dropdown-toggle').forEach(t => {
                t.classList.remove('active');
                t.setAttribute('aria-expanded', 'false');
            });
            document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));

            if (!isActive && menu) {
                btn.classList.add('active');
                btn.setAttribute('aria-expanded', 'true');
                menu.classList.add('active');
            }
        });
    });

    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const targetId = btn.getAttribute('aria-controls');
            const group = btn.closest('.nav-subgroup');
            const menu = document.getElementById(targetId) || (group ? group.querySelector('.sub-dropdown-menu') : null);
            const isActive = btn.classList.contains('active');

            if (menu) {
                if (isActive) {
                    btn.classList.remove('active');
                    btn.setAttribute('aria-expanded', 'false');
                    menu.classList.remove('active');
                } else {
                    btn.classList.add('active');
                    btn.setAttribute('aria-expanded', 'true');
                    menu.classList.add('active');
                }
            }
        });
    });
}

function initPage() {
    if (compSearch) compSearch.addEventListener('input', renderComponentsRequest);
    if (compTeamFilter) compTeamFilter.addEventListener('change', renderComponentsRequest);
    if (compStatusFilter) compStatusFilter.addEventListener('change', renderComponentsRequest);
    if (compClearFilterBtn) {
        compClearFilterBtn.addEventListener('click', () => {
            compSearch.value = '';
            compTeamFilter.value = 'all';
            compStatusFilter.value = 'all';
            renderComponentsRequest();
        });
    }

    if (approveSelectedCompBtn) {
        approveSelectedCompBtn.addEventListener('click', () => bulkActionComponentRequests('Approved'));
    }
    if (rejectSelectedCompBtn) {
        rejectSelectedCompBtn.addEventListener('click', openRejectReasonModal);
    }
    if (confirmRejectReasonBtn) {
        confirmRejectReasonBtn.addEventListener('click', () => {
            bulkActionComponentRequests('Rejected', rejectReasonInput ? rejectReasonInput.value : '');
        });
    }
    if (closeRejectReasonBtn) {
        closeRejectReasonBtn.addEventListener('click', closeRejectReasonModal);
    }
    if (cancelRejectReasonBtn) {
        cancelRejectReasonBtn.addEventListener('click', closeRejectReasonModal);
    }
    if (rejectReasonModal) {
        rejectReasonModal.addEventListener('click', (e) => {
            if (e.target === rejectReasonModal) closeRejectReasonModal();
        });
    }
    if (closeCompModalBtn) {
        closeCompModalBtn.addEventListener('click', () => viewComponentsModal.classList.remove('show'));
    }
    if (viewComponentsModal) {
        viewComponentsModal.addEventListener('click', (e) => {
            if (e.target === viewComponentsModal) viewComponentsModal.classList.remove('show');
        });
    }

    initSidebar();
    renderCompTeamFilterOptions();
    renderComponentsRequest();

    if (typeof lucide !== 'undefined') lucide.createIcons();
}

window.openComponentRequestModal = openComponentRequestModal;

initPage();
