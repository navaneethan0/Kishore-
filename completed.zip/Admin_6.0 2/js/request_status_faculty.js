// --- Sidebar UI Logic ---
document.addEventListener("DOMContentLoaded", function () {
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    if (hamburgerBtn) {
        hamburgerBtn.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('active');
        });
    }

    const sidebarOverlay = document.getElementById('sidebarOverlay');
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            document.getElementById('sidebar').classList.remove('open');
            sidebarOverlay.classList.remove('active');
        });
    }

    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const group = btn.closest('.nav-item');
            const menu = group ? group.querySelector('.dropdown-menu') : null;
            if(!menu) return;
            const isActive = btn.classList.contains('active');
            
            // Close other top level dropdowns
            if (!btn.classList.contains('sub-dropdown-toggle')) {
                document.querySelectorAll('.dropdown-toggle:not(.sub-dropdown-toggle)').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.dropdown-menu:not(.sub-dropdown-menu)').forEach(m => m.classList.remove('active'));
            } else {
                document.querySelectorAll('.sub-dropdown-toggle').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));
            }

            if (!isActive) {
                btn.classList.add('active');
                menu.classList.add('active');
            }
        });
    });

    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const group = btn.closest('.nav-item');
            const menu = group ? group.querySelector('.sub-dropdown-menu') : null;
            if(!menu) return;
            const isActive = btn.classList.contains('active');
            
            document.querySelectorAll('.sub-dropdown-toggle').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.sub-dropdown-menu').forEach(m => m.classList.remove('active'));
            
            if (!isActive) {
                btn.classList.add('active');
                menu.classList.add('active');
            }
        });
    });

    try { lucide.createIcons(); } catch(e) {}
});

document.addEventListener("DOMContentLoaded", function () {
    // We already rendered the base layout from the HTML
});

// Seedable Random for 80+ dynamic requests
function mulberry32(seed) {
    return function () {
        let t = seed += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
}
const rnd = mulberry32(100234);

// Core assets state
const INVENTORY = {
    components: [
        { id: "C001", name: "Arduino Uno R3", cat: "Microcontrollers", stock: 18 },
        { id: "C002", name: "Raspberry Pi 4", cat: "Single Board Computers", stock: 2 },
        { id: "C003", name: "ESP32 NodeMCU", cat: "Microcontrollers", stock: 25 },
        { id: "C004", name: "SG90 Micro Servo", cat: "Motors", stock: 40 },
        { id: "C005", name: "HC-SR04 ultrasonic", cat: "Sensors", stock: 0 },
        { id: "C006", name: "PIR motion sensor", cat: "Sensors", stock: 12 },
        { id: "C007", name: "5V Relay module", cat: "Power", stock: 9 },
        { id: "C008", name: "Breadboard Full", cat: "Prototyping", stock: 35 },
        { id: "C009", name: "Jumper Wires pack", cat: "Cabling", stock: 50 },
        { id: "C010", name: "10K Potentiometer", cat: "Resistors", stock: 8 },
        { id: "C011", name: "Nema 17 Stepper", cat: "Motors", stock: 5 }
    ],
    tools: [
        { id: "T001", name: "Soldering Station", cat: "Assembly", stock: 6 },
        { id: "T002", name: "Digital Multimeter", cat: "Testing", stock: 15 },
        { id: "T003", name: "Hot Glue Gun", cat: "Splicing", stock: 1 },
        { id: "T004", name: "PLA Filament 3D", cat: "Additives", stock: 0 },
        { id: "T005", name: "Wire Stripper", cat: "Hand Tools", stock: 20 },
        { id: "T006", name: "Allen Key wrench kit", cat: "Hand Tools", stock: 10 }
    ]
};

const LABS = ["Electronics Lab", "Mechanical Lab", "Robotics Lab", "IoT Lab", "Fabrication Lab"];
const FACULTY = ["Dr. Priya S.", "Prof. Robert M.", "Dr. Vikram K.", "Prof. Anita Sen", "Dr. Sarah Paul"];
const TEAM_PROJECTS = [
    { id: "TEM-081", name: "EcoGrid Smart Metering", team: "Smart Grid Team" },
    { id: "TEM-102", name: "Biomimetic Quadruped Robot", team: "HexaPeds" },
    { id: "TEM-305", name: "Autonomous Warehouse Rover", team: "LogiBots" },
    { id: "TEM-240", name: "Home Automation via LoRa", team: "Wireless Home" },
    { id: "TEM-041", name: "Automated Plant Watering", team: "AquaGrow" },
    { id: "TEM-199", name: "SDR Satellite Transceiver", team: "OrbitComms" },
    { id: "TEM-053", name: "Adaptive Solar Array Pathing", team: "SunTrackers" },
    { id: "TEM-067", name: "CNC PCB Engraver", team: "PrecisionMill" }
];

// Seed 85 team requests
let requests = [];
let issueHistory = [];

function generateDummyData() {
    for (let i = 1; i <= 85; i++) {
        const project = TEAM_PROJECTS[Math.floor(rnd() * TEAM_PROJECTS.length)];
        const lab = LABS[Math.floor(rnd() * LABS.length)];
        const guide = FACULTY[Math.floor(rnd() * FACULTY.length)];
        const day = Math.floor(rnd() * 28) + 1;
        const reqDate = `${day} Jun 2026`;

        // Select 1 to 4 random components and 0 to 2 random tools
        const childComps = [];
        const compIndices = [...Array(INVENTORY.components.length).keys()].sort(() => rnd() - 0.5);
        const compCount = Math.floor(rnd() * 3) + 1; // 1-3 components
        for (let k = 0; k < compCount; k++) {
            const template = INVENTORY.components[compIndices[k]];
            const requested = Math.floor(rnd() * 4) + 1;
            childComps.push({
                id: template.id,
                name: template.name,
                requested: requested,
                provided: 0,
                delivered: false
            });
        }

        const childTools = [];
        const toolIndices = [...Array(INVENTORY.tools.length).keys()].sort(() => rnd() - 0.5);
        const toolCount = Math.floor(rnd() * 2); // 0-1 tools
        for (let k = 0; k < toolCount; k++) {
            const template = INVENTORY.tools[toolIndices[k]];
            const requested = Math.floor(rnd() * 2) + 1;
            childTools.push({
                id: template.id,
                name: template.name,
                requested: requested,
                provided: 0,
                delivered: false
            });
        }

        // Initial request status
        let status = "Pending";
        const rollStatus = rnd();
        if (rollStatus < 0.25) {
            status = "Pending";
            // Make some items marked as delivered in draft
            childComps[0].delivered = true;
            childComps[0].provided = Math.min(childComps[0].requested, getItemStock(childComps[0].id, true));
        } else if (rollStatus < 0.45) {
            status = "Delivered";
            childComps.forEach(c => {
                c.delivered = true;
                c.provided = c.requested;
            });
            childTools.forEach(t => {
                t.delivered = true;
                t.provided = t.requested;
            });
        }

        requests.push({
            requestId: "REQ-" + String(i).padStart(3, "0"),
            teamId: project.id,
            teamName: project.team,
            projectName: project.name,
            requestedBy: `Student ${Math.floor(rnd() * 10) + 1}`,
            facultyGuide: guide,
            requestDate: reqDate,
            lab: lab,
            status: status,
            components: childComps,
            tools: childTools
        });
    }
    
    // Check if real DB has items and overlay them (hybrid approach)
    try {
        let db = getDB();
        if (db && db.materialRequests && db.materialRequests.length > 0) {
            // Push db material requests into the UI
            db.materialRequests.forEach((r, idx) => {
                // If it's a simple request, format it to work with this UI
                let mappedStatus = "Pending";
                if (r.status === "Fully Issued") mappedStatus = "Delivered";
                else if (r.status === "Approved") mappedStatus = "Delivered";
                else if (r.status === "Rejected") mappedStatus = "Rejected";
                
                let prov = r.issuedQty || 0;
                let reqQty = r.qty || 1;
                let isDel = (prov >= reqQty) || (mappedStatus === "Delivered");

                requests.unshift({
                    requestId: r.id || ("REQ-DB-" + idx),
                    teamId: r.teamId || "TEM-000",
                    teamName: r.teamName || "External Team",
                    projectName: "Project " + (r.item || ""),
                    requestedBy: "Unknown",
                    facultyGuide: "Dr. Faculty",
                    requestDate: r.date || "Today",
                    lab: "Electronics Lab",
                    status: mappedStatus,
                    components: [{
                        id: "C-" + idx,
                        name: r.item || "Unknown Component",
                        requested: reqQty,
                        provided: prov,
                        delivered: isDel
                    }],
                    tools: [],
                    originalDbRef: r
                });
            });
        }
    } catch(e) { }

    // Sync issue records
    generateIssueHistoryRecords();
}

function generateIssueHistoryRecords() {
    issueHistory = [];
    requests.forEach(r => {
        if (r.status === "Delivered" || (r.status === "Pending" && (r.components.some(c => c.delivered) || r.tools.some(t => t.delivered)))) {
            const totalIssued = r.components.reduce((sum, c) => sum + (c.delivered ? c.provided : 0), 0) +
                r.tools.reduce((sum, t) => sum + (t.delivered ? t.provided : 0), 0);
            const totalPending = r.components.reduce((sum, c) => sum + (!c.delivered ? c.requested : (c.requested - c.provided)), 0) +
                r.tools.reduce((sum, t) => sum + (!t.delivered ? t.requested : (t.requested - t.provided)), 0);

            issueHistory.push({
                issueId: "ISS-" + r.requestId.split('-').pop(), // Use end part for ID
                requestId: r.requestId,
                team: `${r.teamName} (${r.teamId})`,
                project: r.projectName,
                issuedQty: totalIssued,
                pendingQty: totalPending,
                status: r.status,
                lab: r.lab
            });
        }
    });
}

function getItemStock(itemId, isComp) {
    const list = isComp ? INVENTORY.components : INVENTORY.tools;
    const match = list.find(x => x.id === itemId);
    return match ? match.stock : Math.floor(Math.random() * 20) + 1; // fake stock for DB items
}

function setItemStock(itemId, isComp, deduction) {
    const list = isComp ? INVENTORY.components : INVENTORY.tools;
    const match = list.find(x => x.id === itemId);
    if (match) {
        match.stock = Math.max(0, match.stock - deduction);
    }
}

// Active State
let currentTab = "requests";
let activeRequest = null;
let filters = { search: "", status: "all", lab: "all", sort: "newest" };

function switchView(tab) {
    currentTab = tab;
    document.getElementById('tabRequestsBtn').classList.toggle('active', tab === 'requests');
    document.getElementById('tabHistoryBtn').classList.toggle('active', tab === 'history');
    document.getElementById('viewRequests').classList.toggle('active', tab === 'requests');
    document.getElementById('viewHistory').classList.toggle('active', tab === 'history');

    if (tab === 'requests') {
        document.getElementById('pageTitleText').textContent = "Component Requests";
        document.getElementById('pageSubtitleText').textContent = "Review and issue component requests submitted by project teams.";
        document.querySelector('.toolbar').style.display = 'flex';
    } else {
        document.getElementById('pageTitleText').textContent = "Component Issue History";
        document.getElementById('pageSubtitleText').textContent = "Track issued items ledger and fulfill outstanding stock-shortage items.";
        document.querySelector('.toolbar').style.display = 'flex';
    }
    renderAll();
}

function getVisibleData() {
    const searchLower = filters.search.toLowerCase();
    if (currentTab === "requests") {
        return requests.filter(r => {
            const matchSearch = r.teamId.toLowerCase().includes(searchLower) ||
                r.teamName.toLowerCase().includes(searchLower) ||
                r.projectName.toLowerCase().includes(searchLower);
            const matchStatus = filters.status === "all" || r.status === filters.status;
            const matchLab = filters.lab === "all" || r.lab === filters.lab;
            return matchSearch && matchStatus && matchLab;
        }).sort((a, b) => {
            const dateA = new Date(a.requestDate);
            const dateB = new Date(b.requestDate);
            return filters.sort === "newest" ? dateB - dateA : dateA - dateB;
        });
    } else {
        // history tab
        return issueHistory.filter(h => {
            const matchSearch = h.team.toLowerCase().includes(searchLower) || h.project.toLowerCase().includes(searchLower);
            const matchStatus = filters.status === "all" || h.status === filters.status;
            const matchLab = filters.lab === "all" || h.lab === filters.lab;
            return matchSearch && matchStatus && matchLab;
        });
    }
}

function renderKPIs() {
    const pendingCount = requests.filter(r => r.status === "Pending" && !r.components.some(c => c.delivered) && !r.tools.some(t => t.delivered)).length;
    const partialCount = requests.filter(r => r.status === "Pending" && (r.components.some(c => c.delivered) || r.tools.some(t => t.delivered))).length;
    const completedCount = requests.filter(r => r.status === "Delivered").length;

    document.getElementById('kpiPending').textContent = pendingCount;
    document.getElementById('kpiPartial').textContent = partialCount;
    document.getElementById('kpiCompleted').textContent = completedCount;
}

function renderCards() {
    const container = document.getElementById('cardsGridContainer');
    const data = getVisibleData();
    if (!data.length) {
        container.innerHTML = `<div style="grid-column: 1/-1; padding:40px; text-align:center; color:var(--muted); font-weight:500;">No requests match the selected filters.</div>`;
        return;
    }

    container.innerHTML = data.map(r => {
        const badgeClass = r.status === 'Delivered' ? 'completed' : 'pending';
        return `
            <div class="req-card">
                <div class="card-header">
                    <span class="badge ${badgeClass}">${r.status}</span>
                </div>
                <div class="card-body">
                    <div><strong>Team ID</strong> ${r.teamId}</div>
                    <div><strong>Request ID</strong> ${r.requestId}</div>
                </div>
                <button class="btn btn-primary" onclick="openReviewDrawer('${r.requestId}')">Review Request</button>
            </div>
        `;
    }).join('');
}

function renderHistoryTable() {
    const tbody = document.getElementById('historyTableBody');
    const data = getVisibleData();
    if (!data.length) {
        tbody.innerHTML = `<tr><td colspan="7" style="padding:30px; text-align:center; color:var(--muted); font-weight:500;">No issue history available.</td></tr>`;
        return;
    }

    tbody.innerHTML = data.map(h => {
        const isPartial = h.status === "Pending";
        const actionCell = isPartial
            ? `<a class="action-link" onclick="openReviewDrawer('${h.requestId}', true)">Continue Issue</a>`
            : `<span style="color:var(--muted); font-weight:500; font-size:12px;">None</span>`;
        const badgeClass = h.status === 'Delivered' ? 'completed' : 'pending';

        return `
            <tr>
                <td><strong>${h.issueId}</strong></td>
                <td>${h.team}</td>
                <td>${h.project}</td>
                <td>${h.issuedQty} items</td>
                <td>${h.pendingQty} items</td>
                <td><span class="badge ${badgeClass}">${h.status}</span></td>
                <td>${actionCell}</td>
            </tr>
        `;
    }).join('');
}

function renderAll() {
    renderKPIs();
    if (currentTab === "requests") {
        renderCards();
    } else {
        renderHistoryTable();
    }
}

// Open Dialog Details Drawer
let drawerContinueOnly = false; // true if opened via "Continue Issue" link
function openReviewDrawer(requestId, isContinue = false) {
    activeRequest = requests.find(x => x.requestId === requestId);
    if (!activeRequest) return;
    drawerContinueOnly = isContinue;

    // Header labels
    document.getElementById('drawerTitle').textContent = isContinue ? "Continue Issuing Items" : "Review Request";
    const badge = document.getElementById('drawerStatusBadge');
    badge.textContent = activeRequest.status;
    badge.className = `badge ${activeRequest.status === 'Delivered' ? 'completed' : 'pending'}`;

    // Team metadata
    document.getElementById('mdTeam').textContent = `${activeRequest.teamName} (${activeRequest.teamId})`;
    document.getElementById('mdProject').textContent = activeRequest.projectName;
    document.getElementById('mdGuide').textContent = activeRequest.facultyGuide;
    document.getElementById('mdDate').textContent = activeRequest.requestDate;

    // Render tables
    const compSection = document.getElementById('wrapperComponentsTable');
    const toolSection = document.getElementById('wrapperToolsTable');

    const compsToRender = isContinue
        ? activeRequest.components.filter(c => !c.delivered || c.provided < c.requested)
        : activeRequest.components;
    const toolsToRender = isContinue
        ? activeRequest.tools.filter(t => !t.delivered || t.provided < t.requested)
        : activeRequest.tools;

    // Toggle table layouts
    compSection.style.display = compsToRender.length > 0 ? "block" : "none";
    toolSection.style.display = toolsToRender.length > 0 ? "block" : "none";

    renderDrawerTableBody('bodyComponents', compsToRender, true);
    renderDrawerTableBody('bodyTools', toolsToRender, false);

    recalculateSummary();

    document.getElementById('drawerOverlay').classList.add('show');
    document.getElementById('reviewDrawer').classList.add('show');
}

window.openReviewDrawer = openReviewDrawer; // Ensure accessible globally

function renderDrawerTableBody(elementId, items, isComp) {
    const tbody = document.getElementById(elementId);
    tbody.innerHTML = "";

    items.forEach((item, index) => {
        const stock = getItemStock(item.id, isComp);
        const type = isComp ? 'c' : 't';
        const id = item.id;
        const suggestedQty = item.delivered ? item.provided : Math.min(item.requested, stock);
        const isCheckedState = item.delivered;

        let checkCell = "";
        let qtyInputHtml = "";

        if (stock === 0) {
            checkCell = ""; // Hidden
            qtyInputHtml = `<input type="number" class="qty-input" id="qty-${type}-${id}" value="0" disabled>`;
        } else {
            checkCell = `<input type="checkbox" id="chk-${type}-${id}" ${isCheckedState ? 'checked' : ''} onchange="recalculateSummary()" style="transform: scale(1.15); cursor: pointer;">`;
            qtyInputHtml = `
                <input type="number" class="qty-input" id="qty-${type}-${id}" 
                    value="${suggestedQty}" min="0" max="${Math.min(item.requested, stock)}"
                    oninput="validateInput('${type}', '${id}', ${stock}, ${item.requested})"
                >
            `;
        }

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${id}</strong></td>
            <td style="max-width:140px; overflow:hidden; text-overflow:ellipsis;">${item.name}</td>
            <td>${stock}</td>
            <td>${item.requested}</td>
            <td>${qtyInputHtml}</td>
            <td style="text-align:right;">${checkCell}</td>
        `;
        tbody.appendChild(tr);
    });
}

function validateInput(type, itemId, stock, requested) {
    const input = document.getElementById(`qty-${type}-${itemId}`);
    let val = parseInt(input.value) || 0;
    const maxVal = Math.min(requested, stock);

    if (val > maxVal) {
        val = maxVal;
        input.value = val;
    }
    if (val < 0) {
        val = 0;
        input.value = val;
    }

    recalculateSummary();
}
window.validateInput = validateInput;

function recalculateSummary() {
    if (!activeRequest) return;

    let totalRequested = 0;
    let totalToIssue = 0;
    let totalShortage = 0;
    let allDelivered = true;

    const processItems = (items, isComp) => {
        items.forEach(item => {
            totalRequested += item.requested;
            const qtyInput = document.getElementById(`qty-${isComp ? 'c' : 't'}-${item.id}`);
            const chkInput = document.getElementById(`chk-${isComp ? 'c' : 't'}-${item.id}`);

            let isChecked = false;
            let val = 0;

            if (qtyInput) {
                isChecked = chkInput ? chkInput.checked : false;
                val = parseInt(qtyInput.value) || 0;
            } else {
                isChecked = item.delivered;
                val = item.provided || 0;
            }

            if (isChecked) {
                totalToIssue += val;
                totalShortage += (item.requested - val);
            } else {
                totalShortage += item.requested;
            }

            const stock = getItemStock(item.id, isComp);
            if (!isChecked || val < item.requested) {
                allDelivered = false;
            }
        });
    }

    processItems(activeRequest.components, true);
    processItems(activeRequest.tools, false);

    document.getElementById('sumRequested').textContent = totalRequested;
    document.getElementById('sumToIssue').textContent = totalToIssue;
    document.getElementById('sumShortage').textContent = totalShortage;

    const statusText = allDelivered ? "Delivered" : "Pending";
    const badge = document.getElementById('drawerStatusBadge');
    badge.textContent = statusText;
    badge.className = `badge ${allDelivered ? 'completed' : 'pending'}`;

    document.getElementById('sumStatus').textContent = statusText;
}

window.recalculateSummary = recalculateSummary;

function closeDrawer() {
    document.getElementById('drawerOverlay').classList.remove('show');
    document.getElementById('reviewDrawer').classList.remove('show');
    activeRequest = null;
}
window.closeDrawer = closeDrawer;

function approveAndIssue() {
    if (!activeRequest) return;

    let totalIssued = 0;
    let totalShortage = 0;
    let allDelivered = true;

    const processItems = (items, isComp) => {
        items.forEach(item => {
            const qtyInput = document.getElementById(`qty-${isComp ? 'c' : 't'}-${item.id}`);
            const chkInput = document.getElementById(`chk-${isComp ? 'c' : 't'}-${item.id}`);

            if (qtyInput) {
                const isChecked = chkInput ? chkInput.checked : false;
                const qtyVal = parseInt(qtyInput.value) || 0;

                if (isChecked) {
                    if (qtyVal > 0) {
                        setItemStock(item.id, isComp, qtyVal);
                    }
                    item.provided = (drawerContinueOnly ? item.provided || 0 : 0) + qtyVal;
                    item.delivered = true;
                    totalIssued += qtyVal;
                } else {
                    if (!drawerContinueOnly) {
                        item.delivered = false;
                        item.provided = 0;
                    }
                }
            }

            if (item.provided < item.requested || !item.delivered) {
                allDelivered = false;
                totalShortage += (item.requested - (item.provided || 0));
            }
        });
    }

    processItems(activeRequest.components, true);
    processItems(activeRequest.tools, false);

    const finalStatus = allDelivered ? "Delivered" : "Pending";
    activeRequest.status = finalStatus;

    if (activeRequest.originalDbRef) {
        // Sync back to db
        try {
            let db = getDB();
            let dbReq = db.materialRequests.find(r => r.id === activeRequest.originalDbRef.id);
            if (dbReq) {
                dbReq.issuedQty = activeRequest.components[0].provided;
                dbReq.pendingQty = activeRequest.components[0].requested - dbReq.issuedQty;
                dbReq.status = finalStatus === "Delivered" ? "Fully Issued" : "Partially Issued";
                setDB(db);
            }
        } catch(e) {}
    }

    const oldIssue = issueHistory.find(x => x.requestId === activeRequest.requestId);
    if (oldIssue) {
        oldIssue.issuedQty = activeRequest.components.reduce((sum, c) => sum + (c.provided || 0), 0) +
            activeRequest.tools.reduce((sum, t) => sum + (t.provided || 0), 0);
        oldIssue.pendingQty = totalShortage;
        oldIssue.status = finalStatus;
    } else {
        generateIssueHistoryRecords();
    }

    showToast(finalStatus === "Delivered" ? "Request fully approved & components issued!" : "Fulfill partial approved request!");
    closeDrawer();
    renderAll();
}
window.approveAndIssue = approveAndIssue;

// Search & Filter controls
function handleFiltersChange() {
    filters.search = document.getElementById('searchInput').value;
    filters.status = document.getElementById('statusFilter').value;
    filters.lab = document.getElementById('labFilter').value;
    filters.sort = document.getElementById('sortFilter').value;
    renderAll();
}
window.handleFiltersChange = handleFiltersChange;

function clearFilters() {
    document.getElementById('searchInput').value = "";
    document.getElementById('statusFilter').value = "all";
    document.getElementById('labFilter').value = "all";
    document.getElementById('sortFilter').value = "newest";
    filters = { search: "", status: "all", lab: "all", sort: "newest" };
    renderAll();
}
window.clearFilters = clearFilters;

// Show Toast
let toastTimer;
function showToast(msg) {
    const t = document.getElementById('toast');
    if (!t) return;
    document.getElementById('toastText').textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

// Initialize Page
generateDummyData();
renderAll();

