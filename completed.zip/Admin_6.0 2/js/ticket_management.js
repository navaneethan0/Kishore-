﻿// Ticket Management Controller
document.addEventListener("DOMContentLoaded", function () {

  // Ensure mock data exists so dropdowns and tables aren't empty
  (function initMockData() {
    var db = getDB();
    let updated = false;
    
    if (!db.teams || db.teams.length === 0) {
      db.teams = [
        { id: "TEAM-001", name: "Alpha Squad" },
        { id: "TEAM-002", name: "Beta Innovators" },
        { id: "TEAM-003", name: "Gamma Creators" }
      ];
      updated = true;
    }
    
    if (!db.inventory || db.inventory.length === 0) {
      db.inventory = [];
      // Combine equipment/components/tools as inventory for the mock
      (db.equipment || []).forEach(e => db.inventory.push({ id: e.eqpid, name: e.componentName || e.name, type: "Equipment", status: e.status }));
      (db.components || []).forEach(c => db.inventory.push({ id: c.cid, name: c.componentName || c.name, type: "Component", status: c.status }));
      (db.tools || []).forEach(t => db.inventory.push({ id: t.toolid, name: t.componentName || t.name, type: "Tool", status: t.status }));
      
      // Fallback if common.js is also empty
      if (db.inventory.length === 0) {
        db.inventory = [
          { id: "EQP-001", name: "3D Printer", type: "Equipment", status: "Available" },
          { id: "EQP-002", name: "Laser Cutter", type: "Equipment", status: "Maintenance" },
          { id: "TL-055", name: "Soldering Station", type: "Tool", status: "Available" }
        ];
      }
      updated = true;
    }
    
    if (!db.tickets || db.tickets.length === 0) {
      db.tickets = [
        {
          id: "TKT-001", type: "Damage", assignedTo: "TEAM-001", subject: "3D Printer Jam", 
          priority: "High", date: "10 Jul 2026", status: "Open", teamName: "Alpha Squad", 
          equipmentName: "3D Printer", raisedBy: "Lab Incharge", time: "10:30 AM", 
          damageDescription: "Nozzle is clogged completely.", fineAmount: "0", 
          dueDate: "17 Jul 2026", remarks: "", lastUpdated: "10 Jul 2026, 10:30 AM", timeSlot: "10:00 - 11:00"
        }
      ];
      updated = true;
    }
    
    if (updated && typeof setDB === 'function') setDB(db);
  })();


  var activeTableBody = document.getElementById("activeTicketsTableBody");

  function parseDBDateToInputDate(s) {
    if (!s) return "";
    var p = s.trim().split(/\s+/);
    if (p.length < 3) return "";
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var mi = months.indexOf(p[1]);
    if (mi === -1) return "";
    return p[2] + "-" + String(mi + 1).padStart(2, "0") + "-" + p[0].padStart(2, "0");
  }

  function formatInputDateToDBDate(s) {
    if (!s) return "";
    var p = s.split("-");
    if (p.length < 3) return "";
    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return String(parseInt(p[2])).padStart(2, "0") + " " + months[parseInt(p[1]) - 1] + " " + p[0];
  }

  function esc(str) {
    if (str == null) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  if (typeof escapeHtml === "undefined") window.escapeHtml = esc;

  var filterStatus = "All", filterTeam = "All", filterPriority = "All", filterSearch = "";

  function initFilterTeams() {
    var db = getDB(), sel = document.getElementById("filterTeamSelect");
    if (!sel) return;
    sel.innerHTML = "<option value='All'>All Teams</option>";
    (db.teams || []).forEach(function (t) {
      var o = document.createElement("option");
      o.value = t.id;
      o.textContent = t.id + " - " + t.name;
      sel.appendChild(o);
    });
  }

  var stab = document.getElementById("ticketStatusFilters");
  if (stab) stab.addEventListener("click", function (e) {
    var b = e.target.closest(".filter-tab"); if (!b) return;
    stab.querySelectorAll(".filter-tab").forEach(function (x) { x.classList.remove("active"); });
    b.classList.add("active"); filterStatus = b.dataset.status; renderActiveTickets();
  });

  var tsel = document.getElementById("filterTeamSelect");
  if (tsel) tsel.addEventListener("change", function (e) { filterTeam = e.target.value; renderActiveTickets(); });


  var sinp = document.getElementById("searchTicketInput");
  if (sinp) sinp.addEventListener("input", function (e) { filterSearch = e.target.value.toLowerCase().trim(); renderActiveTickets(); });

  function renderActiveTickets() {
    var db = getDB();
    var tickets = (db.tickets || []).filter(function (t) { return t.type !== "Procurement"; });
    if (filterStatus !== "All") tickets = tickets.filter(function (t) { return t.status === filterStatus; });
    if (filterTeam !== "All") tickets = tickets.filter(function (t) { return t.assignedTo === filterTeam; });
    if (filterSearch) tickets = tickets.filter(function (t) {
      return (t.id || "").toLowerCase().includes(filterSearch) ||
        (t.teamName || "").toLowerCase().includes(filterSearch) ||
        (t.assignedTo || "").toLowerCase().includes(filterSearch) ||
        (t.equipmentName || "").toLowerCase().includes(filterSearch) ||
        (t.subject || "").toLowerCase().includes(filterSearch) ||
        (t.damageDescription || t.reason || "").toLowerCase().includes(filterSearch);
    });

    if (!tickets.length) {
      activeTableBody.innerHTML = "<tr><td colspan='7' style='text-align:center;padding:48px 16px;color:var(--text-secondary);font-weight:500;'>No matching tickets found.</td></tr>";
      return;
    }

    tickets = tickets.slice().sort(function (a, b) { return b.id.localeCompare(a.id); });

    activeTableBody.innerHTML = tickets.map(function (t) {
      var bc = "badge badge-warning";
      if (t.status === "Resolved") bc = "badge badge-success";
      else if (t.status === "In Progress") bc = "badge badge-info";
      else if (t.status === "Open") bc = "badge badge-danger";
      var details = t.damageDescription || t.reason || "No details provided.";
      var slot = t.timeSlot ? "<br><span style='font-size:11px;color:#6B7280;'>Slot: " + t.timeSlot + "</span>" : "";
      return "<tr>" +
        "<td style='font-weight:700;color:var(--text-secondary);'>" + t.id + "</td>" +
        "<td style='font-weight:600;color:var(--text-primary);'>" + esc(t.teamName || t.assignedTo) + " (" + t.assignedTo + ")</td>" +
        "<td style='font-weight:600;color:var(--text-primary);'>" + esc(t.equipmentName || "N/A") + slot + "</td>" +
        "<td style='font-weight:600;color:var(--text-secondary);'>" + esc(t.subject || "Asset Issue") + "</td>" +
        "<td style='max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' title='" + esc(details) + "'>" + esc(details) + "</td>" +
        "<td><span class='" + bc + "'>" + t.status + "</span></td>" +
        "<td style='text-align:center;'><button class='btn btn-secondary' onclick=\"viewTicket('" + t.id + "')\" style='padding:6px 12px;font-size:12px;'>View &amp; Track</button></td>" +
        "</tr>";
    }).join("");
    if (typeof lucide !== "undefined" && lucide.createIcons) lucide.createIcons();
  }

  /* Raise Quick Ticket */
  var activeRaise = null;

  window.openRaiseModal = function (source, refId, teamId, assetId, assetName, timeSlot) {
    activeRaise = { source: source, refId: refId, teamId: teamId, assetId: assetId, assetName: assetName, timeSlot: timeSlot };
    var db = getDB(), tm = (db.teams || []).find(function (t) { return t.id === teamId; });
    document.getElementById("modalTeamId").textContent = teamId;
    document.getElementById("modalTeamName").textContent = tm ? tm.name : teamId;
    document.getElementById("modalAssetId").textContent = assetId || "N/A";
    document.getElementById("modalAssetName").textContent = assetName;
    var sc = document.getElementById("modalTimeSlotContainer");
    if (timeSlot) { sc.style.display = "block"; document.getElementById("modalTimeSlot").textContent = timeSlot; }
    else { sc.style.display = "none"; }
    document.getElementById("modalDamageType").value = "Damaged";
    document.getElementById("modalDamageDetails").value = "";
    document.getElementById("raiseTicketModal").classList.add("active");
  };

  window.closeRaiseModal = function () {
    var m = document.getElementById("raiseTicketModal"); if (m) m.classList.remove("active"); activeRaise = null;
  };

  function nowParts() {
    var d = new Date(), mo = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return {
      dateStr: String(d.getDate()).padStart(2, "0") + " " + mo[d.getMonth()] + " " + d.getFullYear(),
      timeStr: d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
    };
  }

  var rf = document.getElementById("raiseTicketForm");
  if (rf) rf.addEventListener("submit", function (e) {
    e.preventDefault(); if (!activeRaise) return;
    var dt = document.getElementById("modalDamageType").value;
    var det = document.getElementById("modalDamageDetails").value.trim();
    if (!det) { if (typeof showToast === "function") showToast("Please enter damage details.", "error"); return; }
    var db = getDB(); if (!db.tickets) db.tickets = [];
    if (activeRaise.source === "return") {
      var ri = (db.materialReturns || []).findIndex(function (r) { return r.id === activeRaise.refId; });
      if (ri > -1) db.materialReturns[ri].ticketRaised = true;
    } else if (activeRaise.source === "equipment_request") {
      (db.equipmentRequests || []).forEach(function (team) {
        var req = (team.requests || []).find(function (r) { return r.id === activeRaise.refId; }); if (req) req.ticketRaised = true;
      });
    }
    var np = nowParts(), due = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    var newId = "TKT-" + String(db.tickets.length + 1).padStart(3, "0");
    var tObj = (db.teams || []).find(function (t) { return t.id === activeRaise.teamId; });
    db.tickets.push({
      id: newId, type: "Damage", assignedTo: activeRaise.teamId, subject: activeRaise.assetName + " " + dt,
      priority: "High", date: np.dateStr, status: "Open", teamName: tObj ? tObj.name : activeRaise.teamId, equipmentName: activeRaise.assetName,
      raisedBy: "Lab Incharge", time: np.timeStr, damageDescription: det, fineAmount: "500",
      dueDate: due.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      remarks: "Manual ticket raised: " + dt + ".", teamResponse: "", lastUpdated: np.dateStr + ", " + np.timeStr, timeSlot: activeRaise.timeSlot || ""
    });
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift({
      id: "NTF-" + String(db.notifications.length + 1).padStart(3, "0"), icon: "\uD83C\uDFAB",
      iconClass: "notif-icon-ticket", body: "New ticket " + newId + " raised for " + activeRaise.assetName + ".", time: "Just now", unread: true
    });
    if (activeRaise.assetId) {
      var inv = (db.inventory || []).find(function (i) { return i.id === activeRaise.assetId; });
      if (inv && (dt === "Damaged" || dt === "Unusable")) inv.status = "Repairing";
    }
    setDB(db); if (typeof showToast === "function") showToast("Ticket " + newId + " raised successfully!", "success");
    closeRaiseModal(); renderActiveTickets();
  });

  /* Manual Create Ticket */
  window.openManualCreateModal = function () {
    var db = getDB(), ts = document.getElementById("createTicketTeam");
    ts.innerHTML = "<option value=''>-- Choose Team --</option>";
    (db.teams || []).forEach(function (tm) { var o = document.createElement("option"); o.value = tm.id; o.textContent = tm.id + " - " + tm.name; ts.appendChild(o); });
    document.getElementById("createTicketAsset").innerHTML = "<option value=''>-- Choose Asset --</option>";
    document.getElementById("createTicketType").value = "Damaged";
    document.getElementById("createTicketPriority").value = "High";
    document.getElementById("createTicketStatus").value = "Open";
    document.getElementById("createTicketDescription").value = "";
    document.getElementById("createTicketRemarks").value = "";
    var nw = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    document.getElementById("createTicketDueDate").value = nw.getFullYear() + "-" + String(nw.getMonth() + 1).padStart(2, "0") + "-" + String(nw.getDate()).padStart(2, "0");
    document.getElementById("createTicketModal").classList.add("active");
  };

  window.closeManualCreateModal = function () {
    var m = document.getElementById("createTicketModal"); if (m) m.classList.remove("active");
  };

  window.populateCreateTicketAssets = function (teamId) {
    var sel = document.getElementById("createTicketAsset"); sel.innerHTML = "<option value=''>-- Choose Asset --</option>"; if (!teamId) return;
    var db = getDB(); (db.inventory || []).forEach(function (item) {
      var o = document.createElement("option"); o.value = item.id; o.textContent = item.id + " - " + item.name + " (" + item.type + ")"; sel.appendChild(o);
    });
  };

  var crForm = document.getElementById("createTicketForm");
  if (crForm) crForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var teamId = document.getElementById("createTicketTeam").value;
    var assetId = document.getElementById("createTicketAsset").value;
    var tp = document.getElementById("createTicketType").value;
    var dueDate = document.getElementById("createTicketDueDate").value;
    var priority = document.getElementById("createTicketPriority").value;
    var status = document.getElementById("createTicketStatus").value;
    var desc = document.getElementById("createTicketDescription").value.trim();
    var remarks = document.getElementById("createTicketRemarks").value.trim();
    if (!teamId || !assetId || !desc) { if (typeof showToast === "function") showToast("Please fill in all details.", "error"); return; }
    var db = getDB(); if (!db.tickets) db.tickets = [];
    var tObj = (db.teams || []).find(function (t) { return t.id === teamId; });
    var aObj = (db.inventory || []).find(function (i) { return i.id === assetId; });
    var aName = aObj ? aObj.name : assetId;
    var np = nowParts(), newId = "TKT-" + String(db.tickets.length + 1).padStart(3, "0");
    db.tickets.push({
      id: newId, type: "Damage", assignedTo: teamId, subject: aName + " " + tp, priority: priority,
      date: np.dateStr, status: status, teamName: tObj ? tObj.name : teamId, equipmentName: aName, raisedBy: "Lab Incharge",
      time: np.timeStr, damageDescription: desc, fineAmount: "0", dueDate: formatInputDateToDBDate(dueDate),
      remarks: remarks || "Manually raised. Type: " + tp + ".", teamResponse: "", lastUpdated: np.dateStr + ", " + np.timeStr, timeSlot: ""
    });
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift({
      id: "NTF-" + String(db.notifications.length + 1).padStart(3, "0"), icon: "\uD83C\uDFAB",
      iconClass: "notif-icon-ticket", body: "New ticket " + newId + " raised for " + aName + ".", time: "Just now", unread: true
    });
    if (aObj && (tp === "Damaged" || tp === "Unusable") && status !== "Resolved") aObj.status = "Repairing";
    setDB(db); if (typeof showToast === "function") showToast("Ticket " + newId + " raised successfully!", "success");
    closeManualCreateModal(); renderActiveTickets();
  });

  /* View / Update Ticket */
  var activeViewTicketId = null;

  window.viewTicket = function (ticketId) {
    activeViewTicketId = ticketId;
    var db = getDB(), t = (db.tickets || []).find(function (tk) { return tk.id === ticketId; }); if (!t) return;
    var dateVal = t.dueDate ? parseDBDateToInputDate(t.dueDate) : "";
    var details = t.damageDescription || t.reason || "No details provided.";
    var slotRow = t.timeSlot ? "<div style='grid-column:span 2'><strong>Booking Slot:</strong> <span style='font-weight:600;color:#5C59F2'>" + t.timeSlot + "</span></div>" : "";
    var html =
      "<div style='display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;color:#4B5563;margin-bottom:12px;'>" +
      "<div><strong>Ticket ID:</strong> <span style='font-weight:700'>" + t.id + "</span></div>" +
      "<div><strong>Type:</strong> " + t.type + "</div>" +
      "<div><strong>Team:</strong> " + esc(t.teamName || t.assignedTo) + " (" + t.assignedTo + ")</div>" +
      "<div><strong>Asset:</strong> " + esc(t.equipmentName || "N/A") + "</div>" +
      slotRow +
      "<div style='grid-column:span 2'><strong>Subject:</strong> " + esc(t.subject) + "</div>" +
      "<div style='grid-column:span 2;background:#F8FAFC;padding:12px;border-radius:8px;border:1px solid var(--border-color)'>" +
      "<strong>Issue Details:</strong><p style='margin:4px 0 0 0;line-height:1.4'>" + esc(details) + "</p>" +
      "</div>" +
      "</div>" +
      "<div style='margin-top:16px'><label style='font-size:12px;font-weight:700;color:#374151;display:block;margin-bottom:4px'>Ticket Status</label>" +
      "<select id='detailStatus' class='search-input' style='width:100%'>" +
      "<option value='Open'" + (t.status === "Open" ? " selected" : "") + ">Open</option>" +
      "<option value='Pending'" + (t.status === "Pending" ? " selected" : "") + ">Pending</option>" +
      "<option value='In Progress'" + (t.status === "In Progress" ? " selected" : "") + ">In Progress</option>" +
      "<option value='Resolved'" + (t.status === "Resolved" ? " selected" : "") + ">Resolved</option>" +
      "</select></div>";
    if (t.type === "Damage") {
      html += "<div style='margin-top:12px'><label style='font-size:12px;font-weight:700;color:#374151;display:block;margin-bottom:4px'>Due Date</label>" +
        "<input type='date' id='detailDueDate' value='" + dateVal + "' class='search-input' style='width:100%'></div>";
    }
    html += "<div style='margin-top:12px'><label style='font-size:12px;font-weight:700;color:#374151;display:block;margin-bottom:4px'>Remarks</label>" +
      "<textarea id='detailRemarks' class='search-input' style='width:100%;height:75px;resize:vertical'>" + esc(t.remarks || "") + "</textarea></div>";
    document.getElementById("viewTicketContent").innerHTML = html;
    document.getElementById("viewTicketModal").classList.add("active");
  };

  window.closeViewModal = function () {
    var m = document.getElementById("viewTicketModal"); if (m) m.classList.remove("active"); activeViewTicketId = null;
  };

  var vf = document.getElementById("viewTicketForm");
  if (vf) vf.addEventListener("submit", function (e) {
    e.preventDefault(); if (!activeViewTicketId) return;
    var db = getDB(), idx = (db.tickets || []).findIndex(function (tk) { return tk.id === activeViewTicketId; }); if (idx === -1) return;
    var t = db.tickets[idx];
    t.status = document.getElementById("detailStatus").value;
    t.remarks = document.getElementById("detailRemarks").value.trim();
    var di = document.getElementById("detailDueDate"); if (di) t.dueDate = formatInputDateToDBDate(di.value);
    var np = nowParts(); t.lastUpdated = np.dateStr + ", " + np.timeStr;
    setDB(db); if (typeof showToast === "function") showToast("Ticket " + activeViewTicketId + " updated successfully.", "success");
    closeViewModal(); renderActiveTickets();
  });

  /* backdrop close */
  document.querySelectorAll(".modal-overlay").forEach(function (ov) {
    ov.addEventListener("click", function (e) {
      if (e.target === ov) { closeRaiseModal(); closeManualCreateModal(); closeViewModal(); }
    });
  });

  /* Init */
  initFilterTeams();
  renderActiveTickets();

  /* URL params */
  (function () {
    var p = new URLSearchParams(window.location.search);
    if (p.get("action") === "raise") {
      var tid = p.get("teamId");
      if (tid) { openManualCreateModal(); var ts = document.getElementById("createTicketTeam"); if (ts) { ts.value = tid; populateCreateTicketAssets(tid); } }
    }
  })();
});
