/* ============================================================
   PROJECT DETAILS
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    initApp();
});

function initApp() {
    // Sidebar dropdown
      

    // Mobile sidebar
    

    document.getElementById('sidebarOverlay').addEventListener('click', () => {
        document.getElementById('sidebar').style.transform = '';
        document.getElementById('sidebarOverlay').classList.remove('active');
    });
    const closeTeamModal = document.getElementById('closeTeamModal');
    const closeTeamBtn = document.getElementById('closeTeamBtn');

    if (closeTeamModal) {
        closeTeamModal.addEventListener('click', () => {
            document.getElementById('teamModal')?.classList.remove('active');
        });
    }

    if (closeTeamBtn) {
        closeTeamBtn.addEventListener('click', () => {
            document.getElementById('teamModal')?.classList.remove('active');
        });
    }

    renderStages();
    updateDonutChart(40);
    // Bind filters
    const filterIds = ['batchFilter', 'yearFilter', 'facultyFilter', 'statusFilter'];
    filterIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', filterProjects);
    });
    const searchEl = document.getElementById('projectSearch');
    if (searchEl) searchEl.addEventListener('input', filterProjects);

}

function openTeamModal() {
    document.getElementById('teamModal').classList.add('active');
}

function renderStages() {
    const stages = [
        "Problem Statement",
        "Ideation & Context",
        "Design Phase",
        "Product Dev",
        "Testing & Valid",
        "Iteration",
        "Adv Prototype",
        "Evaluation",
        "Documentation",
        "Deployment"
    ];

    const currentStageIndex = 2; // "Design Phase" (0-indexed, so 2) is active, previous are completed

    const container = document.getElementById('stagesContainer');
    
    // Draw the nodes
    let html = '';
    stages.forEach((st, idx) => {
        let stateClass = '';
        if (idx < currentStageIndex) stateClass = 'completed';
        else if (idx === currentStageIndex) stateClass = 'active';

        const iconOrNum = idx < currentStageIndex ? `<i data-lucide="check"></i>` : (idx + 1);

        html += `
            <div class="step-node ${stateClass}">
                <div class="step-circle">${iconOrNum}</div>
                <div class="step-label">${st}</div>
            </div>
        `;
    });
    // Calculate fill percentage for line
    const fillPercent = (currentStageIndex / (stages.length - 1)) * 100;
    
    // Add lines
    html += `
        <div class="stepper-line"></div>
        <div class="stepper-line-fill" style="width: calc(${fillPercent}% - 40px);"></div>
    `;
    const projectModal =
    document.getElementById('projectModal');
        if(projectModal){
            projectModal.addEventListener('click', (e) => {
                if(e.target === projectModal){
                    closeProject();
                }
            });
        }
    container.innerHTML = html;
    lucide.createIcons();
}

function updateDonutChart(percent) {
    const radius = 64; // from SVG
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percent / 100) * circumference;

    const fillCircle = document.getElementById('donutFill');
    fillCircle.style.strokeDasharray = `${circumference} ${circumference}`;
    fillCircle.style.strokeDashoffset = offset;
}

// grid function
function showProject() {

    document
        .getElementById('projectModal')
        .classList.add('active');

    lucide.createIcons();
}

function closeProject() {

    document
        .getElementById('projectModal')
        .classList.remove('active');
}
function filterProjects() {
    const selectedBatch = document.getElementById('batchFilter').value;
    const selectedYear = document.getElementById('yearFilter') ? document.getElementById('yearFilter').value : "";
    const searchInput = document.getElementById('projectSearch') ? document.getElementById('projectSearch').value.toLowerCase() : "";

    document.querySelectorAll('.project-card')
        .forEach(card => {
            const batch = card.dataset.batch;
            const year = card.dataset.year;
            
            const h3 = card.querySelector('h3');
            const p = card.querySelector('p');
            const projectId = h3 ? h3.textContent.toLowerCase() : "";
            const projectName = p ? p.textContent.toLowerCase() : "";

            let matches = true;

            // Existing logic
            if (selectedBatch && batch !== selectedBatch) {
                matches = false;
            }
            
            // New logic
            if (selectedYear && year !== selectedYear) {
                matches = false;
            }
            if (searchInput && !(projectId.includes(searchInput) || projectName.includes(searchInput))) {
                matches = false;
            }

            if (matches) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
}