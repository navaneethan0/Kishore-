// js/db.js
// ═══════════════════════════════════════════════════════════════
// LAB DB — Single Source of Truth for Equipment Tracking
// All data lives here. The page JS consumes window.labDB.*
// ═══════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // ─── Date Helpers ───────────────────────────────────────────────────────────
  // Returns a Date object relative to today (hour/minute precision)
  function relDate(dayOffset, hour, minute = 0) {
    const d = new Date();
    d.setDate(d.getDate() + dayOffset);
    d.setHours(hour, minute, 0, 0);
    return d;
  }

  // Format a Date as "DD Mon YYYY, HH:MM AM/PM"
  function fmtDatetime(d) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const h = d.getHours();
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    const mm = String(d.getMinutes()).padStart(2, '0');
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}, ${h12}:${mm} ${ampm}`;
  }

  // Format a Date as "DD Mon YYYY"
  function fmtDate(d) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
  }

  // Format as "HH:MM AM – HH:MM AM"
  function fmtSlot(start, end) {
    function f(d) {
      const h = d.getHours(), m = d.getMinutes();
      const ampm = h >= 12 ? 'PM' : 'AM';
      return `${(h % 12 || 12)}:${String(m).padStart(2, '0')} ${ampm}`;
    }
    return `${f(start)} – ${f(end)}`;
  }

  // ─── 1. Equipment Categories ─────────────────────────────────────────────────
  const equipmentCategories = [
    {
      id: 'printers',
      name: '3D Printers',
      image: 'images/3dprinter.jpeg',
      colorClass: 'color-blue',
      prefix: '3DP',
    },
    {
      id: 'laser',
      name: 'Laser Cutters',
      image: 'images/lasercutter.jpg',
      colorClass: 'color-orange',
      prefix: 'LCR',
    },
    {
      id: 'cnc',
      name: 'CNC Routers',
      image: 'images/cncrouter.jpeg',
      colorClass: 'color-green',
      prefix: 'CNC',
    },
    {
      id: 'pcb',
      name: 'CNC Milling',
      image: 'images/cncmilling.avif',
      colorClass: 'color-purple',
      prefix: 'MLG',
    },
    {
      id: 'testing',
      name: 'CNC Lathe',
      image: 'images/cnclathe.png',
      colorClass: 'color-cyan',
      prefix: 'LTH',
    },
    {
      id: 'solder',
      name: 'Table Saw',
      image: 'images/tablesaw.jpg',
      colorClass: 'color-red',
      prefix: 'SAW',
    },
    {
      id: 'robotics',
      name: 'Vacuum Foaming',
      image: 'images/vaccumfoaming.jpg',
      colorClass: 'color-indigo',
      prefix: 'VFM',
    },
  ];

  // ─── 2. Machines (3–4 units per category = 25 total) ────────────────────────
  const machines = [
    // 3D Printers (4 units)
    { id: '3DP-01', categoryId: 'printers', type: 'FDM Printer',       location: 'Bay A', status: 'available',    health: '98%', firmware: 'v2.4.1', usageToday: '4 hrs', lastMaint: relDate(-7, 9) },
    { id: '3DP-02', categoryId: 'printers', type: 'FDM Printer',       location: 'Bay A', status: 'in-use',       health: '91%', firmware: 'v2.4.0', usageToday: '2 hrs', lastMaint: relDate(-10, 10) },
    { id: '3DP-03', categoryId: 'printers', type: 'SLA Printer',       location: 'Bay B', status: 'maintenance',  health: '74%', firmware: 'v2.3.8', usageToday: '0 hrs', lastMaint: relDate(-2, 14) },
    { id: '3DP-04', categoryId: 'printers', type: 'FDM Printer',       location: 'Bay B', status: 'available',    health: '87%', firmware: 'v2.4.1', usageToday: '1 hrs', lastMaint: relDate(-14, 9) },

    // Laser Cutters (4 units)
    { id: 'LCR-01', categoryId: 'laser',    type: 'CO2 Cutter (60W)',  location: 'Bay C', status: 'available',    health: '95%', firmware: 'v1.8.3', usageToday: '3 hrs', lastMaint: relDate(-5, 11) },
    { id: 'LCR-02', categoryId: 'laser',    type: 'CO2 Cutter (80W)',  location: 'Bay C', status: 'in-use',       health: '88%', firmware: 'v1.8.2', usageToday: '5 hrs', lastMaint: relDate(-8, 9) },
    { id: 'LCR-03', categoryId: 'laser',    type: 'Diode Cutter',      location: 'Bay D', status: 'available',    health: '100%',firmware: 'v1.9.0', usageToday: '0 hrs', lastMaint: relDate(-3, 15) },
    { id: 'LCR-04', categoryId: 'laser',    type: 'Fiber Cutter',      location: 'Bay D', status: 'scheduled',    health: '82%', firmware: 'v1.7.5', usageToday: '0 hrs', lastMaint: relDate(-20, 9) },

    // CNC Routers (4 units)
    { id: 'CNC-01', categoryId: 'cnc',      type: 'Milling Machine',   location: 'Bay E', status: 'in-use',       health: '93%', firmware: 'v3.1.0', usageToday: '6 hrs', lastMaint: relDate(-6, 8) },
    { id: 'CNC-02', categoryId: 'cnc',      type: 'Milling Machine',   location: 'Bay E', status: 'available',    health: '97%', firmware: 'v3.1.0', usageToday: '2 hrs', lastMaint: relDate(-9, 10) },
    { id: 'CNC-03', categoryId: 'cnc',      type: 'Lathe',             location: 'Bay F', status: 'available',    health: '90%', firmware: 'v3.0.5', usageToday: '0 hrs', lastMaint: relDate(-11, 9) },
    { id: 'CNC-04', categoryId: 'cnc',      type: 'Router Table',      location: 'Bay F', status: 'maintenance',  health: '65%', firmware: 'v2.9.1', usageToday: '0 hrs', lastMaint: relDate(-1, 16) },

    // CNC Milling (3 units)
    { id: 'MLG-01', categoryId: 'pcb',      type: 'CNC Mill',          location: 'Bay G', status: 'available',    health: '96%', firmware: 'v4.2.0', usageToday: '2 hrs', lastMaint: relDate(-4, 10) },
    { id: 'MLG-02', categoryId: 'pcb',      type: 'CNC Mill',          location: 'Bay G', status: 'in-use',       health: '89%', firmware: 'v4.2.0', usageToday: '4 hrs', lastMaint: relDate(-12, 9) },
    { id: 'MLG-03', categoryId: 'pcb',      type: 'CNC Mill',          location: 'Bay H', status: 'available',    health: '99%', firmware: 'v4.3.1', usageToday: '1 hrs', lastMaint: relDate(-7, 14) },

    // CNC Lathe (4 units)
    { id: 'LTH-01', categoryId: 'testing',  type: 'CNC Lathe',         location: 'Bay I', status: 'available',    health: '100%',firmware: 'v5.1.2', usageToday: '3 hrs', lastMaint: relDate(-2, 9) },
    { id: 'LTH-02', categoryId: 'testing',  type: 'Signal Generator',  location: 'Bay I', status: 'in-use',       health: '94%', firmware: 'v5.0.8', usageToday: '5 hrs', lastMaint: relDate(-6, 11) },
    { id: 'LTH-03', categoryId: 'testing',  type: 'Logic Analyzer',    location: 'Bay J', status: 'available',    health: '98%', firmware: 'v5.1.0', usageToday: '2 hrs', lastMaint: relDate(-3, 9) },
    { id: 'LTH-04', categoryId: 'testing',  type: 'Spectrum Analyzer', location: 'Bay J', status: 'available',    health: '91%', firmware: 'v4.9.3', usageToday: '0 hrs', lastMaint: relDate(-15, 9) },

    // Table Saw (3 units)
    { id: 'SAW-01', categoryId: 'solder',   type: 'Table Saw',         location: 'Bay K', status: 'in-use',       health: '95%', firmware: 'v1.2.0', usageToday: '3 hrs', lastMaint: relDate(-8, 9) },
    { id: 'SAW-02', categoryId: 'solder',   type: 'Soldering Station', location: 'Bay K', status: 'available',    health: '88%', firmware: 'v1.1.5', usageToday: '1 hrs', lastMaint: relDate(-13, 10) },
    { id: 'SAW-03', categoryId: 'solder',   type: 'Hot Air Station',   location: 'Bay L', status: 'available',    health: '92%', firmware: 'v1.2.0', usageToday: '0 hrs', lastMaint: relDate(-5, 14) },

    // Vacuum Foaming (3 units)
    { id: 'VFM-01', categoryId: 'robotics', type: 'Vacuum Foamer',     location: 'Bay M', status: 'available',    health: '97%', firmware: 'v6.0.1', usageToday: '2 hrs', lastMaint: relDate(-4, 9) },
    { id: 'VFM-02', categoryId: 'robotics', type: 'Mobile Platform',   location: 'Bay M', status: 'in-use',       health: '84%', firmware: 'v6.0.0', usageToday: '4 hrs', lastMaint: relDate(-11, 10) },
    { id: 'VFM-03', categoryId: 'robotics', type: 'Drone Testbed',     location: 'Bay N', status: 'scheduled',    health: '79%', firmware: 'v5.8.2', usageToday: '0 hrs', lastMaint: relDate(-18, 9) },
  ];

  // ─── 3. Teams ────────────────────────────────────────────────────────────────
  const teams = [
    { id: 'T01', name: 'Solar Car Team',     faculty: 'Dr. Amit Verma',      dept: 'Mechanical Engineering',   contact: 'Rahul Sharma',  studentId: 'S12345' },
    { id: 'T02', name: 'Robotics Club',      faculty: 'Prof. Neha Iyer',     dept: 'Electronics Engineering',  contact: 'Ananya Verma',  studentId: 'S67890' },
    { id: 'T03', name: 'Aero Team',          faculty: 'Dr. Rahul Mehta',     dept: 'Aerospace Engineering',    contact: 'Vikram Singh',  studentId: 'S11223' },
    { id: 'T04', name: 'Formula Racing',     faculty: 'Prof. Karan Gupta',   dept: 'Industrial Design',        contact: 'Priya Nair',    studentId: 'S33445' },
    { id: 'T05', name: 'Electronics Club',   faculty: 'Dr. Priya Nair',      dept: 'Electrical Engineering',   contact: 'Amit Kumar',    studentId: 'S55667' },
    { id: 'T06', name: 'Mech Design Club',   faculty: 'Prof. S. Raghavan',   dept: 'Mechanical Engineering',   contact: 'Suresh Rao',    studentId: 'S77889' },
    { id: 'T07', name: 'Drone Team',         faculty: 'Dr. Kavya Pillai',    dept: 'Avionics Engineering',     contact: 'Deepak Menon',  studentId: 'S99001' },
    { id: 'T08', name: 'Product Design Team',faculty: 'Prof. Arjun Nanda',   dept: 'Design Engineering',       contact: 'Sneha Patel',   studentId: 'S22334' },
  ];

  // ─── 4. Bookings ─────────────────────────────────────────────────────────────
  // dayOffset 0 = today. Negative = past. Positive = future.
  // type: 'project' | 'prototype' | 'club' | 'testing' | 'maintenance'
  // status: 'confirmed' | 'pending' | 'rejected'

  const bookings = [
    // ── 2 WEEKS AGO (day -14 to -8) ──────────────────────────────────────────
    { id: 'BK-H01', teamId: 'T01', machineId: '3DP-01', detail: 'Shell Prototype v1',    type: 'project',     startTime: relDate(-14, 9),  endTime: relDate(-14, 11), status: 'confirmed' },
    { id: 'BK-H02', teamId: 'T02', machineId: 'LCR-01', detail: 'Chassis Panel Cut',     type: 'prototype',   startTime: relDate(-14, 13), endTime: relDate(-14, 15), status: 'confirmed' },
    { id: 'BK-H03', teamId: 'T03', machineId: 'CNC-01', detail: 'Wing Rib Milling',      type: 'project',     startTime: relDate(-13, 8),  endTime: relDate(-13, 10), status: 'confirmed' },
    { id: 'BK-H04', teamId: 'T05', machineId: 'MLG-01', detail: 'Motor Controller Board',type: 'club',        startTime: relDate(-13, 11), endTime: relDate(-13, 13), status: 'confirmed' },
    { id: 'BK-H05', teamId: 'T06', machineId: '3DP-02', detail: 'Gear Model Print',      type: 'project',     startTime: relDate(-12, 9),  endTime: relDate(-12, 12), status: 'confirmed' },
    { id: 'BK-H06', teamId: 'T07', machineId: 'VFM-02', detail: 'Drone Navigation Test', type: 'testing',     startTime: relDate(-12, 14), endTime: relDate(-12, 16), status: 'confirmed' },
    { id: 'BK-M01', teamId: null,  machineId: '3DP-03', detail: 'Extruder Head Service', type: 'maintenance', startTime: relDate(-11, 8),  endTime: relDate(-11, 12), status: 'confirmed' },
    { id: 'BK-H07', teamId: 'T04', machineId: 'LCR-02', detail: 'Acrylic Panel Cuts',    type: 'project',     startTime: relDate(-11, 13), endTime: relDate(-11, 15), status: 'confirmed' },
    { id: 'BK-H08', teamId: 'T08', machineId: 'LTH-01', detail: 'Power System Audit',    type: 'testing',     startTime: relDate(-10, 9),  endTime: relDate(-10, 11), status: 'confirmed' },
    { id: 'BK-H09', teamId: 'T01', machineId: 'CNC-02', detail: 'Suspension Bracket',    type: 'prototype',   startTime: relDate(-10, 13), endTime: relDate(-10, 16), status: 'confirmed' },
    { id: 'BK-H10', teamId: 'T03', machineId: '3DP-04', detail: 'Fuselage Frames v2',    type: 'project',     startTime: relDate(-9, 9),   endTime: relDate(-9, 11),  status: 'confirmed' },
    { id: 'BK-H11', teamId: 'T05', machineId: 'SAW-01', detail: 'ESC Rework Session',    type: 'club',        startTime: relDate(-9, 14),  endTime: relDate(-9, 16),  status: 'confirmed' },
    { id: 'BK-H12', teamId: 'T02', machineId: 'MLG-02', detail: 'Sensor Array Board',    type: 'prototype',   startTime: relDate(-8, 10),  endTime: relDate(-8, 12),  status: 'confirmed' },
    { id: 'BK-H13', teamId: 'T06', machineId: 'CNC-01', detail: 'Differential Gearbox',  type: 'project',     startTime: relDate(-8, 13),  endTime: relDate(-8, 16),  status: 'confirmed' },
    { id: 'BK-M02', teamId: null,  machineId: 'CNC-04', detail: 'Router Bit Replacement', type: 'maintenance', startTime: relDate(-8, 8),   endTime: relDate(-8, 12),  status: 'confirmed' },

    // ── LAST WEEK (day -7 to -1) ──────────────────────────────────────────────
    { id: 'BK-L01', teamId: 'T01', machineId: '3DP-01', detail: 'Shell Print Batch',      type: 'project',     startTime: relDate(-7, 9),   endTime: relDate(-7, 12),  status: 'confirmed' },
    { id: 'BK-L02', teamId: 'T07', machineId: 'VFM-01', detail: 'Arm Calibration',        type: 'prototype',   startTime: relDate(-7, 13),  endTime: relDate(-7, 15),  status: 'confirmed' },
    { id: 'BK-L03', teamId: 'T04', machineId: 'LCR-03', detail: 'Bodywork Panels',        type: 'project',     startTime: relDate(-6, 9),   endTime: relDate(-6, 11),  status: 'confirmed' },
    { id: 'BK-L04', teamId: 'T05', machineId: 'LTH-02', detail: 'Signal Integrity Test',  type: 'testing',     startTime: relDate(-6, 13),  endTime: relDate(-6, 15),  status: 'confirmed' },
    { id: 'BK-L05', teamId: 'T02', machineId: '3DP-02', detail: 'Servo Bracket Prints',   type: 'prototype',   startTime: relDate(-5, 9),   endTime: relDate(-5, 11),  status: 'confirmed' },
    { id: 'BK-L06', teamId: 'T08', machineId: 'MLG-01', detail: 'Product PCB Prototype',  type: 'project',     startTime: relDate(-5, 13),  endTime: relDate(-5, 15),  status: 'confirmed' },
    { id: 'BK-L07', teamId: 'T03', machineId: 'CNC-01', detail: 'Spar Machining Run 2',   type: 'project',     startTime: relDate(-4, 8),   endTime: relDate(-4, 11),  status: 'confirmed' },
    { id: 'BK-L08', teamId: 'T06', machineId: 'SAW-02', detail: 'Connector Rework',       type: 'club',        startTime: relDate(-4, 14),  endTime: relDate(-4, 16),  status: 'confirmed' },
    { id: 'BK-M03', teamId: null,  machineId: 'LCR-04', detail: 'Lens Alignment Check',   type: 'maintenance', startTime: relDate(-3, 8),   endTime: relDate(-3, 14),  status: 'confirmed' },
    { id: 'BK-L09', teamId: 'T01', machineId: 'VFM-02', detail: 'Simulation Run A',       type: 'testing',     startTime: relDate(-3, 14),  endTime: relDate(-3, 16),  status: 'confirmed' },
    { id: 'BK-L10', teamId: 'T07', machineId: '3DP-04', detail: 'Drone Frame Iteration',  type: 'prototype',   startTime: relDate(-2, 9),   endTime: relDate(-2, 11),  status: 'confirmed' },
    { id: 'BK-L11', teamId: 'T05', machineId: 'LTH-03', detail: 'FPGA Logic Verify',      type: 'testing',     startTime: relDate(-2, 13),  endTime: relDate(-2, 15),  status: 'confirmed' },
    { id: 'BK-L12', teamId: 'T08', machineId: 'LCR-01', detail: 'Mockup Cut Final',       type: 'project',     startTime: relDate(-1, 9),   endTime: relDate(-1, 11),  status: 'confirmed' },
    { id: 'BK-L13', teamId: 'T06', machineId: 'CNC-03', detail: 'Lathe – Axle Shaping',   type: 'prototype',   startTime: relDate(-1, 13),  endTime: relDate(-1, 15),  status: 'confirmed' },
    { id: 'BK-M04', teamId: null,  machineId: '3DP-03', detail: 'Bed Leveling Service',   type: 'maintenance', startTime: relDate(-1, 15),  endTime: relDate(-1, 18),  status: 'confirmed' },

    // ── THIS WEEK — CURRENT / UPCOMING (day 0 to +6) ─────────────────────────
    // Today
    { id: 'BK-C01', teamId: 'T01', machineId: '3DP-01', detail: 'Shell Prototype v3',     type: 'project',     startTime: relDate(0, 9),    endTime: relDate(0, 11),   status: 'confirmed' },
    { id: 'BK-C02', teamId: 'T02', machineId: 'LCR-02', detail: 'Chassis Cut Round 2',    type: 'prototype',   startTime: relDate(0, 9),    endTime: relDate(0, 11),   status: 'confirmed' },
    { id: 'BK-C03', teamId: 'T05', machineId: 'LTH-02', detail: 'RF Module Test',         type: 'testing',     startTime: relDate(0, 11),   endTime: relDate(0, 13),   status: 'confirmed' },
    { id: 'BK-C04', teamId: 'T07', machineId: 'VFM-02', detail: 'Obstacle Course Trial',  type: 'testing',     startTime: relDate(0, 13),   endTime: relDate(0, 15),   status: 'confirmed' },
    { id: 'BK-C05', teamId: 'T04', machineId: 'CNC-01', detail: 'Uprights Machining',     type: 'project',     startTime: relDate(0, 13),   endTime: relDate(0, 16),   status: 'confirmed' },
    { id: 'BK-P01', teamId: 'T03', machineId: '3DP-02', detail: 'Wing Tips Print',        type: 'project',     startTime: relDate(0, 16),   endTime: relDate(0, 17, 30),status: 'pending' },

    // Tomorrow (+1)
    { id: 'BK-C06', teamId: 'T06', machineId: '3DP-01', detail: 'Gear Housing Print',     type: 'project',     startTime: relDate(1, 9),    endTime: relDate(1, 11),   status: 'confirmed' },
    { id: 'BK-C07', teamId: 'T08', machineId: 'LCR-01', detail: 'Faceplate Engrave',      type: 'project',     startTime: relDate(1, 11),   endTime: relDate(1, 13),   status: 'confirmed' },
    { id: 'BK-P02', teamId: 'T05', machineId: 'MLG-02', detail: 'Battery Management PCB', type: 'prototype',   startTime: relDate(1, 13),   endTime: relDate(1, 15),   status: 'pending' },
    { id: 'BK-C08', teamId: 'T02', machineId: 'CNC-02', detail: 'Wheel Hub Turning',      type: 'prototype',   startTime: relDate(1, 14),   endTime: relDate(1, 16),   status: 'confirmed' },

    // +2 days
    { id: 'BK-C09', teamId: 'T01', machineId: '3DP-04', detail: 'Headrest Mount Print',   type: 'project',     startTime: relDate(2, 9),    endTime: relDate(2, 11),   status: 'confirmed' },
    { id: 'BK-M05', teamId: null,  machineId: 'CNC-04', detail: 'Scheduled Spindle Check',type: 'maintenance', startTime: relDate(2, 8),    endTime: relDate(2, 12),   status: 'confirmed' },
    { id: 'BK-P03', teamId: 'T07', machineId: 'VFM-03', detail: 'Autonomous Flight Test', type: 'testing',     startTime: relDate(2, 14),   endTime: relDate(2, 16),   status: 'pending' },

    // +3 days
    { id: 'BK-C10', teamId: 'T03', machineId: 'LCR-03', detail: 'Rib Diaphragm Cuts',     type: 'project',     startTime: relDate(3, 10),   endTime: relDate(3, 12),   status: 'confirmed' },
    { id: 'BK-C11', teamId: 'T05', machineId: 'SAW-01', detail: 'Reflow Soldering',       type: 'club',        startTime: relDate(3, 13),   endTime: relDate(3, 15),   status: 'confirmed' },
    { id: 'BK-P04', teamId: 'T04', machineId: 'CNC-01', detail: 'Steering Rack Machining',type: 'prototype',   startTime: relDate(3, 8),    endTime: relDate(3, 10),   status: 'pending' },

    // +4 days
    { id: 'BK-C12', teamId: 'T06', machineId: '3DP-02', detail: 'Bracket Array Print',    type: 'project',     startTime: relDate(4, 9),    endTime: relDate(4, 12),   status: 'confirmed' },
    { id: 'BK-M06', teamId: null,  machineId: 'LCR-04', detail: 'Fiber Lens Realignment', type: 'maintenance', startTime: relDate(4, 8),    endTime: relDate(4, 16),   status: 'confirmed' },
    { id: 'BK-C13', teamId: 'T08', machineId: 'LTH-04', detail: 'EMC Pre-compliance Test', type: 'testing',    startTime: relDate(4, 13),   endTime: relDate(4, 15),   status: 'confirmed' },

    // +5 days
    { id: 'BK-C14', teamId: 'T07', machineId: 'VFM-01', detail: 'Pick & Place Demo',      type: 'prototype',   startTime: relDate(5, 10),   endTime: relDate(5, 12),   status: 'confirmed' },
    { id: 'BK-P05', teamId: 'T01', machineId: '3DP-03', detail: 'Dashboard Pod Print',    type: 'project',     startTime: relDate(5, 13),   endTime: relDate(5, 15),   status: 'pending' },

    // +6 days
    { id: 'BK-M07', teamId: null,  machineId: 'VFM-03', detail: 'Full Drone Inspection',  type: 'maintenance', startTime: relDate(6, 9),    endTime: relDate(6, 14),   status: 'confirmed' },
    { id: 'BK-C15', teamId: 'T02', machineId: 'MLG-01', detail: 'Controller Board Rev2',  type: 'prototype',   startTime: relDate(6, 14),   endTime: relDate(6, 16),   status: 'confirmed' },

    // ── REJECTED BOOKINGS (past) ──────────────────────────────────────────────
    // These appear in history tab with 'Rejected' badge but are excluded from
    // the calendar (calendar filters b.status !== 'rejected').
    { id: 'BK-R01', teamId: 'T03', machineId: 'LCR-02',  detail: 'Carbon Fibre Panel Cuts',    type: 'project',   startTime: relDate(-13, 10), endTime: relDate(-13, 13), status: 'rejected', rejectionReason: 'Booking window overlaps with an already-confirmed maintenance session. Please reschedule for a later slot.',         rejectedAt: relDate(-14, 9)  },
    { id: 'BK-R02', teamId: 'T04', machineId: '3DP-03',  detail: 'Formula Body Shell Print',   type: 'project',   startTime: relDate(-12, 9),  endTime: relDate(-12, 11), status: 'rejected', rejectionReason: 'Machine is reserved for SLA resin maintenance during this period. Unit will be available from next Monday.',      rejectedAt: relDate(-13, 11) },
    { id: 'BK-R03', teamId: 'T06', machineId: 'CNC-04',  detail: 'Gearbox Housing Mill',       type: 'prototype', startTime: relDate(-11, 14), endTime: relDate(-11, 16), status: 'rejected', rejectionReason: 'Incomplete safety training certificate on file. Student must complete CNC Router safety module before booking.',   rejectedAt: relDate(-12, 10) },
    { id: 'BK-R04', teamId: 'T02', machineId: 'VFM-03',  detail: 'Drone Frame Vacuum Form',    type: 'prototype', startTime: relDate(-10, 8),  endTime: relDate(-10, 10), status: 'rejected', rejectionReason: 'Requested duration exceeds the 2-hour per-session limit for this equipment. Split into two separate bookings.',   rejectedAt: relDate(-11, 9)  },
    { id: 'BK-R05', teamId: 'T07', machineId: 'SAW-01',  detail: 'Drone Arm Jig Cut',          type: 'club',      startTime: relDate(-9, 13),  endTime: relDate(-9, 15),  status: 'rejected', rejectionReason: 'Table Saw booking requires a faculty supervisor to be physically present. No supervisor confirmed for this slot.',  rejectedAt: relDate(-10, 8)  },
    { id: 'BK-R06', teamId: 'T01', machineId: 'MLG-03',  detail: 'Suspension Upright Mill',    type: 'project',   startTime: relDate(-8, 9),   endTime: relDate(-8, 12),  status: 'rejected', rejectionReason: 'Submitted project proposal document was missing the material specification sheet. Please re-submit with full docs.', rejectedAt: relDate(-9, 14)  },
    { id: 'BK-R07', teamId: 'T05', machineId: 'LTH-04',  detail: 'Spectrum Analysis Run',      type: 'testing',   startTime: relDate(-7, 11),  endTime: relDate(-7, 13),  status: 'rejected', rejectionReason: 'Equipment is currently under calibration by the lab technician. Estimated return to service: end of this week.',      rejectedAt: relDate(-8, 10)  },
    { id: 'BK-R08', teamId: 'T08', machineId: 'CNC-01',  detail: 'Product Enclosure Milling',  type: 'project',   startTime: relDate(-6, 14),  endTime: relDate(-6, 16),  status: 'rejected', rejectionReason: 'Booking conflicts with a higher-priority Aero Team slot already confirmed. Please choose an alternate time window.', rejectedAt: relDate(-7, 9)   },
    { id: 'BK-R09', teamId: 'T03', machineId: 'SAW-02',  detail: 'Fuselage Connector Rework',  type: 'club',      startTime: relDate(-5, 9),   endTime: relDate(-5, 11),  status: 'rejected', rejectionReason: 'Booking submitted less than 24 hours before the requested start time. Lab policy requires at least 24 h advance notice.', rejectedAt: relDate(-5, 8) },
    { id: 'BK-R10', teamId: 'T04', machineId: 'LCR-04',  detail: 'Polycarbonate Body Panels',  type: 'project',   startTime: relDate(-3, 10),  endTime: relDate(-3, 12),  status: 'rejected', rejectionReason: 'Fiber cutter is not rated for polycarbonate above 6 mm. Material choice is outside the approved material specification.', rejectedAt: relDate(-4, 11) },

    // ── MULTI-DAY & OVERLAP DEMONSTRATION ────────────────────────────────────
    // 3-day maintenance booking: spans today → today+2 (full day 08:00–18:00)
    { id: 'BK-MD01', teamId: null,  machineId: 'CNC-03', detail: '3-Day Spindle Overhaul',   type: 'maintenance', startTime: relDate(0, 8),    endTime: relDate(2, 18),   status: 'confirmed' },
    // Concurrent project booking on same day window (today 09:00–14:00, 3DP-04)
    // — demonstrates 2-way side-by-side split alongside BK-C01 on today's column
    { id: 'BK-MD02', teamId: 'T04', machineId: '3DP-04', detail: 'Formula Aero Shell Print', type: 'project',     startTime: relDate(0, 9),    endTime: relDate(0, 14),   status: 'confirmed' },
    // Third concurrent booking today (10:00–15:30) to show a 3-way split
    { id: 'BK-MD03', teamId: 'T07', machineId: 'VFM-01', detail: 'Arm Endurance Trial',      type: 'prototype',   startTime: relDate(0, 10),   endTime: relDate(0, 15, 30), status: 'confirmed' },
  ];

  // ─── 5. Derived / Computed Helpers ───────────────────────────────────────────

  /** Get all machines with their category data merged in */
  function getAllMachinesFlat() {
    return machines.map(m => {
      const cat = equipmentCategories.find(c => c.id === m.categoryId) || {};
      return {
        ...m,
        catId:       cat.id,
        catName:     cat.name,
        catIcon:     cat.icon,
        catColorClass: cat.colorClass,
        catPrefix:   cat.prefix,
      };
    });
  }

  /** Get team object by id */
  function getTeam(teamId) {
    return teams.find(t => t.id === teamId) || null;
  }

  /** Get machine object by id */
  function getMachine(machineId) {
    return machines.find(m => m.id === machineId) || null;
  }

  /** Get category that a machine belongs to */
  function getCategoryForMachine(machineId) {
    const machine = getMachine(machineId);
    if (!machine) return null;
    return equipmentCategories.find(c => c.id === machine.categoryId) || null;
  }

  /**
   * Get machine spec object for the Details modal.
   * Computes currentUser and nextBooking dynamically from bookings.
   */
  function getMachineSpec(machineId) {
    const machine = getMachine(machineId);
    if (!machine) return null;
    const now = new Date();

    // Current active booking for this machine
    const activeBooking = bookings.find(b =>
      b.machineId === machineId &&
      b.status === 'confirmed' &&
      b.startTime <= now && b.endTime >= now
    );

    // Next upcoming confirmed booking
    const nextBooking = bookings
      .filter(b => b.machineId === machineId && b.status === 'confirmed' && b.startTime > now)
      .sort((a, b) => a.startTime - b.startTime)[0];

    const currentTeam = activeBooking ? getTeam(activeBooking.teamId) : null;
    const currentUser = currentTeam ? currentTeam.name :
                        (machine.status === 'maintenance' ? 'Maintenance' : '—');

    const nextLabel = nextBooking
      ? `${fmtSlot(nextBooking.startTime, nextBooking.endTime)}, ${fmtDate(nextBooking.startTime)}`
      : 'None';

    return {
      machineId,
      status:      machine.status,
      location:    machine.location,
      type:        machine.type,
      currentUser,
      nextBooking: nextLabel,
      lastMaint:   fmtDate(machine.lastMaint),
      health:      machine.health,
      firmware:    machine.firmware,
      usageToday:  machine.usageToday,
    };
  }

  /**
   * Get all pending bookings as approval-detail objects (for Approval List modal).
   */
  function getPendingApprovals() {
    return bookings
      .filter(b => b.status === 'pending')
      .map(b => {
        const team    = getTeam(b.teamId) || {};
        const machine = getMachine(b.machineId) || {};
        const cat     = getCategoryForMachine(b.machineId) || {};
        const durationMs = b.endTime - b.startTime;
        const durationHrs = Math.round(durationMs / 3600000);
        return {
          bookingId:    b.id,
          team:         team.name || '—',
          faculty:      team.faculty || '—',
          equipment:    `${cat.name || ''} — ${b.machineId}`,
          machineId:    b.machineId,
          catImage:     cat.image,
          catColorClass: cat.colorClass,
          date:         fmtDate(b.startTime),
          timeSlot:     fmtSlot(b.startTime, b.endTime),
          duration:     `${durationHrs} Hour${durationHrs !== 1 ? 's' : ''}`,
          requester:    team.contact || '—',
          studentId:    team.studentId || '—',
          dept:         team.dept || '—',
          purpose:      b.detail,
          requestedOn:  fmtDatetime(new Date(b.startTime.getTime() - 86400000 * 2)), // 2 days before
          attachment:   `${b.id}_Proposal.pdf`,
        };
      });
  }

  /**
   * Compute overview stats from live machine + booking data.
   */
  function computeStats() {
    const now = new Date();
    const totalMachines = machines.length;

    // In-use: machine status is 'in-use' OR it has an active confirmed non-maintenance booking
    const inUseMachines = new Set(
      bookings
        .filter(b => b.status === 'confirmed' && b.type !== 'maintenance' && b.startTime <= now && b.endTime >= now)
        .map(b => b.machineId)
    );
    // Also include machines whose static status is in-use
    machines.filter(m => m.status === 'in-use').forEach(m => inUseMachines.add(m.id));

    const inMaintMachines = new Set(
      bookings
        .filter(b => b.type === 'maintenance' && b.startTime <= now && b.endTime >= now)
        .map(b => b.machineId)
    );
    machines.filter(m => m.status === 'maintenance').forEach(m => inMaintMachines.add(m.id));

    // Machines in maintenance shouldn't count as in-use
    inMaintMachines.forEach(id => inUseMachines.delete(id));

    const scheduledMaintenance = bookings.filter(b =>
      b.type === 'maintenance' && b.startTime > now
    ).length;

    const pendingApproval = bookings.filter(b => b.status === 'pending').length;

    const inUse = inUseMachines.size;
    const inMaintenance = inMaintMachines.size;
    const currentlyFree = totalMachines - inUse - inMaintenance;

    return { totalMachines, inUse, currentlyFree, inMaintenance, scheduledMaintenance, pendingApproval };
  }

  /**
   * Add a new maintenance booking and update the affected machine's status.
   * Returns the new booking object.
   */
  function addMaintenance({ machineId, startTime, endTime, purpose }) {
    const id = `BK-MAINT-${Date.now()}`;
    const newBooking = {
      id,
      teamId: null,
      machineId,
      detail: purpose || 'Scheduled Maintenance',
      type: 'maintenance',
      startTime,
      endTime,
      status: 'confirmed',
    };
    bookings.push(newBooking);

    // Update machine status to 'scheduled' if the maintenance is in the future,
    // or 'maintenance' if it starts now or is ongoing
    const now = new Date();
    const machine = getMachine(machineId);
    if (machine) {
      if (startTime <= now && endTime >= now) {
        machine.status = 'maintenance';
      } else if (startTime > now) {
        machine.status = 'scheduled';
      }
    }

    return newBooking;
  }

  /**
   * Approve a pending booking — change its status to 'confirmed'.
   */
  function approveBooking(bookingId) {
    const booking = bookings.find(b => b.id === bookingId);
    if (booking && booking.status === 'pending') {
      booking.status = 'confirmed';
      booking.type = booking.type === 'pending' ? 'project' : booking.type;
      booking.approvedAt = new Date();
    }
    return booking;
  }

  /**
   * Reject a pending booking — change status to 'rejected' and store the reason.
   * The booking is kept in the array so it appears in history.
   */
  function rejectBooking(bookingId, reason) {
    const booking = bookings.find(b => b.id === bookingId);
    if (booking && booking.status === 'pending') {
      booking.status = 'rejected';
      booking.rejectionReason = reason || '';
      booking.rejectedAt = new Date();
    }
  }

  /**
   * Get booking history — confirmed (approved) and rejected bookings.
   * Uses the same mapping logic as getPendingApprovals() with extra fields.
   */
  function getBookingHistory() {
    return bookings
      .filter(b => b.status === 'confirmed' || b.status === 'rejected')
      .map(b => {
        const team    = getTeam(b.teamId) || {};
        const machine = getMachine(b.machineId) || {};
        const cat     = getCategoryForMachine(b.machineId) || {};
        const durationMs = b.endTime - b.startTime;
        const durationHrs = Math.round(durationMs / 3600000);
        const isApproved = b.status === 'confirmed';
        return {
          bookingId:       b.id,
          team:            team.name || '—',
          faculty:         team.faculty || '—',
          equipment:       `${cat.name || ''} — ${b.machineId}`,
          machineId:       b.machineId,
          catImage:        cat.image,
          catColorClass:   cat.colorClass,
          date:            fmtDate(b.startTime),
          timeSlot:        fmtSlot(b.startTime, b.endTime),
          duration:        `${durationHrs} Hour${durationHrs !== 1 ? 's' : ''}`,
          requester:       team.contact || '—',
          studentId:       team.studentId || '—',
          dept:            team.dept || '—',
          purpose:         b.detail,
          requestedOn:     fmtDatetime(new Date(b.startTime.getTime() - 86400000 * 2)),
          attachment:      `${b.id}_Proposal.pdf`,
          response:        isApproved ? 'Approved' : 'Rejected',
          status:          b.status,
          rejectionReason: b.rejectionReason || null,
        };
      })
      .sort((a, b) => {
        // Sort descending by date (most recent first)
        const aDate = new Date(a.date);
        const bDate = new Date(b.date);
        return bDate - aDate;
      });
  }

  // ─── 6. Equipment Type Groups (for Day View column headers) ─────────────────
  const equipmentTypeGroups = equipmentCategories.map(cat => ({
    id:          cat.id,
    label:       cat.name,
    image:       cat.image,
    colorClass:  cat.colorClass,
    prefix:      cat.prefix,
    prefixes:    [`${cat.prefix}-`],
  }));

  // ─── Expose as window.labDB ──────────────────────────────────────────────────
  window.labDB = {
    equipmentCategories,
    machines,
    teams,
    bookings,
    equipmentTypeGroups,
    // Helpers
    getAllMachinesFlat,
    getTeam,
    getMachine,
    getCategoryForMachine,
    getMachineSpec,
    getPendingApprovals,
    getBookingHistory,
    computeStats,
    addMaintenance,
    approveBooking,
    rejectBooking,
  };

})();
