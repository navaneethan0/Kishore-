// Standalone script for Component Request page

// 1. Initial Mock Data Setup (matching faculty.js)
const session = JSON.parse(localStorage.getItem("faculty_session")) || { name: "Dr. Faculty Name" };

const stages = [
    "Problem Statement",
    "Ideation & Concept Development",
    "Design Phase",
    "Product Development",
    "Testing & Validation",
    "Iteration & Improvement",
    "Advanced Prototype & MVP",
    "Evaluation & Demonstration",
    "Documentation",
    "Deployment"
];

const defaultTeams = [
    {
        id: "PRJ-2025-01",
        name: "Team Alpha",
        project: "AI-Powered Inventory Management System",
        leader: "Arun Kumar",
        leaderId: "22BCS001",
        faculty: "Dr. Faculty Name",
        department: "AI & DS",
        created: "May 15, 2025",
        started: "May 16, 2025",
        deadline: "July 15, 2025",
        description: "The system will automate inventory tracking, stock alerts, and reporting using AI/ML models.",
        members: [
            ["Team Leader", "Arun Kumar", "22BCS001", "AI & DS", "arun@example.com"],
            ["Member", "Priya Sharma", "22BCS002", "AI & DS", "priya@example.com"],
            ["Member", "Rohan Mehta", "22BCS003", "AI & DS", "rohan@example.com"],
            ["Member", "Sneha P", "22BCS004", "AI & DS", "sneha@example.com"],
            ["Member", "Vikram S", "22BCS005", "AI & DS", "vikram@example.com"]
        ]
    },
    {
        id: "PRJ-2025-02",
        name: "Team Beta",
        project: "Smart Attendance Monitoring System",
        leader: "Kavin Raj",
        leaderId: "22BCS011",
        faculty: "Dr. Faculty Name",
        department: "CSE",
        created: "May 18, 2025",
        started: "May 19, 2025",
        deadline: "July 20, 2025",
        description: "A web-based system for automated attendance tracking and report generation.",
        members: [
            ["Team Leader", "Kavin Raj", "22BCS011", "CSE", "kavin@example.com"],
            ["Member", "Nila S", "22BCS012", "CSE", "nila@example.com"],
            ["Member", "Arjun V", "22BCS013", "CSE", "arjun@example.com"],
            ["Member", "Divya R", "22BCS014", "CSE", "divya@example.com"],
            ["Member", "Hari P", "22BCS015", "CSE", "hari@example.com"]
        ]
    },
    {
        id: "PRJ-2025-03",
        name: "Team Gamma",
        project: "IoT Based Energy Monitoring System",
        leader: "Ramesh M",
        leaderId: "22BCS021",
        faculty: "Dr. Faculty Name",
        department: "ECE",
        created: "May 20, 2025",
        started: "May 21, 2025",
        deadline: "July 25, 2025",
        description: "This project monitors energy usage using IoT sensors and provides real-time analytics.",
        members: [
            ["Team Leader", "Ramesh M", "22BCS021", "ECE", "ramesh@example.com"],
            ["Member", "Anitha K", "22BCS022", "ECE", "anitha@example.com"],
            ["Member", "Bala C", "22BCS023", "ECE", "bala@example.com"],
            ["Member", "Deepak N", "22BCS024", "ECE", "deepak@example.com"],
            ["Member", "Meera G", "22BCS025", "ECE", "meera@example.com"]
        ]
    },
    {
        id: "PRJ-2025-04",
        name: "Team Delta",
        project: "Online Complaint Management Portal",
        leader: "Sanjay T",
        leaderId: "22BCS031",
        faculty: "Dr. Faculty Name",
        department: "IT",
        created: "May 22, 2025",
        started: "May 23, 2025",
        deadline: "July 30, 2025",
        description: "A portal for students and staff to register complaints and track resolution progress.",
        members: [
            ["Team Leader", "Sanjay T", "22BCS031", "IT", "sanjay@example.com"],
            ["Member", "Lavanya P", "22BCS032", "IT", "lavanya@example.com"],
            ["Member", "Naveen R", "22BCS033", "IT", "naveen@example.com"],
            ["Member", "Ritika J", "22BCS034", "IT", "ritika@example.com"],
            ["Member", "Suresh L", "22BCS035", "IT", "suresh@example.com"]
        ]
    },
    {
        id: "PRJ-2025-05",
        name: "Team Epsilon",
        project: "Smart Library Book Tracking System",
        leader: "Manoj K",
        leaderId: "22BCS041",
        faculty: "Dr. Faculty Name",
        department: "CSE",
        created: "May 25, 2025",
        started: "May 26, 2025",
        deadline: "August 02, 2025",
        description: "A digital library tracking system that manages book issue, return, availability, and reports.",
        members: [
            ["Team Leader", "Manoj K", "22BCS041", "CSE", "manoj@example.com"],
            ["Member", "Ishwarya S", "22BCS042", "CSE", "ishwarya@example.com"],
            ["Member", "Gokul V", "22BCS043", "CSE", "gokul@example.com"],
            ["Member", "Janani R", "22BCS044", "CSE", "janani@example.com"],
            ["Member", "Varun B", "22BCS045", "CSE", "varun@example.com"]
        ]
    }
];

// Initialize appData
let appData = JSON.parse(localStorage.getItem("facultyReviewSeparateData"));
if (appData && appData.teams && appData.teams.length > 0 && !appData.teams[0].hasOwnProperty("approvalStatus")) {
    appData = null;
    localStorage.removeItem("facultyReviewSeparateData");
}

if (!appData) {
    appData = {
        teams: defaultTeams.map((team) => {
            let appStatus = "Pending";
            if (team.id === "PRJ-2025-01" || team.id === "PRJ-2025-02") {
                appStatus = "Approved";
            }
            return {
                ...team,
                approvalStatus: appStatus,
                studentUnlockedStage: 1,
                stages: stages.map((stageName, index) => {
                    let status = "Locked";
                    if (index === 0) {
                        status = "Submitted";
                    }
                    return {
                        stageNo: index + 1,
                        name: stageName,
                        documentName: index === 0 ? `${stageName.replaceAll(" ", "-")}-${team.name}.pdf` : "-",
                        fileType: index === 0 ? "PDF" : "-",
                        uploadedOn: index === 0 ? "01 Jun 2025" : "-",
                        uploadedBy: index === 0 ? team.leader : "-",
                        version: 1,
                        status: status,
                        reviewer: "-",
                        reviewedOn: "-",
                        comment: "",
                        history: index === 0
                            ? [
                                {
                                    version: 1,
                                    submittedDate: "01 Jun 2025",
                                    reviewedDate: "-",
                                    reviewer: "-",
                                    status: "Submitted"
                                }
                            ]
                            : []
                    };
                })
            };
        })
    };
    saveData();
}

function saveData() {
    localStorage.setItem("facultyReviewSeparateData", JSON.stringify(appData));
}

// Initialize Profile
if (!localStorage.getItem("facultyProfile")) {
    const defaultProfile = {
        name: "Dr. Faculty Name",
        email: "faculty@ilp.edu",
        phone: "+91 98765 43210",
        role: "Technical Faculty",
        password: "password"
    };
    localStorage.setItem("facultyProfile", JSON.stringify(defaultProfile));
}

// Initialize Component Requests
const existingCompRequests = localStorage.getItem("facultyComponentRequests");
let needsReset = false;
if (existingCompRequests) {
    try {
        const parsed = JSON.parse(existingCompRequests);
        if (parsed.length > 0 && !parsed[0].hasOwnProperty("components")) {
            needsReset = true;
        }
    } catch (e) {
        needsReset = true;
    }
} else {
    needsReset = true;
}

if (needsReset) {
    const initialCompRequests = [
        {
            id: "CRQ-2025-001",
            team: "Team Alpha",
            purpose: "For IoT gateway development",
            status: "Pending",
            requestedOn: "15 May 2025",
            deadline: "15 Jul 2025 (60 days left)",
            components: [
                { name: "Raspberry Pi 4 Model B", quantity: 2, status: "Pending" },
                { name: "Jumper Wires Set", quantity: 2, status: "Approved" },
                { name: "5V 3A Power Supply", quantity: 2, status: "Pending" }
            ]
        },
        {
            id: "CRQ-2025-002",
            team: "Team Beta",
            purpose: "For hardware interfacing and display",
            status: "Approved",
            requestedOn: "10 May 2025",
            deadline: "10 Jun 2025 (Completed)",
            components: [
                { name: "Arduino Mega 2560", quantity: 3, status: "Approved" },
                { name: "LCD Display 16x2", quantity: 2, status: "Approved" }
            ]
        },
        {
            id: "CRQ-2025-003",
            team: "Team Gamma",
            purpose: "For wireless communication prototyping",
            status: "Pending",
            requestedOn: "18 May 2025",
            deadline: "20 Jul 2025 (65 days left)",
            components: [
                { name: "ESP32 Dev Kit", quantity: 5, status: "Pending" },
                { name: "Breadboard Large", quantity: 3, status: "Pending" }
            ]
        },
        {
            id: "CRQ-2025-004",
            team: "Team Delta",
            purpose: "For image processing edge module",
            status: "Rejected",
            requestedOn: "12 May 2025",
            deadline: "25 Jul 2025 (70 days left)",
            components: [
                { name: "Camera Module (Pi Cam)", quantity: 1, status: "Rejected" }
            ]
        },
        {
            id: "CRQ-2025-005",
            team: "Team Epsilon",
            purpose: "AI processing at the edge and tracking",
            status: "Pending",
            requestedOn: "20 May 2025",
            deadline: "30 Aug 2025 (90 days left)",
            components: [
                { name: "Nvidia Jetson Nano", quantity: 1, status: "Pending" },
                { name: "RFID RC522 Module", quantity: 4, status: "Pending" },
                { name: "RFID Tags (Card/Key)", quantity: 20, status: "Pending" }
            ]
        }
    ];
    localStorage.setItem("facultyComponentRequests", JSON.stringify(initialCompRequests));
}

// 2. DOM Elements
const headerProfileBlock = document.getElementById("headerProfileBlock");
const profilePopupModal = document.getElementById("profilePopupModal");
const closeProfilePopupModalBtn = document.getElementById("closeProfilePopupModalBtn");
const toast = document.getElementById("toast");

const compTotalRequests = document.getElementById("compTotalRequests");
const compPendingRequests = document.getElementById("compPendingRequests");
const compApprovedRequests = document.getElementById("compApprovedRequests");
const compRejectedRequests = document.getElementById("compRejectedRequests");
const compSearch = document.getElementById("compSearch");
const compTeamFilter = document.getElementById("compTeamFilter");
const compStatusFilter = document.getElementById("compStatusFilter");
const compClearFilterBtn = document.getElementById("compClearFilterBtn");
const componentsRequestsTeamContainer = document.getElementById("componentsRequestsTeamContainer");

const viewComponentsModal = document.getElementById("viewComponentsModal");
const closeCompModalBtn = document.getElementById("closeCompModalBtn");
const compModalReqId = document.getElementById("compModalReqId");
const compModalTeam = document.getElementById("compModalTeam");
const compModalDate = document.getElementById("compModalDate");
const compModalDeadline = document.getElementById("compModalDeadline");
const compModalPurpose = document.getElementById("compModalPurpose");
const compModalTableBody = document.getElementById("compModalTableBody");
const selectAllComponents = document.getElementById("selectAllComponents");
const approveSelectedCompBtn = document.getElementById("approveSelectedCompBtn");
const rejectSelectedCompBtn = document.getElementById("rejectSelectedCompBtn");

let activeRequestForApproval = null;

// 3. UI Helpers
function updateHeaderProfileDisplay() {
    let profile = JSON.parse(localStorage.getItem("facultyProfile"));
    if (!profile) {
        profile = {
            name: session.name || "Dr. Faculty Name",
            email: "faculty@ilp.edu",
            phone: "+91 98765 43210",
            role: "Technical Faculty"
        };
    }

    const headerNameNode = document.querySelector(".header-right h4");
    if (headerNameNode) {
        headerNameNode.textContent = profile.name;
    }

    const headerAvatarNode = document.querySelector(".header-right .faculty-avatar");
    if (headerAvatarNode) {
        headerAvatarNode.textContent = profile.name ? profile.name.trim().charAt(0).toUpperCase() : 'F';
    }
}

function showToast(message) {
    if (toast) {
        toast.textContent = message;
        toast.classList.add("show");
        setTimeout(() => {
            toast.classList.remove("show");
        }, 2500);
    }
}

// 4. Notifications Implementation
const notificationBell = document.getElementById("notificationBell");
const notifDropdown = document.getElementById("notifDropdown");
const notifList = document.getElementById("notifList");
const notifBadge = document.getElementById("notifBadge");
const markAllReadBtn = document.getElementById("markAllReadBtn");
const NOTIF_KEY = "facultyNotifications";

function getNotifications() {
    return JSON.parse(localStorage.getItem(NOTIF_KEY)) || [];
}

function saveNotifications(notifs) {
    localStorage.setItem(NOTIF_KEY, JSON.stringify(notifs));
}

function generateNotifications() {
    const existing = getNotifications();
    const newNotifs = [];

    // Check pending component requests to issue notifications
    const compRequests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];
    compRequests.filter(r => r.status === "Pending").forEach(req => {
        const id = `notif-comp-${req.id}`;
        if (!existing.some(e => e.id === id)) {
            newNotifs.push({
                id: id,
                title: "New Component Request",
                desc: `${req.team} requested components for purpose: ${req.purpose}`,
                timestamp: new Date().getTime(),
                read: false,
                type: "component",
                page: "componentsRequest"
            });
        }
    });

    if (newNotifs.length > 0) {
        const merged = [...newNotifs, ...existing].slice(0, 40);
        saveNotifications(merged);
    }
}

function timeAgo(timestamp) {
    const seconds = Math.floor((new Date().getTime() - timestamp) / 1000);
    if (seconds < 60) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return new Date(timestamp).toLocaleDateString();
}

function iconForType(type) {
    if (type === "component") return "📦";
    return "🔔";
}

function renderNotifications() {
    if (!notifList) return;
    generateNotifications();
    const notifs = getNotifications();
    const unreadCount = notifs.filter(n => !n.read).length;

    if (notifBadge) {
        if (unreadCount > 0) {
            notifBadge.textContent = unreadCount > 9 ? "9+" : unreadCount;
            notifBadge.classList.remove("hidden");
        } else {
            notifBadge.classList.add("hidden");
        }
    }

    notifList.innerHTML = "";
    if (notifs.length === 0) {
        notifList.innerHTML = `
            <div class="notif-empty">
                <span class="notif-empty-icon">🔕</span>
                All caught up! No notifications.
            </div>
        `;
        return;
    }

    notifs.forEach(n => {
        const item = document.createElement("div");
        item.className = `notif-item${n.read ? "" : " unread"}`;
        item.innerHTML = `
            <div class="notif-icon type-${n.type}">${iconForType(n.type)}</div>
            <div class="notif-body">
                <div class="notif-title">${n.title}</div>
                <div class="notif-desc">${n.desc}</div>
                <div class="notif-time">${timeAgo(n.timestamp)}</div>
            </div>
        `;

        item.addEventListener("click", () => {
            const all = getNotifications();
            const idx = all.findIndex(item => item.id === n.id);
            if (idx !== -1) {
                all[idx].read = true;
                saveNotifications(all);
            }
            closeNotifDropdown();
            renderNotifications();
        });
        notifList.appendChild(item);
    });
}

function toggleNotifDropdown() {
    if (notifDropdown) notifDropdown.classList.toggle("show");
}

function closeNotifDropdown() {
    if (notifDropdown) notifDropdown.classList.remove("show");
}

if (notificationBell) {
    notificationBell.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleNotifDropdown();
    });
}

if (markAllReadBtn) {
    markAllReadBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const all = getNotifications().map(n => ({ ...n, read: true }));
        saveNotifications(all);
        renderNotifications();
    });
}

// 5. Component Request Logic
function renderCompTeamFilterOptions() {
    if (!compTeamFilter) return;
    const currentVal = compTeamFilter.value;
    compTeamFilter.innerHTML = `<option value="all">All Teams</option>`;

    const requests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];
    const uniqueTeams = [...new Set(requests.map(r => r.team))];

    uniqueTeams.forEach(team => {
        const option = document.createElement("option");
        option.value = team;
        option.textContent = team;
        compTeamFilter.appendChild(option);
    });

    compTeamFilter.value = currentVal || "all";
}

function renderComponentsRequest() {
    if (!componentsRequestsTeamContainer) return;
    const requests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];

    const query = compSearch.value.toLowerCase();
    const selectedTeam = compTeamFilter.value;
    const selectedStatus = compStatusFilter.value;

    const filtered = requests.filter(req => {
        const componentsText = req.components ? req.components.map(c => c.name).join(" ").toLowerCase() : "";
        const matchesSearch = componentsText.includes(query) ||
            req.team.toLowerCase().includes(query) ||
            req.id.toLowerCase().includes(query);
        const matchesTeam = selectedTeam === "all" || req.team === selectedTeam;
        const matchesStatus = selectedStatus === "all" || req.status === selectedStatus;
        return matchesSearch && matchesTeam && matchesStatus;
    });

    componentsRequestsTeamContainer.innerHTML = "";

    // Calc stats
    const total = filtered.length;
    const pending = filtered.filter(r => r.status === "Pending").length;
    const approved = filtered.filter(r => r.status === "Approved").length;
    const rejected = filtered.filter(r => r.status === "Rejected").length;

    if (compTotalRequests) compTotalRequests.textContent = total;
    if (compPendingRequests) compPendingRequests.textContent = pending;
    if (compApprovedRequests) compApprovedRequests.textContent = approved;
    if (compRejectedRequests) compRejectedRequests.textContent = rejected;

    if (filtered.length === 0) {
        componentsRequestsTeamContainer.innerHTML = `<p class="muted" style="text-align:center; padding:40px; background: white; border-radius: 12px; margin-top: 10px;">No component requests found matching the filters.</p>`;
        return;
    }

    // Group requests by team
    const requestsByTeam = {};
    filtered.forEach(req => {
        if (!requestsByTeam[req.team]) {
            requestsByTeam[req.team] = [];
        }
        requestsByTeam[req.team].push(req);
    });

    // Render team-wise panels
    Object.keys(requestsByTeam).forEach(teamName => {
        const teamRequests = requestsByTeam[teamName];

        // Find matching project description from defaultTeams / appData.teams
        const teamObj = appData.teams.find(t => t.name.toLowerCase() === teamName.toLowerCase()) || {};
        const projectDesc = teamObj.project || "Active Rapid Prototyping Project";

        const card = document.createElement("div");
        card.className = "panel team-request-card";

        let requestsTableRows = "";

        teamRequests.forEach(req => {
            // Create component list summary
            const componentsSummary = req.components ? req.components.map(c => {
                let pillClass = "status-pill status-draft";
                if (c.status === "Pending") pillClass = "status-pill status-review";
                if (c.status === "Approved") pillClass = "status-pill status-approved";
                if (c.status === "Rejected") pillClass = "status-pill status-rejected";
                return `<span class="${pillClass}" style="margin: 2px 4px; display: inline-block;">${c.name} (${c.quantity})</span>`;
            }).join("") : "-";

            let overallBadgeClass = "status-pill status-draft";
            if (req.status === "Pending") overallBadgeClass = "status-pill status-review";
            if (req.status === "Approved") overallBadgeClass = "status-pill status-approved";
            if (req.status === "Rejected") overallBadgeClass = "status-pill status-rejected";

            const reasonHtml = (req.status === "Rejected" && req.rejectionComment)
                ? `<div style="font-size: 11px; color: #dc2626; margin-top: 4px; font-weight: 500; max-width: 140px; word-wrap: break-word;">Reason: ${req.rejectionComment}</div>`
                : "";

            requestsTableRows += `
                <tr>
                    <td><b>${req.id}</b></td>
                    <td><div style="display: flex; flex-wrap: wrap; gap: 4px;">${componentsSummary}</div></td>
                    <td>${req.purpose}</td>
                    <td><span class="${overallBadgeClass}">${req.status}</span>${reasonHtml}</td>
                    <td>${req.requestedOn}</td>
                    <td>${req.deadline || "-"}</td>
                    <td>
                        <button class="review-btn" onclick="openComponentRequestModal('${req.id}')" style="padding: 6px 12px; font-size: 12px;">View Components</button>
                    </td>
                </tr>
            `;
        });

        card.innerHTML = `
            <div class="panel-title" style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e5e7eb; padding-bottom: 12px; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h3 style="color: #003366; margin: 0; font-size: 17px; font-weight: 700;"><i class="fa-solid fa-users" style="margin-right: 8px; color: var(--primary);"></i> ${teamName}</h3>
                    <p class="muted" style="margin: 4px 0 0 0; font-size: 13px; font-weight: 500;">Project: ${projectDesc}</p>
                </div>
                 <span class="status-pill status-approved" style="font-size: 11px; padding: 4px 10px; font-weight: 700; background: var(--primary-soft); color: var(--primary);">${teamRequests.length} Request(s)</span>
            </div>
            
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 110px;">Request ID</th>
                            <th>Requested Components</th>
                            <th style="max-width: 150px;">Purpose</th>
                            <th>Overall Status</th>
                            <th>Requested On</th>
                            <th>Deadline</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${requestsTableRows}
                    </tbody>
                </table>
            </div>
        `;

        componentsRequestsTeamContainer.appendChild(card);
    });
}

function openComponentRequestModal(reqId) {
    const requests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];
    const req = requests.find(r => r.id === reqId);
    if (!req) return;

    activeRequestForApproval = reqId;

    compModalReqId.textContent = req.id;
    compModalTeam.textContent = req.team;
    compModalDate.textContent = req.requestedOn;
    compModalDeadline.textContent = req.deadline || "-";
    compModalPurpose.textContent = req.purpose;

    compModalTableBody.innerHTML = "";
    selectAllComponents.checked = false;

    const isAssigned = appData.teams.some(t => t.name.toLowerCase() === req.team.toLowerCase());
    const hasPendingComponents = req.components.some(c => c.status === "Pending");
    const showActions = isAssigned && hasPendingComponents;

    const actionsDiv = document.getElementById("compModalActions");
    if (actionsDiv) {
        actionsDiv.style.display = showActions ? "flex" : "none";
    }

    if (!isAssigned) {
        selectAllComponents.disabled = true;
        document.getElementById("compModalSubTitle").innerHTML = `<span style="color: #dc2626; font-weight: 700;"><i class="fa-solid fa-triangle-exclamation"></i> View Only - Not Assigned to You</span>`;
    } else {
        selectAllComponents.disabled = !hasPendingComponents;
        document.getElementById("compModalSubTitle").innerHTML = `<span style="color: var(--primary); font-weight: 600;"><i class="fa-solid fa-circle-info"></i> Manage components for ${req.team}</span>`;
    }

    req.components.forEach((c, index) => {
        const row = document.createElement("tr");

        let checkboxHtml = "";
        if (c.status === "Pending" && isAssigned) {
            checkboxHtml = `<input type="checkbox" class="comp-item-checkbox" data-index="${index}" style="width:18px; height:18px; cursor:pointer;">`;
        } else {
            checkboxHtml = `<input type="checkbox" disabled style="width:18px; height:18px; opacity: 0.3;">`;
        }

        let qtyHtml = "";
        if (c.status === "Pending" && isAssigned) {
            qtyHtml = `<input type="number" class="comp-qty-input" data-index="${index}" value="${c.quantity}" min="1" style="width: 60px; padding: 4px; border: 1px solid #cbd5e1; border-radius: 4px; text-align: center; font-weight: 600;">`;
        } else {
            qtyHtml = `<span style="font-weight: 600;">${c.quantity}</span>`;
        }

        let badgeClass = "status-pill status-draft";
        if (c.status === "Pending") badgeClass = "status-pill status-review";
        if (c.status === "Approved") badgeClass = "status-pill status-approved";
        if (c.status === "Rejected") badgeClass = "status-pill status-rejected";

        row.innerHTML = `
            <td style="text-align: center;">${checkboxHtml}</td>
            <td><b>${c.name}</b></td>
            <td>${qtyHtml}</td>
            <td><span class="${badgeClass}">${c.status}</span></td>
        `;

        compModalTableBody.appendChild(row);

        const qtyInput = row.querySelector(".comp-qty-input");
        if (qtyInput) {
            qtyInput.addEventListener("change", function (e) {
                const qtyVal = parseInt(e.target.value) || 1;
                const requests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];
                const reqIndex = requests.findIndex(r => r.id === reqId);
                if (reqIndex !== -1) {
                    requests[reqIndex].components[index].quantity = qtyVal;
                    localStorage.setItem("facultyComponentRequests", JSON.stringify(requests));
                    req.components[index].quantity = qtyVal;
                }
            });
        }
    });

    selectAllComponents.onchange = function () {
        const checkboxes = compModalTableBody.querySelectorAll(".comp-item-checkbox:not(:disabled)");
        checkboxes.forEach(cb => {
            cb.checked = selectAllComponents.checked;
        });
    };

    viewComponentsModal.classList.add("show");
}

function bulkActionComponentRequests(action) {
    if (!activeRequestForApproval) return;

    const requests = JSON.parse(localStorage.getItem("facultyComponentRequests")) || [];
    const reqIndex = requests.findIndex(r => r.id === activeRequestForApproval);
    if (reqIndex === -1) return;

    const req = requests[reqIndex];

    const isAssigned = appData.teams.some(t => t.name.toLowerCase() === req.team.toLowerCase());
    if (!isAssigned) {
        showToast("Permission Denied: Team is not assigned to you.");
        return;
    }

    const checkboxes = compModalTableBody.querySelectorAll(".comp-item-checkbox:checked");
    if (checkboxes.length === 0) {
        showToast("Please select at least one component first.");
        return;
    }

    let rejectionComment = "";
    if (action === "Rejected") {
        rejectionComment = prompt("Please enter a reason/comment for rejecting the selected components:");
        if (rejectionComment === null) return; // User clicked cancel
        rejectionComment = rejectionComment.trim();
        if (!rejectionComment) {
            showToast("Rejection comment is required to reject a request.");
            return;
        }
        req.rejectionComment = rejectionComment;
    } else if (action === "Approved") {
        delete req.rejectionComment;
    }

    checkboxes.forEach(cb => {
        const index = parseInt(cb.dataset.index);
        req.components[index].status = action;
    });

    const hasPending = req.components.some(c => c.status === "Pending");
    if (hasPending) {
        req.status = "Pending";
    } else {
        const hasApproved = req.components.some(c => c.status === "Approved");
        if (hasApproved) {
            req.status = "Approved";
        } else {
            req.status = "Rejected";
        }
    }

    requests[reqIndex] = req;
    localStorage.setItem("facultyComponentRequests", JSON.stringify(requests));

    showToast(`Selected components have been ${action.toLowerCase()}.`);
    viewComponentsModal.classList.remove("show");

    renderComponentsRequest();
}

window.openComponentRequestModal = openComponentRequestModal;
window.bulkActionComponentRequests = bulkActionComponentRequests;

if (compSearch) compSearch.addEventListener("input", renderComponentsRequest);
if (compTeamFilter) compTeamFilter.addEventListener("change", renderComponentsRequest);
if (compStatusFilter) compStatusFilter.addEventListener("change", renderComponentsRequest);
if (compClearFilterBtn) {
    compClearFilterBtn.addEventListener("click", () => {
        compSearch.value = "";
        compTeamFilter.value = "all";
        compStatusFilter.value = "all";
        renderComponentsRequest();
    });
}

// 7. Profile Popup Event Listeners
if (headerProfileBlock && profilePopupModal) {
    headerProfileBlock.addEventListener("click", (e) => {
        e.stopPropagation();
        let profile = JSON.parse(localStorage.getItem("facultyProfile"));
        if (!profile) {
            profile = {
                name: session.name || "Dr. Faculty Name",
                email: "faculty@ilp.edu",
                phone: "+91 98765 43210",
                role: "Technical Faculty"
            };
        }
        document.getElementById("popupProfileName").textContent = profile.name;
        document.getElementById("popupProfileRole").textContent = profile.role || "Technical Faculty";
        document.getElementById("popupProfileEmail").textContent = profile.email;
        document.getElementById("popupProfilePhone").textContent = profile.phone || "+91 98765 43210";

        const avatarChar = profile.name ? profile.name.trim().charAt(0).toUpperCase() : 'F';
        const modalAvatar = profilePopupModal.querySelector(".faculty-avatar");
        if (modalAvatar) modalAvatar.textContent = avatarChar;

        profilePopupModal.classList.add("show");
    });
}

if (closeProfilePopupModalBtn && profilePopupModal) {
    closeProfilePopupModalBtn.addEventListener("click", () => {
        profilePopupModal.classList.remove("show");
    });
}

if (profilePopupModal) {
    profilePopupModal.addEventListener("click", (e) => {
        if (e.target === profilePopupModal) {
            profilePopupModal.classList.remove("show");
        }
    });
}

// Bind Modal Action Buttons
if (approveSelectedCompBtn) {
    approveSelectedCompBtn.addEventListener("click", () => { bulkActionComponentRequests("Approved"); });
}
if (rejectSelectedCompBtn) {
    rejectSelectedCompBtn.addEventListener("click", () => { bulkActionComponentRequests("Rejected"); });
}
if (closeCompModalBtn) {
    closeCompModalBtn.addEventListener("click", () => { viewComponentsModal.classList.remove("show"); });
}
if (viewComponentsModal) {
    viewComponentsModal.onclick = (e) => {
        if (e.target === viewComponentsModal) {
            viewComponentsModal.classList.remove("show");
        }
    };
}

// 8. Initialization
function initAll() {
    updateHeaderProfileDisplay();
    renderCompTeamFilterOptions();
    renderComponentsRequest();
    renderNotifications();
}

document.addEventListener("DOMContentLoaded", initAll);
// Fallback if DOMContentLoaded already fired
if (document.readyState === "interactive" || document.readyState === "complete") {
    initAll();
}


document.addEventListener("click", (e) => {
    // Handle close button explicitly to avoid detached reference issues
    const closeBtn = e.target.closest("#closeCompModalBtn");
    if (closeBtn) {
        const modal = document.getElementById("viewComponentsModal");
        if (modal) modal.classList.remove("show", "open");
    }
});


document.addEventListener("click", (e) => {
    // Handle overlay click closing
    if (e.target.classList.contains("modal-overlay")) {
        e.target.classList.remove("show", "open");
    }
});
