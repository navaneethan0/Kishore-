/* ============================================================
   PROTOTRACK — MATERIAL HANDOVER MANAGEMENT
   script.js  |  Complete application logic
   ============================================================ */

/* ===========================
   1. SAMPLE DATA
=========================== */

/** Inventory — flat map keyed by materialId */
const inventory = {
    // ---- Tools ----
    "T-001": { id: "T-001", name: "Screwdriver", category: "tool", totalStock: 15, availableStock: 12 },
    "T-002": { id: "T-002", name: "Multimeter", category: "tool", totalStock: 10, availableStock: 8 },
    "T-003": { id: "T-003", name: "Wire Cutter", category: "tool", totalStock: 12, availableStock: 10 },
    "T-004": { id: "T-004", name: "Plier", category: "tool", totalStock: 14, availableStock: 11 },
    "T-005": { id: "T-005", name: "Soldering Iron", category: "tool", totalStock: 8, availableStock: 6 },
    "T-006": { id: "T-006", name: "Heat Gun", category: "tool", totalStock: 5, availableStock: 4 },
    "T-007": { id: "T-007", name: "Glue Gun", category: "tool", totalStock: 10, availableStock: 8 },
    "T-008": { id: "T-008", name: "Drill Machine", category: "tool", totalStock: 6, availableStock: 5 },
    "T-009": { id: "T-009", name: "Oscilloscope", category: "tool", totalStock: 4, availableStock: 3 },
    "T-010": { id: "T-010", name: "Power Supply", category: "tool", totalStock: 8, availableStock: 7 },
    "T-011": { id: "T-011", name: "Crimping Tool", category: "tool", totalStock: 10, availableStock: 9 },
    "T-012": { id: "T-012", name: "Wire Stripper", category: "tool", totalStock: 12, availableStock: 10 },
    "T-013": { id: "T-013", name: "Allen Key Set", category: "tool", totalStock: 7, availableStock: 6 },
    "T-014": { id: "T-014", name: "Tweezers", category: "tool", totalStock: 20, availableStock: 18 },
    "T-015": { id: "T-015", name: "Digital Caliper", category: "tool", totalStock: 5, availableStock: 4 },

    // ---- Components ----
    "C-001": { id: "C-001", name: "Arduino UNO", category: "component", totalStock: 30, availableStock: 22 },
    "C-002": { id: "C-002", name: "ESP32", category: "component", totalStock: 25, availableStock: 18 },
    "C-003": { id: "C-003", name: "Breadboard", category: "component", totalStock: 40, availableStock: 32 },
    "C-004": { id: "C-004", name: "Servo Motor", category: "component", totalStock: 20, availableStock: 15 },
    "C-005": { id: "C-005", name: "DC Motor", category: "component", totalStock: 25, availableStock: 20 },
    "C-006": { id: "C-006", name: "Relay Module", category: "component", totalStock: 30, availableStock: 24 },
    "C-007": { id: "C-007", name: "Soil Moisture Sensor", category: "component", totalStock: 20, availableStock: 16 },
    "C-008": { id: "C-008", name: "Jumper Wires Pack", category: "component", totalStock: 50, availableStock: 40 },
    "C-009": { id: "C-009", name: "Resistor Pack", category: "component", totalStock: 50, availableStock: 45 },
    "C-010": { id: "C-010", name: "Capacitor Pack", category: "component", totalStock: 40, availableStock: 35 },
    "C-011": { id: "C-011", name: "LED Pack", category: "component", totalStock: 50, availableStock: 42 },
    "C-012": { id: "C-012", name: "IR Sensor", category: "component", totalStock: 20, availableStock: 16 },
    "C-013": { id: "C-013", name: "Ultrasonic Sensor", category: "component", totalStock: 15, availableStock: 12 },
    "C-014": { id: "C-014", name: "LCD Display", category: "component", totalStock: 18, availableStock: 14 },
    "C-015": { id: "C-015", name: "Battery Holder", category: "component", totalStock: 25, availableStock: 20 }
};

// Team / Faculty pools for sample data
const teams = [
    { name: "Team Alpha", leader: "Sumanth" },
    { name: "Team Beta", leader: "Arun" },
    { name: "Team Gamma", leader: "Vijay" },
    { name: "Team Delta", leader: "Karan" },
    { name: "Team Epsilon", leader: "Priya" },
    { name: "Team Zeta", leader: "Meena" },
    { name: "Team Theta", leader: "Rahul" },
    { name: "Team Kappa", leader: "Sneha" },
    { name: "Team Lambda", leader: "Deepak" },
    { name: "Team Sigma", leader: "Ananya" }
];

const faculties = ["Dr. Kumar", "Dr. Sharma", "Dr. Patel", "Dr. Reddy", "Dr. Iyer"];

const projects = [
    "Smart Irrigation", "Automated Greenhouse", "Line Following Robot",
    "Weather Station", "Home Automation", "Drone Controller",
    "Water Quality Monitor", "Solar Tracker", "Smart Parking",
    "IoT Security System", "Voice Assistant", "Gesture Control"
];

const dates = [
    "2025-05-10", "2025-05-14", "2025-05-18", "2025-05-22", "2025-05-26",
    "2025-05-30", "2025-06-03", "2025-06-07", "2025-06-11", "2025-06-15",
    "2025-06-19", "2025-06-23", "2025-06-27", "2025-07-01", "2025-07-05",
    "2025-07-09", "2025-07-12", "2025-07-15"
];

/** Build a random subset of N materials from a given pool */
function pickRandom(arr, n) {
    const shuffled = [...arr].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, n);
}

/** Deterministic time strings for sample data */
const sampleTimes = [
    "08:30 AM", "09:00 AM", "09:15 AM", "09:45 AM", "10:00 AM",
    "10:30 AM", "10:45 AM", "11:00 AM", "11:15 AM", "11:30 AM",
    "11:45 AM", "12:00 PM", "12:30 PM", "01:00 PM", "01:30 PM",
    "02:00 PM", "02:30 PM", "03:00 PM"
];

/** Create sample requests for a given type ("tool" | "component") */
function generateRequests(type, count) {
    const prefix = type === "tool" ? "TR" : "CR";
    const matPool = Object.values(inventory).filter(m => m.category === type);
    const requests = [];

    for (let i = 1; i <= count; i++) {
        const id = `${prefix}-${String(i).padStart(3, "0")}`;
        const team = teams[i % teams.length];
        const faculty = faculties[i % faculties.length];
        const project = projects[i % projects.length];
        const date = dates[i % dates.length];
        const requestTime = sampleTimes[i % sampleTimes.length];
        const matCount = 3 + (i % 4); // 3-6 materials
        const mats = pickRandom(matPool, matCount);

        // Determine initial handover state for variety
        let handedOverFraction = 0; // 0 = Ready, 0.5 = Partial, 1 = Completed
        if (i <= 18) handedOverFraction = 0;     // Ready for Handover
        else if (i <= 25) handedOverFraction = 0.5;    // Partially Handed Over
        else handedOverFraction = 1;      // Fully Handed Over

        const materials = mats.map(m => {
            const requestedQty = 2 + (i % 5) + Math.floor(Math.random() * 4);
            let handedOverQty = 0;
            if (handedOverFraction === 1) {
                handedOverQty = requestedQty;
            } else if (handedOverFraction === 0.5) {
                handedOverQty = Math.max(1, Math.floor(requestedQty * 0.4));
            }
            return {
                materialId: m.id,
                name: m.name,
                requestedQty,
                handedOverQty,
                remainingQty: requestedQty - handedOverQty
            };
        });

        // Build handover history for partial/completed requests
        const handoverHistory = [];
        if (handedOverFraction > 0) {
            const histMats = materials
                .filter(m => m.handedOverQty > 0)
                .map(m => ({ materialId: m.materialId, name: m.name, qty: m.handedOverQty }));

            if (histMats.length > 0) {
                handoverHistory.push({
                    handoverNumber: 1,
                    timestamp: formatDateDisplay(date) + ", " + requestTime,
                    handedOverBy: "Ravi Kumar",
                    materials: histMats
                });
            }
        }

        // Build team ID from team name initials + padded number
        const teamInitials = team.name.split(' ').slice(1).map(w => w[0]).join('').toUpperCase() || 'T';
        const teamId = `${teamInitials}-${String(i).padStart(3, '0')}`;

        requests.push({
            requestId: id,
            teamId,
            teamName: team.name,
            teamLeader: team.leader,
            project,
            faculty,
            requestDate: date,
            requestTime,
            requestType: type,
            materials,
            handoverHistory
        });
    }
    return requests;
}

// Generate 30 tool + 30 component requests
const toolRequests = generateRequests("tool", 30);
const componentRequests = generateRequests("component", 30);


/* ===========================
   2. APPLICATION STATE
=========================== */
const state = {
    currentView: "dashboard",       // "dashboard" | "queue" | "verification" | "confirmation" | "history"
    activeTab: "tool",              // "tool" | "component"
    selectedRequestId: null,
    searchTerm: "",
    filters: { faculty: "all", status: "all", filterDate: "" },
    sortOrder: "oldest",
    currentPage: 1,
    pageSize: 10,
    todayHandovers: [],             // log: { requestId, materials, timestamp }
    handOverNowValues: {}           // temporary: { materialId: qty } during verification
};


/* ===========================
   20. UTILITY FUNCTIONS (placed early so other sections can use them)
=========================== */

/** Shorthand selectors */
const $ = sel => document.querySelector(sel);
const $$ = sel => document.querySelectorAll(sel);

/** Show a specific view, hide all others */
function showView(viewName) {
    state.currentView = viewName;
    $$('.view').forEach(v => v.classList.remove('active'));

    if (viewName === 'dashboard') {
        $('#dashboard-view').classList.add('active');
        $('#page-breadcrumb').textContent = 'Dashboard';
    } else if (viewName === 'queue') {
        $('#queue-view').classList.add('active');
        $('#page-breadcrumb').textContent = 'Dashboard › ' + (state.activeTab === 'tool' ? 'Tool Queue' : 'Component Queue');
    }
}

/** Get the combined request list for the active tab */
function getActiveRequests() {
    return state.activeTab === "tool" ? toolRequests : componentRequests;
}

/** Get a request by ID from both lists */
function getRequestById(requestId) {
    return toolRequests.find(r => r.requestId === requestId) ||
        componentRequests.find(r => r.requestId === requestId);
}

/** Compute status from materials — NEVER stored, always derived */
function getRequestStatus(request) {
    const totalHandedOver = request.materials.reduce((s, m) => s + m.handedOverQty, 0);
    const totalRemaining = request.materials.reduce((s, m) => s + m.remainingQty, 0);
    if (totalHandedOver === 0) return "Ready for Handover";
    if (totalRemaining === 0) return "Fully Handed Over";
    return "Partially Handed Over";
}

/** Map status to badge class suffix */
function statusToBadgeClass(status) {
    if (status === "Ready for Handover") return "ready";
    if (status === "Partially Handed Over") return "partial";
    return "done";
}

/** Generate badge HTML */
function generateBadgeHTML(status) {
    const cls = statusToBadgeClass(status);
    const short = status === "Ready for Handover" ? "Awaiting Handover" :
        status === "Partially Handed Over" ? "Partial" : "Handed Over";
    return `<span class="badge badge-${cls}"><span class="badge-dot"></span>${short}</span>`;
}

/** Format ISO date string to display format */
function formatDateDisplay(dateStr) {
    const d = new Date(dateStr);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

/** Format current date/time for display */
function formatNow() {
    return new Date().toLocaleString('en-IN', {
        day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
}


/* ===========================
   14. REQUEST STATUS CALCULATION
   (placed here as utility — used by multiple sections)
=========================== */
// getRequestStatus() already defined above in utilities


/* ===========================
   3. DASHBOARD RENDERING
=========================== */

function getKPICounts(requestType) {
    const list = requestType === "tool" ? toolRequests : componentRequests;
    let pending = 0, partial = 0, completed = 0;
    list.forEach(r => {
        const status = getRequestStatus(r);
        if (status === "Ready for Handover") pending++;
        else if (status === "Partially Handed Over") partial++;
        else completed++;
    });
    return { pending, partial, completed };
}

function renderDashboard() {
    const toolCounts = getKPICounts("tool");
    $('#kpi-tool-pending').textContent = toolCounts.pending;
    $('#kpi-tool-partial').textContent = toolCounts.partial;
    $('#kpi-tool-completed').textContent = toolCounts.completed;

    const compCounts = getKPICounts("component");
    $('#kpi-comp-pending').textContent = compCounts.pending;
    $('#kpi-comp-partial').textContent = compCounts.partial;
    $('#kpi-comp-completed').textContent = compCounts.completed;

    // Today's summary (across both types)
    // Active tool/components: Pending + Partial
    $('#summary-total').textContent = toolCounts.pending + toolCounts.partial;
    $('#summary-components').textContent = compCounts.pending + compCounts.partial;

    // Items handed over today (during this session)
    const handedToday = state.todayHandovers.reduce((sum, h) =>
        sum + h.materials.reduce((s, m) => s + m.qty, 0), 0);
    $('#summary-handed-today').textContent = handedToday;

    // Pending items (remaining across all requests)
    const allRequests = [...toolRequests, ...componentRequests];
    const pendingItems = allRequests.reduce((sum, r) =>
        sum + r.materials.reduce((s, m) => s + m.remainingQty, 0), 0);
    $('#summary-pending').textContent = pendingItems;
}


/* ===========================
   5. SEARCH
=========================== */

function matchesSearch(request, term) {
    if (!term) return true;
    const lower = term.toLowerCase();
    return request.requestId.toLowerCase().includes(lower) ||
        request.teamName.toLowerCase().includes(lower) ||
        (request.teamId && request.teamId.toLowerCase().includes(lower)) ||
        request.teamLeader.toLowerCase().includes(lower) ||
        request.project.toLowerCase().includes(lower) ||
        request.faculty.toLowerCase().includes(lower);
}


/* ===========================
   6. FILTERS
=========================== */

function matchesFilters(request) {
    const { faculty, status, filterDate } = state.filters;

    if (faculty !== "all" && request.faculty !== faculty) return false;

    if (status !== "all") {
        const computed = getRequestStatus(request);
        if (status === "ready" && computed !== "Ready for Handover") return false;
        if (status === "partial" && computed !== "Partially Handed Over") return false;
        if (status === "completed" && computed !== "Fully Handed Over") return false;
    }

    // Date filter: exact ISO date match
    if (filterDate && filterDate !== "") {
        if (request.requestDate !== filterDate) return false;
    }

    return true;
}

/** Get filtered, searched, sorted requests */
function getFilteredRequests() {
    let list = [...getActiveRequests()];

    // Search
    list = list.filter(r => matchesSearch(r, state.searchTerm));

    // Filters
    list = list.filter(r => matchesFilters(r));

    // Sort
    list.sort((a, b) => {
        const da = new Date(a.requestDate), db = new Date(b.requestDate);
        return state.sortOrder === "latest" ? db - da : da - db;
    });

    return list;
}


/* ===========================
   7. SORTING — handled inside getFilteredRequests()
=========================== */


/* ===========================
   8. PAGINATION
=========================== */

function renderPagination(totalItems) {
    const totalPages = Math.max(1, Math.ceil(totalItems / state.pageSize));
    if (state.currentPage > totalPages) state.currentPage = totalPages;

    const start = (state.currentPage - 1) * state.pageSize + 1;
    const end = Math.min(state.currentPage * state.pageSize, totalItems);

    $('#pagination-info').textContent = totalItems === 0
        ? 'Showing 0 to 0 of 0 entries'
        : `Showing ${start} to ${end} of ${totalItems} entries`;

    const controls = $('#pagination-controls');
    controls.innerHTML = '';

    // Previous button
    const prevBtn = document.createElement('button');
    prevBtn.className = 'page-btn';
    prevBtn.innerHTML = '&#8249;';
    prevBtn.disabled = state.currentPage === 1;
    prevBtn.addEventListener('click', () => goToPage(state.currentPage - 1));
    controls.appendChild(prevBtn);

    // Page numbers — show max 5 pages
    let startPage = Math.max(1, state.currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    if (endPage - startPage < 4) startPage = Math.max(1, endPage - 4);

    for (let p = startPage; p <= endPage; p++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = 'page-btn' + (p === state.currentPage ? ' active' : '');
        pageBtn.textContent = p;
        pageBtn.addEventListener('click', () => goToPage(p));
        controls.appendChild(pageBtn);
    }

    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.className = 'page-btn';
    nextBtn.innerHTML = '&#8250;';
    nextBtn.disabled = state.currentPage === totalPages;
    nextBtn.addEventListener('click', () => goToPage(state.currentPage + 1));
    controls.appendChild(nextBtn);
}

function goToPage(pageNum) {
    state.currentPage = pageNum;
    renderQueue();
}


/* ===========================
   4. MATERIAL QUEUE RENDERING
=========================== */

function renderQueue() {
    const filtered = getFilteredRequests();
    const totalItems = filtered.length;

    // Paginate
    const start = (state.currentPage - 1) * state.pageSize;
    const pageItems = filtered.slice(start, start + state.pageSize);

    const tbody = $('#queue-tbody');
    tbody.innerHTML = '';

    if (pageItems.length === 0) {
        tbody.innerHTML = `<tr class="empty-row"><td colspan="8">No requests found matching your criteria.</td></tr>`;
    } else {
        pageItems.forEach(request => {
            tbody.innerHTML += renderQueueRow(request);
        });
    }

    // Attach action button events
    tbody.querySelectorAll('.btn-handover, .btn-continue').forEach(btn => {
        btn.addEventListener('click', () => openVerificationDrawer(btn.dataset.id));
    });
    tbody.querySelectorAll('.btn-history').forEach(btn => {
        btn.addEventListener('click', () => openHandoverHistory(btn.dataset.id));
    });

    renderPagination(totalItems);
}

function renderQueueRow(request) {
    const status = getRequestStatus(request);
    const badgeHTML = generateBadgeHTML(status);
    const isCompleted = status === "Fully Handed Over";
    const isPartial = status === "Partially Handed Over";
    const issueLabel = request.requestType === "tool" ? "Hand Over Tools" : "Hand Over Components";

    // Pick button class & label based on status
    let actionBtnClass, actionBtnLabel;
    if (isCompleted) {
        actionBtnClass = "btn-history btn-view-text";
        actionBtnLabel = "View";
    } else if (isPartial) {
        actionBtnClass = "btn-continue";
        actionBtnLabel = "Continue";
    } else {
        actionBtnClass = "btn-handover";
        actionBtnLabel = issueLabel;
    }

    const term = state.searchTerm;
    const h = (text) => {
        if (!term || !text) return text;
        const safeTerm = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(${safeTerm})`, 'gi');
        return String(text).replace(regex, '<mark>$1</mark>');
    };

    return `
        <tr>
            <td class="td-reqid">${h(request.requestId)}</td>
            <td class="td-teamid">${h(request.teamId) || '—'}</td>
            <td class="td-team">${h(request.teamName)}</td>
            <td class="td-faculty">${h(request.faculty)}</td>
            <td class="td-time">${request.requestTime || '—'}</td>
            <td class="td-date">${formatDateDisplay(request.requestDate)}</td>
            <td>${badgeHTML}</td>
            <td>
                <div class="action-cell">
                    <button class="${actionBtnClass}" data-id="${request.requestId}">
                        ${actionBtnLabel}
                    </button>
                </div>
            </td>
        </tr>
    `;
}

/** Populate faculty filter dropdown dynamically */
function populateFacultyFilter() {
    const sel = $('#filter-faculty');
    sel.innerHTML = '<option value="all">All Faculty</option>';
    const unique = [...new Set([...toolRequests, ...componentRequests].map(r => r.faculty))];
    unique.sort().forEach(f => {
        sel.innerHTML += `<option value="${f}">${f}</option>`;
    });
}


/* ===========================
   9. REVIEW REQUEST DRAWER (Verification)
=========================== */

function openVerificationDrawer(requestId) {
    const request = getRequestById(requestId);
    if (!request) return;

    state.selectedRequestId = requestId;
    state.handOverNowValues = {};

    // Set header
    const typeLabel = request.requestType === "tool" ? "TOOL MATERIAL VERIFICATION" : "COMPONENT MATERIAL VERIFICATION";
    $('#drawer-title').textContent = typeLabel;
    $('#drawer-request-id').textContent = request.requestId;

    // Fill team info
    $('#info-req-id').textContent = request.requestId;
    $('#info-team').textContent = request.teamName;
    $('#info-leader').textContent = request.teamLeader;
    $('#info-project').textContent = request.project;
    $('#info-faculty').textContent = request.faculty;
    $('#info-date').textContent = formatDateDisplay(request.requestDate);
    // Extra fields (set to dash if element missing)
    const drEl = $('#info-dr'); if (drEl) drEl.textContent = request.faculty;
    const irrigEl = $('#info-irrigation'); if (irrigEl) irrigEl.textContent = request.project;
    const tfEl = $('#info-tech-faculty'); if (tfEl) tfEl.textContent = request.faculty;

    // Materials label
    $('#materials-label').textContent = request.requestType === "tool"
        ? "Tools to be Handed Over"
        : "Components to be Handed Over";

    // Build material rows
    renderMaterialTable(request);

    // Update summary
    updateVerificationSummary();

    // Reset "Next" button
    $('#btn-next-confirm').disabled = true;

    // Show verification step, hide confirmation step
    $('#step-verification').classList.remove('hidden-step');
    $('#step-verification').classList.add('active-step');
    $('#step-confirmation').classList.remove('active-step');
    $('#step-confirmation').classList.add('hidden-step');

    // Show drawer + overlay
    $('#drawer-overlay').classList.remove('hidden');
    $('#verification-drawer').classList.remove('hidden');
}

function closeDrawer() {
    $('#drawer-overlay').classList.add('hidden');
    $('#verification-drawer').classList.add('hidden');
    state.selectedRequestId = null;
    state.handOverNowValues = {};
}


/* ===========================
   10. MATERIAL VERIFICATION (table rendering)
=========================== */

function renderMaterialTable(request) {
    const tbody = $('#material-tbody');
    tbody.innerHTML = '';

    request.materials.forEach(mat => {
        const inv = inventory[mat.materialId];
        const availableStock = inv ? inv.availableStock : 0;
        const maxAllowed = Math.min(availableStock, mat.remainingQty);

        tbody.innerHTML += renderMaterialRow(mat, availableStock, maxAllowed);
    });

    // Attach input events
    tbody.querySelectorAll('.qty-input').forEach(input => {
        input.addEventListener('input', handleQuantityInput);
        input.addEventListener('change', handleQuantityInput);
    });

    tbody.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', handleCheckboxChange);
    });

    updateSelectAllState();
}

function renderMaterialRow(material, availableStock, maxAllowed) {
    const isFullyHandedOver = material.remainingQty === 0;
    return `
        <tr data-mat-id="${material.materialId}">
            <td class="cb-col">
                <input type="checkbox" class="row-checkbox"
                       data-mat-id="${material.materialId}"
                       data-max="${maxAllowed}"
                       ${isFullyHandedOver || maxAllowed === 0 ? 'disabled' : ''} />
            </td>
            <td>
                <span class="mat-name">${material.name}</span>
                <span class="mat-id">${material.materialId}</span>
            </td>
            <td>${material.requestedQty}</td>
            <td>${material.handedOverQty}</td>
            <td>${availableStock}</td>
            <td>
                <input type="number"
                       class="qty-input"
                       data-mat-id="${material.materialId}"
                       data-max="${maxAllowed}"
                       min="0"
                       max="${maxAllowed}"
                       value="0"
                       ${isFullyHandedOver ? 'disabled' : ''} />
            </td>
            <td class="remaining-val ${material.remainingQty === 0 ? 'remaining-zero' : ''}" data-remaining="${material.materialId}">
                ${material.remainingQty}
            </td>
        </tr>
    `;
}


/* ===========================
   12. QUANTITY VALIDATION
=========================== */

function handleQuantityInput(e) {
    const input = e.target;
    const matId = input.dataset.matId;
    const max = parseInt(input.dataset.max) || 0;

    let val = parseInt(input.value) || 0;

    // Clamp
    if (val < 0) val = 0;
    if (val > max) val = max;
    input.value = val;

    // Visual feedback
    if (val > max) {
        input.classList.add('over-limit');
    } else {
        input.classList.remove('over-limit');
    }

    // Store
    state.handOverNowValues[matId] = val;

    // Update remaining column
    const request = getRequestById(state.selectedRequestId);
    if (request) {
        const mat = request.materials.find(m => m.materialId === matId);
        if (mat) {
            const remaining = mat.remainingQty - val;
            const cell = $(`[data-remaining="${matId}"]`);
            if (cell) {
                cell.textContent = remaining;
                cell.classList.toggle('remaining-zero', remaining === 0);
            }
        }
    }

    // 13. Live Summary Calculation
    updateVerificationSummary();

    // Sync Checkbox
    const cb = document.querySelector(`.row-checkbox[data-mat-id="${matId}"]`);
    if (cb && !cb.disabled) {
        cb.checked = val > 0;
    }
    updateSelectAllState();

    // 11. Enable/disable "Next" button
    updateNextButton();
}

function handleCheckboxChange(e) {
    const cb = e.target;
    const matId = cb.dataset.matId;
    const max = parseInt(cb.dataset.max) || 0;
    const input = document.querySelector(`.qty-input[data-mat-id="${matId}"]`);

    if (input) {
        input.value = cb.checked ? max : 0;
        input.dispatchEvent(new Event('input', { bubbles: true }));
    }
}

function handleSelectAllChange(e) {
    const isChecked = e.target.checked;
    const checkboxes = document.querySelectorAll('.row-checkbox:not(:disabled)');
    checkboxes.forEach(cb => {
        cb.checked = isChecked;
        const matId = cb.dataset.matId;
        const max = parseInt(cb.dataset.max) || 0;
        const input = document.querySelector(`.qty-input[data-mat-id="${matId}"]`);
        if (input) {
            input.value = isChecked ? max : 0;
            // dispatch input event so existing logic processes new value
            input.dispatchEvent(new Event('input', { bubbles: true }));
        }
    });
}

function updateSelectAllState() {
    const selectAllCheck = document.getElementById('select-all-tools');
    if (!selectAllCheck) return;

    const checkboxes = Array.from(document.querySelectorAll('.row-checkbox:not(:disabled)'));
    if (checkboxes.length === 0) {
        selectAllCheck.checked = false;
        selectAllCheck.disabled = true;
        return;
    }

    selectAllCheck.disabled = false;
    const allChecked = checkboxes.every(cb => cb.checked);
    const someChecked = checkboxes.some(cb => cb.checked);

    selectAllCheck.checked = allChecked;
    selectAllCheck.indeterminate = someChecked && !allChecked;
}


/* ===========================
   11. APPROVAL CHECKBOX LOGIC (Next button enable/disable)
=========================== */

function updateNextButton() {
    const hasAny = Object.values(state.handOverNowValues).some(v => v > 0);
    $('#btn-next-confirm').disabled = !hasAny;
}


/* ===========================
   13. LIVE SUMMARY CALCULATION
=========================== */

function updateVerificationSummary() {
    const request = getRequestById(state.selectedRequestId);
    if (!request) return;

    let totalRequested = 0, alreadyHandedOver = 0, handingOverToday = 0;

    request.materials.forEach(mat => {
        totalRequested += mat.requestedQty;
        alreadyHandedOver += mat.handedOverQty;
        handingOverToday += (state.handOverNowValues[mat.materialId] || 0);
    });

    const remaining = totalRequested - alreadyHandedOver - handingOverToday;

    $('#sum-requested').textContent = totalRequested;
    $('#sum-already').textContent = alreadyHandedOver;
    $('#sum-today').textContent = handingOverToday;
    $('#sum-remaining').textContent = remaining;

    const remBox = $('#sum-remaining').parentElement;
    if (remBox) {
        remBox.classList.toggle('summary-box-remaining-active', remaining > 0);
    }
}


/* ===========================
   15. HANDOVER CONFIRMATION
=========================== */

function showConfirmation() {
    const request = getRequestById(state.selectedRequestId);
    if (!request) return;

    // Validate at least one item
    const hasAny = Object.values(state.handOverNowValues).some(v => v > 0);
    if (!hasAny) return;

    // Switch drawer steps
    $('#step-verification').classList.remove('active-step');
    $('#step-verification').classList.add('hidden-step');
    $('#step-confirmation').classList.remove('hidden-step');
    $('#step-confirmation').classList.add('active-step');

    // Fill confirmation header
    const typeLabel = request.requestType === "tool"
        ? "TOOL HANDOVER CONFIRMATION"
        : "COMPONENT HANDOVER CONFIRMATION";
    $('#confirm-drawer-title').textContent = typeLabel;
    $('#confirm-request-id').textContent = request.requestId;

    // Fill team info (read-only)
    $('#conf-req-id').textContent = request.requestId;
    $('#conf-team').textContent = request.teamName;
    $('#conf-leader').textContent = request.teamLeader;
    $('#conf-project').textContent = request.project;
    $('#conf-faculty').textContent = request.faculty;
    $('#conf-date').textContent = formatDateDisplay(request.requestDate);

    // Render confirmation table — only items with handOverNow > 0
    renderConfirmationTable(request);

    // Reset checkbox and button
    $('#confirm-checkbox').checked = false;
    $('#btn-confirm-handover').disabled = true;
}

function renderConfirmationTable(request) {
    const tbody = $('#confirm-tbody');
    tbody.innerHTML = '';

    request.materials.forEach(mat => {
        const qty = state.handOverNowValues[mat.materialId] || 0;
        if (qty > 0) {
            const remainingAfter = mat.remainingQty - qty;
            tbody.innerHTML += `
                <tr>
                    <td>
                        <span class="mat-name">${mat.name}</span>
                        <span class="mat-id">${mat.materialId}</span>
                    </td>
                    <td>${mat.requestedQty}</td>
                    <td>${mat.handedOverQty}</td>
                    <td><span class="qty-badge">${qty}</span></td>
                    <td class="${remainingAfter === 0 ? 'remaining-zero' : ''}">${remainingAfter}</td>
                </tr>
            `;
        }
    });
}

function handleConfirmCheckbox() {
    const checked = $('#confirm-checkbox').checked;
    $('#btn-confirm-handover').disabled = !checked;
}

function backToVerification() {
    $('#step-confirmation').classList.remove('active-step');
    $('#step-confirmation').classList.add('hidden-step');
    $('#step-verification').classList.remove('hidden-step');
    $('#step-verification').classList.add('active-step');
}


/* ===========================
   16. INVENTORY UPDATE + confirmHandover()
=========================== */

function confirmHandover() {
    const request = getRequestById(state.selectedRequestId);
    if (!request) return;

    const handedMaterials = [];
    let totalHandedItems = 0;

    request.materials.forEach(mat => {
        const qty = state.handOverNowValues[mat.materialId] || 0;
        if (qty > 0) {
            // Update request material quantities
            mat.handedOverQty += qty;
            mat.remainingQty -= qty;

            // Update inventory
            if (inventory[mat.materialId]) {
                inventory[mat.materialId].availableStock -= qty;
            }

            handedMaterials.push({ materialId: mat.materialId, name: mat.name, qty });
            totalHandedItems += qty;
        }
    });

    // Build handover record and add to request history
    const nextNumber = request.handoverHistory.length + 1;
    const timestamp = formatNow();
    request.handoverHistory.push({
        handoverNumber: nextNumber,
        timestamp: timestamp,
        handedOverBy: "Ravi Kumar",
        materials: handedMaterials
    });

    // Log in today's handovers
    state.todayHandovers.push({
        requestId: request.requestId,
        materials: handedMaterials,
        timestamp: timestamp
    });

    // Compute remaining for success popup
    const totalRemaining = request.materials.reduce((s, m) => s + m.remainingQty, 0);

    // Close drawer
    closeDrawer();

    // 17. Show success popup
    showSuccessPopup({
        requestId: request.requestId,
        teamName: request.teamName,
        itemsCount: handedMaterials.length,
        totalHandedItems,
        remaining: totalRemaining,
        requestType: request.requestType,
        timestamp
    });

    // 18. Dashboard refresh + 19. Queue refresh happen when user navigates back
}


/* ===========================
   17. SUCCESS POPUP
=========================== */

function showSuccessPopup(details) {
    const typeTitle = details.requestType === "tool"
        ? "TOOLS HANDED OVER SUCCESSFULLY!"
        : "COMPONENTS HANDED OVER SUCCESSFULLY!";

    $('#success-title').textContent = typeTitle;
    $('#suc-req-id').textContent = details.requestId;
    $('#suc-team').textContent = details.teamName;
    $('#suc-items').textContent = details.totalHandedItems;
    $('#suc-remaining').textContent = details.remaining;
    $('#suc-by').textContent = "Ravi Kumar";
    $('#suc-datetime').textContent = details.timestamp;

    $('#success-modal').classList.remove('hidden');
}

function closeSuccessPopup() {
    $('#success-modal').classList.add('hidden');
    // 19. Queue Refresh
    renderQueue();
    // 18. Dashboard Refresh (for when user goes back to dashboard)
    renderDashboard();
}


/* ===========================
   HANDOVER HISTORY
=========================== */

function openHandoverHistory(requestId) {
    const request = getRequestById(requestId);
    if (!request) return;

    // Fill header
    $('#history-request-id').textContent = request.requestId;

    // Fill team info
    $('#hist-req-id').textContent = request.requestId;
    $('#hist-team').textContent = request.teamName;
    $('#hist-leader').textContent = request.teamLeader;
    $('#hist-project').textContent = request.project;
    $('#hist-faculty').textContent = request.faculty;
    $('#hist-date').textContent = formatDateDisplay(request.requestDate);

    // Cumulative summary
    const totalRequested = request.materials.reduce((s, m) => s + m.requestedQty, 0);
    const totalHandedOver = request.materials.reduce((s, m) => s + m.handedOverQty, 0);
    const totalRemaining = request.materials.reduce((s, m) => s + m.remainingQty, 0);

    $('#hist-sum-requested').textContent = totalRequested;
    $('#hist-sum-handedover').textContent = totalHandedOver;
    $('#hist-sum-remaining').textContent = totalRemaining;
    $('#hist-sum-sessions').textContent = request.handoverHistory.length;

    // Additional progress summary updates
    const percent = totalRequested > 0 ? Math.round((totalHandedOver / totalRequested) * 100) : 0;
    $('#hist-progress-fill').style.width = `${percent}%`;
    $('#hist-progress-text').textContent = `${percent}%`;
    $('#hist-status-text').textContent = getRequestStatus(request);
    $('#hist-unique-items-count').textContent = request.materials.length;

    // Render timeline
    renderHistoryTimeline(request.handoverHistory);

    // Show history drawer + overlay
    $('#drawer-overlay').classList.remove('hidden');
    $('#history-drawer').classList.remove('hidden');
}

function renderHistoryTimeline(handovers) {
    const container = $('#history-timeline');
    container.innerHTML = '';

    if (handovers.length === 0) {
        container.innerHTML = '<div class="history-empty">No handover history available.</div>';
        return;
    }

    // Show most recent first
    [...handovers].reverse().forEach(h => {
        const matCards = h.materials.map(m =>
            `<div class="history-mat-card">
                <span class="history-mat-name">${m.name}</span>
                <span class="history-mat-qty">Qty: <strong>${m.qty}</strong></span>
            </div>`
        ).join('');

        container.innerHTML += `
            <div class="history-entry">
                <div class="history-entry-header">
                    <span class="history-badge">Handover #${h.handoverNumber}</span>
                    <div class="history-meta">
                        <span class="history-time">${h.timestamp}</span>
                        <span class="history-by">By: ${h.handedOverBy}</span>
                    </div>
                </div>
                <div class="history-materials">${matCards}</div>
            </div>
        `;
    });
}

function closeHistoryDrawer() {
    $('#drawer-overlay').classList.add('hidden');
    $('#history-drawer').classList.add('hidden');
}


/* ===========================
   INITIALIZATION
=========================== */

function init() {
    // Render default view
    renderDashboard();
    populateFacultyFilter();

    // ---- Tab switching ----
    $('#tab-tool').addEventListener('click', () => {
        state.activeTab = 'tool';
        $('#tab-tool').classList.add('active');
        $('#tab-component').classList.remove('active');
        renderDashboard();
    });

    $('#tab-component').addEventListener('click', () => {
        state.activeTab = 'component';
        $('#tab-component').classList.add('active');
        $('#tab-tool').classList.remove('active');
        renderDashboard();
    });

    // ---- Action buttons (open queue) ----
    $('#btn-open-tool-queue').addEventListener('click', () => {
        state.activeTab = 'tool';
        state.currentPage = 1;
        state.searchTerm = '';
        state.filters = { faculty: 'all', status: 'all' };
        state.sortOrder = 'oldest';
        resetFilterUI();
        const qt = $('#queue-title'); if (qt) qt.textContent = 'TOOL REQUEST QUEUE';
        const qhTitle = $('#queue-header-title'); if (qhTitle) qhTitle.textContent = 'Request Queue';
        const qhSub = $('#queue-header-subtitle'); if (qhSub) qhSub.textContent = 'List of tool requests approved by faculty';
        const colHeader = $('#col-num-items'); if (colHeader) colHeader.textContent = 'No. of Tools';
        showView('queue');
        renderQueue();
    });

    $('#btn-open-component-queue').addEventListener('click', () => {
        state.activeTab = 'component';
        state.currentPage = 1;
        state.searchTerm = '';
        state.filters = { faculty: 'all', status: 'all' };
        state.sortOrder = 'oldest';
        resetFilterUI();
        const qt = $('#queue-title'); if (qt) qt.textContent = 'COMPONENT REQUEST QUEUE';
        const qhTitle = $('#queue-header-title'); if (qhTitle) qhTitle.textContent = 'Request Queue';
        const qhSub = $('#queue-header-subtitle'); if (qhSub) qhSub.textContent = 'List of component requests approved by faculty';
        const colHeader = $('#col-num-items'); if (colHeader) colHeader.textContent = 'No. of Components';
        showView('queue');
        renderQueue();
    });

    // ---- Back to Dashboard ----
    $('#btn-back-to-dashboard').addEventListener('click', () => {
        showView('dashboard');
        renderDashboard();
    });

    // ---- Search ----
    $('#search-input').addEventListener('input', e => {
        state.searchTerm = e.target.value.trim();
        state.currentPage = 1;
        renderQueue();
    });

    // ---- Filters ----
    $('#filter-faculty').addEventListener('change', e => {
        state.filters.faculty = e.target.value;
        state.currentPage = 1;
        renderQueue();
    });

    $('#filter-status').addEventListener('change', e => {
        state.filters.status = e.target.value;
        state.currentPage = 1;
        renderQueue();
    });

    // ---- Sort ----
    $('#filter-date').addEventListener('change', e => {
        state.sortOrder = e.target.value;
        state.currentPage = 1;
        renderQueue();
    });

    // ---- Date picker filter ----
    $('#filter-date-picker').addEventListener('change', e => {
        state.filters.filterDate = e.target.value;
        state.currentPage = 1;
        renderQueue();
    });

    // ---- Reset ----
    $('#btn-reset-filters').addEventListener('click', () => {
        state.searchTerm = '';
        state.filters = { faculty: 'all', status: 'all', filterDate: '' };
        state.sortOrder = 'latest';
        state.currentPage = 1;
        resetFilterUI();
        renderQueue();
    });

    // ---- Drawer: Cancel / Close ----
    $('#btn-cancel-verification').addEventListener('click', closeDrawer);
    $('#btn-close-drawer').addEventListener('click', closeDrawer);
    $('#drawer-overlay').addEventListener('click', () => {
        // Close whichever drawer is open
        if (!$('#verification-drawer').classList.contains('hidden')) closeDrawer();
        if (!$('#history-drawer').classList.contains('hidden')) closeHistoryDrawer();
    });

    // ---- Drawer: Next → Confirmation ----
    $('#btn-next-confirm').addEventListener('click', showConfirmation);

    // ---- Confirmation: Back to Verification ----
    $('#btn-back-to-verification').addEventListener('click', backToVerification);

    // ---- Confirmation: Checkbox ----
    $('#confirm-checkbox').addEventListener('change', handleConfirmCheckbox);

    // ---- Confirmation: Close ----
    $('#btn-close-confirm').addEventListener('click', closeDrawer);

    // ---- Confirmation: Confirm Handover ----
    $('#btn-confirm-handover').addEventListener('click', confirmHandover);

    // ---- Success popup: Back to Queue ----
    $('#btn-back-to-queue').addEventListener('click', closeSuccessPopup);

    // ---- History drawer: Close ----
    $('#btn-close-history').addEventListener('click', closeHistoryDrawer);
    $('#btn-close-history-footer').addEventListener('click', closeHistoryDrawer);

    // ---- Select All Checkbox ----
    const selectAllCb = $('#select-all-tools');
    if (selectAllCb) {
        selectAllCb.addEventListener('change', handleSelectAllChange);
    }
}

/** Reset filter UI controls to defaults */
function resetFilterUI() {
    $('#search-input').value = '';
    $('#filter-faculty').value = 'all';
    $('#filter-status').value = 'all';
    $('#filter-date').value = 'oldest';
    $('#filter-date-picker').value = '';
}


/* ===========================
   BOOT
=========================== */

document.addEventListener('DOMContentLoaded', init);
