/* =====================================================
   LAB ASSET MANAGEMENT
   COMPLETE SCRIPT
===================================================== */

/* =====================================================
   SAMPLE INVENTORY DATA
===================================================== */

const rowsPerPage = 10;
let currentPage = 1;
let filteredInventory = [];
let selectedCategory = "Component";
let editingAssetId = null;

const inventory = [
    {
        id: 1,
        assetName: "Arduino Uno R3",
        category: "Component",
        make: "Arduino",
        specification: "ATmega328P",
        cost: 850,
        returnTimeline: "Project Completion",
        total: 40,
        available: 28,
        issued: 12,
        componentType: "Microcontroller",
        lab: "IoT Lab",
        cupboard: "Cupboard A",
        shelf1: "Shelf 1",
        count1: 20,
        shelf2: "Shelf 2",
        count2: 20,
        purpose: "Embedded & IoT Projects",
        comments: "Handle carefully.",
        remarks: "",
        status: "Available"
    },
    {
        id: 2,
        assetName: "ESP32 Dev Kit",
        category: "Component",
        make: "Espressif",
        specification: "ESP32-WROOM",
        cost: 650,
        returnTimeline: "Project Completion",
        total: 35,
        available: 4,
        issued: 31,
        componentType: "Microcontroller",
        lab: "IoT Lab",
        cupboard: "Cupboard A",
        shelf1: "Shelf 3",
        count1: 15,
        shelf2: "Shelf 4",
        count2: 20,
        purpose: "IoT Development",
        comments: "Low stock.",
        remarks: "",
        status: "Low Stock"
    },
    {
        id: 3,
        assetName: "Ultrasonic Sensor",
        category: "Component",
        make: "HC-SR04",
        specification: "Distance Sensor",
        cost: 180,
        returnTimeline: "Daily",
        total: 50,
        available: 32,
        issued: 18,
        componentType: "Sensor",
        lab: "Embedded Lab",
        cupboard: "Cupboard B",
        shelf1: "Shelf 2",
        count1: 25,
        shelf2: "Shelf 3",
        count2: 25,
        purpose: "Obstacle Detection",
        comments: "Store in anti-static box.",
        remarks: "",
        status: "Available"
    },
    {
        id: 4,
        assetName: "Raspberry Pi 4",
        category: "Component",
        make: "Raspberry Pi",
        specification: "8GB RAM",
        cost: 6500,
        returnTimeline: "Project Completion",
        total: 15,
        available: 2,
        issued: 13,
        componentType: "Single Board Computer",
        lab: "IoT Lab",
        cupboard: "Cupboard C",
        shelf1: "Shelf 1",
        count1: 8,
        shelf2: "Shelf 2",
        count2: 7,
        purpose: "Edge Computing",
        comments: "Return with SD Card.",
        remarks: "",
        status: "Low Stock"
    },
    {
        id: 5,
        assetName: "Digital Multimeter",
        category: "Tool",
        make: "Fluke",
        specification: "117",
        cost: 4500,
        returnTimeline: "Daily",
        total: 18,
        available: 10,
        issued: 8,
        componentType: "Testing Tool",
        lab: "Electronics Lab",
        cupboard: "Cupboard D",
        shelf1: "Shelf 1",
        count1: 9,
        shelf2: "Shelf 2",
        count2: 9,
        purpose: "Voltage Measurement",
        comments: "Calibrate yearly.",
        remarks: "",
        status: "Available"
    },
    {
        id: 6,
        assetName: "Soldering Station",
        category: "Tool",
        make: "Hakko",
        specification: "FX888D",
        cost: 9500,
        returnTimeline: "Daily",
        total: 10,
        available: 1,
        issued: 9,
        componentType: "Assembly Tool",
        lab: "Electronics Lab",
        cupboard: "Cupboard E",
        shelf1: "Shelf 1",
        count1: 5,
        shelf2: "Shelf 2",
        count2: 5,
        purpose: "PCB Assembly",
        comments: "Switch off after use.",
        remarks: "",
        status: "Low Stock"
    },
    {
        id: 7,
        assetName: "Wire Stripper",
        category: "Tool",
        make: "Stanley",
        specification: "Professional",
        cost: 900,
        returnTimeline: "Daily",
        total: 20,
        available: 20,
        issued: 0,
        componentType: "Hand Tool",
        lab: "Fabrication Lab",
        cupboard: "Cupboard F",
        shelf1: "Shelf 1",
        count1: 10,
        shelf2: "Shelf 2",
        count2: 10,
        purpose: "Cable Preparation",
        comments: "Keep clean.",
        remarks: "",
        status: "Available"
    },
    {
        id: 8,
        assetName: "3D Printer",
        category: "Equipment",
        make: "Creality",
        specification: "Ender 3 V3",
        cost: "",
        returnTimeline: "",
        total: 2,
        available: 2,
        issued: 0,
        componentType: "3D Printer",
        lab: "Rapid Prototyping Lab",
        cupboard: "",
        shelf1: "",
        count1: "",
        shelf2: "",
        count2: "",
        purpose: "",
        comments: "",
        remarks: "Operational. Scheduled maintenance every quarter.",
        status: "Available"
    },
    {
        id: 9,
        assetName: "Laser Cutter",
        category: "Equipment",
        make: "Glowforge",
        specification: "Pro",
        cost: "",
        returnTimeline: "",
        total: 1,
        available: 1,
        issued: 0,
        componentType: "Laser Cutter",
        lab: "Fabrication Lab",
        cupboard: "",
        shelf1: "",
        count1: "",
        shelf2: "",
        count2: "",
        purpose: "",
        comments: "",
        remarks: "Currently under maintenance. Service due in 2 weeks.",
        status: "Maintenance"
    },
    {
        id: 10,
        assetName: "CNC Milling Machine",
        category: "Equipment",
        make: "Roland",
        specification: "SRM-20",
        cost: "",
        returnTimeline: "",
        total: 1,
        available: 1,
        issued: 0,
        componentType: "CNC Machine",
        lab: "Manufacturing Lab",
        cupboard: "",
        shelf1: "",
        count1: "",
        shelf2: "",
        count2: "",
        purpose: "",
        comments: "",
        remarks: "Available for faculty-approved projects only.",
        status: "Available"
    }
];

/* =====================================================
   DOM ELEMENTS
===================================================== */

const tableBody = document.getElementById("assetTableBody");
const totalInventory = document.getElementById("totalInventory");
const availableInventory = document.getElementById("availableInventory");
const issuedInventory = document.getElementById("issuedInventory");
const lowStock = document.getElementById("lowStock");

const componentCount = document.getElementById("componentCount");
const toolCount = document.getElementById("toolCount");
const equipmentCount = document.getElementById("equipmentCount");
const availableComponents = document.getElementById("availableComponents");
const availableTools = document.getElementById("availableTools");
const availableEquipments = document.getElementById("availableEquipments");
const issuedComponents = document.getElementById("issuedComponents");
const issuedTools = document.getElementById("issuedTools");
const issuedEquipments = document.getElementById("issuedEquipments");
const lowComponent = document.getElementById("lowComponent");
const lowTool = document.getElementById("lowTool");

const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const statusFilter = document.getElementById("statusFilter");
const quickFilters = document.querySelectorAll(".quick-filters button");
const flipCards = document.querySelectorAll(".flip-card");

/* =====================================================
   MODAL DOM REFERENCES
===================================================== */

const modalOverlay = document.getElementById("modalOverlay");
const addAssetModal = document.getElementById("addAssetModal");
const viewAssetModal = document.getElementById("viewAssetModal");
const editAssetModal = document.getElementById("editAssetModal");
const bulkUploadModal = document.getElementById("bulkUploadModal");
const deleteAssetModal = document.getElementById("deleteAssetModal");

/* =====================================================
   HELPER FUNCTIONS
===================================================== */

function getStatusBadge(status) {
    const className = {
        "Available": "available",
        "Low Stock": "low",
        "Issued": "issued",
        "Maintenance": "maintenance",
        "Out of Stock": "out"
    }[status] || "";
    return `<span class="status ${className}">${status}</span>`;
}

function getCategoryBadge(category) {
    return `<span class="category ${category.toLowerCase()}">${category}</span>`;
}

/* =====================================================
   TOAST NOTIFICATION - BOTTOM RIGHT
===================================================== */

function showToast(message, type = 'success') {
    // Remove any existing toast
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }

    const toast = document.createElement("div");
    toast.className = `toast-notification ${type}`;

    // Add icon based on type
    const icon = document.createElement("i");
    const iconMap = {
        success: 'fa-solid fa-check-circle',
        error: 'fa-solid fa-circle-exclamation',
        warning: 'fa-solid fa-triangle-exclamation',
        info: 'fa-solid fa-circle-info'
    };
    icon.className = iconMap[type] || iconMap.success;
    toast.prepend(icon);

    // Add message
    const textSpan = document.createElement("span");
    textSpan.textContent = message;
    toast.appendChild(textSpan);

    document.body.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
        toast.classList.add('show');
    });

    // Auto dismiss
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 300);
    }, 3000);
}


/* MOBILE SIDEBAR OMITTED */
/* =====================================================
   SEARCH HIGHLIGHTING FUNCTIONALITY
===================================================== */

// Store the current search term globally
let currentSearchTerm = "";

// Function to highlight text in a string
function highlightText(text, searchTerm) {
    if (!searchTerm || searchTerm.trim() === "") {
        return text;
    }

    const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<span class="search-highlight">$1</span>');
}

// Modified renderTable function with highlighting
function renderTableWithHighlight(data, searchTerm) {
    tableBody.innerHTML = "";

    if (data.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="10">
                    <div class="empty-state">
                        <i class="fa-solid fa-box-open"></i>
                        <h3>No Assets Found</h3>
                        <p>Try changing your filters.</p>
                    </div>
                </td>
            </tr>
        `;
        updateTableFooter(0);
        return;
    }

    const start = (currentPage - 1) * rowsPerPage;
    const end = Math.min(start + rowsPerPage, data.length);
    const pageData = data.slice(start, end);

    pageData.forEach(asset => {
        // Highlight search terms in relevant fields
        const highlightedName = highlightText(asset.assetName, searchTerm);
        const highlightedMake = highlightText(asset.make, searchTerm);
        const highlightedSpec = highlightText(asset.specification, searchTerm);

        tableBody.innerHTML += `
            <tr>
                <td>${asset.id}</td>
                <td>${highlightedName}</td>
                <td>${getCategoryBadge(asset.category)}</td>
                <td>${highlightedMake}</td>
                <td>${highlightedSpec}</td>
                <td>${asset.total}</td>
                <td>${asset.category === "Equipment" ? "-" : asset.available}</td>
                <td>${getStatusBadge(asset.status)}</td>
                <td>${asset.lab}</td>
                <td>
                    <div class="action-buttons">
                        <button data-id="${asset.id}" class="action-btn view-btn">
                            <i class="fa-solid fa-eye"></i>
                        </button>
                        <button data-id="${asset.id}" class="action-btn edit-btn">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    attachViewButtonEvents();
    attachEditButtonEvents();
    updateTableFooter(data.length);
}

// Override the original renderTable function
const originalRenderTable = renderTable;
renderTable = function (data) {
    renderTableWithHighlight(data, currentSearchTerm);
};

// Update the search handler
searchInput.addEventListener("keyup", function () {
    currentSearchTerm = this.value.trim();
    applyFilters();
});

// Update the applyFilters function to use the current search term
const originalApplyFilters = applyFilters;
applyFilters = function () {
    const searchText = searchInput.value.toLowerCase().trim();
    const category = categoryFilter.value;
    const status = statusFilter.value;

    filteredInventory = inventory.filter(asset => {
        const matchesSearch = asset.assetName.toLowerCase().includes(searchText) ||
            asset.make.toLowerCase().includes(searchText) ||
            asset.specification.toLowerCase().includes(searchText);

        const matchesCategory = category === "" || asset.category === category;
        const matchesStatus = status === "" || asset.status === status;

        let matchesQuick = true;
        switch (activeQuickFilter) {
            case "Components": matchesQuick = asset.category === "Component"; break;
            case "Tools": matchesQuick = asset.category === "Tool"; break;
            case "Equipments": matchesQuick = asset.category === "Equipment"; break;
            case "Low Stock": matchesQuick = asset.status === "Low Stock"; break;
            case "Out of Stock": matchesQuick = asset.status === "Out of Stock"; break;
            case "Maintenance": matchesQuick = asset.status === "Maintenance"; break;
            default: matchesQuick = true;
        }

        return matchesSearch && matchesCategory && matchesStatus && matchesQuick;
    });

    currentSearchTerm = searchText;
    currentPage = 1;
    renderTableWithHighlight(filteredInventory, currentSearchTerm);
};

// Also update the reset function to clear highlighting
function resetFilters() {
    searchInput.value = "";
    currentSearchTerm = "";
    categoryFilter.selectedIndex = 0;
    statusFilter.selectedIndex = 0;
    activeQuickFilter = "All";
    quickFilters.forEach(btn => {
        btn.classList.remove("active");
    });
    quickFilters[0].classList.add("active");
    filteredInventory = [...inventory];
    currentPage = 1;
    renderTableWithHighlight(filteredInventory, "");
}

/* =====================================================
   MODAL CONTROLS
===================================================== */

function openModal(modalElement) {
    modalOverlay.classList.add("active");
    modalElement.classList.add("active");
    document.body.style.overflow = "hidden";
}

function closeModal(modalElement) {
    modalElement.classList.remove("active");
    modalOverlay.classList.remove("active");
    document.body.style.overflow = "";
}

function closeAllModals() {
    document.querySelectorAll(".modal-container").forEach(m => {
        m.classList.remove("active");
    });
    modalOverlay.classList.remove("active");
    document.body.style.overflow = "";
}

modalOverlay.addEventListener("click", closeAllModals);
document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAllModals();
});

/* =====================================================
   RENDER TABLE
===================================================== */

function renderTable(data) {
    tableBody.innerHTML = "";

    if (data.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="10">
                    <div class="empty-state">
                        <i class="fa-solid fa-box-open"></i>
                        <h3>No Assets Found</h3>
                        <p>Try changing your filters.</p>
                    </div>
                </td>
            </tr>
        `;
        updateTableFooter(0);
        return;
    }

    const start = (currentPage - 1) * rowsPerPage;
    const end = Math.min(start + rowsPerPage, data.length);
    const pageData = data.slice(start, end);

    pageData.forEach(asset => {
        tableBody.innerHTML += `
            <tr>
                <td>${asset.id}</td>
                <td>${asset.assetName}</td>
                <td>${getCategoryBadge(asset.category)}</td>
                <td>${asset.make}</td>
                <td>${asset.specification}</td>
                <td>${asset.total}</td>
                <td>${asset.category === "Equipment" ? "-" : asset.available}</td>
                <td>${getStatusBadge(asset.status)}</td>
                <td>${asset.lab}</td>
                <td>
                    <div class="action-buttons">
                        <button data-id="${asset.id}" class="action-btn view-btn">
                            <i class="fa-solid fa-eye"></i>
                        </button>
                        <button data-id="${asset.id}" class="action-btn edit-btn">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });

    attachViewButtonEvents();
    attachEditButtonEvents();
    updateTableFooter(data.length);
}

function updateTableFooter(totalAssets) {
    const start = totalAssets === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1;
    const end = Math.min(currentPage * rowsPerPage, totalAssets);
    document.getElementById("tableInfo").textContent =
        `Showing ${start} to ${end} of ${totalAssets} assets`;
    document.getElementById("pageNumber").textContent = currentPage;
}

/* =====================================================
   PAGINATION
===================================================== */

document.getElementById("prevPage").addEventListener("click", () => {
    if (currentPage > 1) {
        currentPage--;
        renderTable(filteredInventory);
    }
});

document.getElementById("nextPage").addEventListener("click", () => {
    const totalPages = Math.ceil(filteredInventory.length / rowsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        renderTable(filteredInventory);
    }
});

/* =====================================================
   DASHBOARD STATISTICS
===================================================== */

function updateStats() {
    const totalQty = inventory.reduce((sum, item) => sum + item.total, 0);
    const availableQty = inventory.reduce((sum, item) => sum + item.available, 0);
    const issuedQty = inventory.reduce((sum, item) => sum + item.issued, 0);
    const lowStockQty = inventory.filter(item =>
        item.status === "Low Stock" && item.category !== "Equipment"
    ).length;

    totalInventory.textContent = totalQty;
    availableInventory.textContent = availableQty;
    issuedInventory.textContent = issuedQty;
    lowStock.textContent = lowStockQty;

    componentCount.textContent = inventory.filter(i => i.category === "Component").reduce((s, i) => s + i.total, 0);
    toolCount.textContent = inventory.filter(i => i.category === "Tool").reduce((s, i) => s + i.total, 0);
    equipmentCount.textContent = inventory.filter(i => i.category === "Equipment").reduce((s, i) => s + i.total, 0);

    availableComponents.textContent = inventory.filter(i => i.category === "Component").reduce((s, i) => s + i.available, 0);
    availableTools.textContent = inventory.filter(i => i.category === "Tool").reduce((s, i) => s + i.available, 0);
    availableEquipments.textContent = inventory.filter(i => i.category === "Equipment").reduce((s, i) => s + i.available, 0);

    issuedComponents.textContent = inventory.filter(i => i.category === "Component").reduce((s, i) => s + i.issued, 0);
    issuedTools.textContent = inventory.filter(i => i.category === "Tool").reduce((s, i) => s + i.issued, 0);
    issuedEquipments.textContent = inventory.filter(i => i.category === "Equipment").reduce((s, i) => s + i.issued, 0);

    lowComponent.textContent = inventory.filter(i => i.category === "Component" && i.status === "Low Stock").length;
    lowTool.textContent = inventory.filter(i => i.category === "Tool" && i.status === "Low Stock").length;
}

/* =====================================================
   FLIP CARDS
===================================================== */

flipCards.forEach(card => {
    card.addEventListener("click", () => {
        card.classList.toggle("flipped");
    });
});

/* =====================================================
   SEARCH & FILTERS
===================================================== */

let activeQuickFilter = "All";

function applyFilters() {
    const searchText = searchInput.value.toLowerCase().trim();
    const category = categoryFilter.value;
    const status = statusFilter.value;

    filteredInventory = inventory.filter(asset => {
        const matchesSearch = asset.assetName.toLowerCase().includes(searchText) ||
            asset.make.toLowerCase().includes(searchText) ||
            asset.specification.toLowerCase().includes(searchText);

        const matchesCategory = category === "" || asset.category === category;
        const matchesStatus = status === "" || asset.status === status;

        let matchesQuick = true;
        switch (activeQuickFilter) {
            case "Components": matchesQuick = asset.category === "Component"; break;
            case "Tools": matchesQuick = asset.category === "Tool"; break;
            case "Equipments": matchesQuick = asset.category === "Equipment"; break;
            case "Low Stock": matchesQuick = asset.status === "Low Stock"; break;
            case "Out of Stock": matchesQuick = asset.status === "Out of Stock"; break;
            case "Maintenance": matchesQuick = asset.status === "Maintenance"; break;
            default: matchesQuick = true;
        }

        return matchesSearch && matchesCategory && matchesStatus && matchesQuick;
    });

    currentPage = 1;
    renderTable(filteredInventory);
}

searchInput.addEventListener("keyup", applyFilters);
categoryFilter.addEventListener("change", applyFilters);
statusFilter.addEventListener("change", applyFilters);

quickFilters.forEach(button => {
    button.addEventListener("click", () => {
        quickFilters.forEach(btn => btn.classList.remove("active"));
        button.classList.add("active");
        activeQuickFilter = button.textContent.trim();
        applyFilters();
    });
});

/* =====================================================
   ADD ASSET MODAL
===================================================== */

const categoryCards = document.querySelectorAll(".category-card");
const componentToolFields = document.getElementById("componentToolFields");
const equipmentFields = document.getElementById("equipmentFields");

categoryCards.forEach(card => {
    card.addEventListener("click", () => {
        categoryCards.forEach(item => item.classList.remove("active"));
        card.classList.add("active");
        selectedCategory = card.dataset.category;
        updateCategoryFields();
    });
});

function updateCategoryFields() {
    if (selectedCategory === "Equipment") {
        componentToolFields.classList.add("hidden");
        equipmentFields.classList.remove("hidden");
    } else {
        componentToolFields.classList.remove("hidden");
        equipmentFields.classList.add("hidden");
    }
}

function resetAssetForm() {
    const inputs = addAssetModal.querySelectorAll("input, textarea");
    inputs.forEach(input => {
        if (input.type !== "file") input.value = "";
    });
    const selects = addAssetModal.querySelectorAll("select");
    selects.forEach(select => select.selectedIndex = 0);
    selectedCategory = "Component";
    categoryCards.forEach(card => card.classList.remove("active"));
    categoryCards[0].classList.add("active");
    updateCategoryFields();
}

document.getElementById("addAssetBtn").addEventListener("click", () => {
    resetAssetForm();
    openModal(addAssetModal);
});

document.getElementById("closeAddModal").addEventListener("click", () => closeModal(addAssetModal));
document.getElementById("cancelAddModal").addEventListener("click", () => closeModal(addAssetModal));

document.getElementById("saveAsset").addEventListener("click", function () {
    const assetName = document.getElementById("assetName").value.trim();
    const make = document.getElementById("assetMake").value.trim();
    const specification = document.getElementById("assetSpecification").value.trim();
    const total = parseInt(document.getElementById("assetTotal").value);
    const available = parseInt(document.getElementById("assetAvailable").value) || 0;
    const lab = document.getElementById("assetLab").value;
    const remarks = document.getElementById("assetRemarks").value.trim();

    if (assetName === "") {
        showToast("Asset Name is required.", "error");
        return;
    }
    if (isNaN(total)) {
        showToast("Please enter Total Count.", "error");
        return;
    }

    // For Equipment, available should always be equal to total
    const finalAvailable = selectedCategory === "Equipment" ? total : available;
    const issued = total - finalAvailable;

    // Determine status
    let status;
    if (selectedCategory === "Equipment") {
        // Equipment can be Available or Maintenance based on remarks
        if (remarks.toLowerCase().includes("maintenance") || remarks.toLowerCase().includes("repair")) {
            status = "Maintenance";
        } else {
            status = "Available";
        }
    } else if (finalAvailable === 0) {
        status = "Out of Stock";
    } else if (finalAvailable <= 5) {
        status = "Low Stock";
    } else {
        status = "Available";
    }

    const newAsset = {
        id: inventory.length + 1,
        assetName,
        category: selectedCategory,
        make,
        specification,
        total,
        available: finalAvailable,
        issued,
        status,
        lab,
        cost: document.getElementById("assetCost").value || "",
        cupboard: document.getElementById("cupboard").value || "",
        shelf1: document.getElementById("shelf1").value || "",
        count1: document.getElementById("count1").value || "",
        shelf2: document.getElementById("shelf2").value || "",
        count2: document.getElementById("count2").value || "",
        returnTimeline: document.getElementById("returnTimeline").value || "",
        purpose: document.getElementById("assetPurpose").value || "",
        comments: document.getElementById("assetComments").value || "",
        remarks: remarks
    };

    inventory.push(newAsset);
    filteredInventory = [...inventory];
    currentPage = Math.ceil(filteredInventory.length / rowsPerPage);
    renderTable(filteredInventory);
    updateStats();
    resetAssetForm();
    closeModal(addAssetModal);
    showToast(`"${assetName}" added successfully!`);
});

/* =====================================================
   VIEW ASSET MODAL
===================================================== */

function openViewAssetModal(asset) {
    populateAssetDetails(asset);
    openModal(viewAssetModal);
}

document.getElementById("closeViewModal").addEventListener("click", () => closeModal(viewAssetModal));
document.getElementById("closeViewFooter").addEventListener("click", () => closeModal(viewAssetModal));

function populateAssetDetails(asset) {
    document.getElementById("viewId").textContent = asset.id;
    document.getElementById("viewAssetName").textContent = asset.assetName;
    document.getElementById("viewCategory").textContent = asset.category;
    document.getElementById("viewMake").textContent = asset.make;
    document.getElementById("viewSpecification").textContent = asset.specification;
    document.getElementById("viewCost").textContent = asset.cost || "-";
    document.getElementById("viewTotal").textContent = asset.total;
    document.getElementById("viewAvailable").textContent = asset.available ?? "-";
    document.getElementById("viewIssued").textContent = asset.issued ?? "-";
    document.getElementById("viewComponentType").textContent = asset.category;
    document.getElementById("viewReturnTimeline").textContent = asset.returnTimeline || "-";
    document.getElementById("viewLab").textContent = asset.lab;
    document.getElementById("viewCupboard").textContent = asset.cupboard || "-";
    document.getElementById("viewShelf1").textContent = asset.shelf1 || "-";
    document.getElementById("viewCount1").textContent = asset.count1 || "-";
    document.getElementById("viewShelf2").textContent = asset.shelf2 || "-";
    document.getElementById("viewCount2").textContent = asset.count2 || "-";
    document.getElementById("viewPurpose").textContent = asset.purpose || "-";
    document.getElementById("viewComments").textContent = asset.comments || "-";
    document.getElementById("viewRemarks").textContent = asset.remarks || "-";

    const storageSection = document.getElementById("storageSection");
    const additionalSection = document.getElementById("additionalSection");
    const equipmentRemarksSection = document.getElementById("equipmentRemarksSection");

    // Find return timeline detail item
    const detailItems = document.querySelectorAll('.detail-item');
    let returnTimelineDetail = null;
    detailItems.forEach(item => {
        const label = item.querySelector('label');
        if (label && label.textContent.trim() === 'Return Timeline') {
            returnTimelineDetail = item;
        }
    });

    if (asset.category === "Equipment") {
        storageSection.classList.add("hidden");
        additionalSection.classList.add("hidden");
        equipmentRemarksSection.classList.remove("hidden");
        // Hide Return Timeline for Equipment in view modal
        if (returnTimelineDetail) {
            returnTimelineDetail.classList.add("hidden");
        }
    } else {
        storageSection.classList.remove("hidden");
        additionalSection.classList.remove("hidden");
        equipmentRemarksSection.classList.add("hidden");
        // Show Return Timeline for Components and Tools
        if (returnTimelineDetail) {
            returnTimelineDetail.classList.remove("hidden");
        }
    }

    updateCategoryBadge(asset.category);
    updateStatusBadge(asset.status);
}

function updateCategoryBadge(category) {
    const el = document.getElementById("viewCategory");
    el.textContent = category;
    el.className = "category-badge";
    el.classList.add(`category-${category.toLowerCase()}`);
}

function updateStatusBadge(status) {
    const el = document.getElementById("viewStatus");
    el.textContent = status;
    el.className = "status-badge";
    const map = {
        "Available": "status-available",
        "Low Stock": "status-low",
        "Out of Stock": "status-out",
        "Maintenance": "status-maintenance"
    };
    if (map[status]) el.classList.add(map[status]);
}

/* =====================================================
   EDIT ASSET MODAL
===================================================== */

function openEditAssetModal(asset) {
    editingAssetId = asset.id;
    populateEditDrawer(asset);
    openModal(editAssetModal);
}

document.getElementById("closeEditModal").addEventListener("click", () => closeModal(editAssetModal));
document.getElementById("cancelEdit").addEventListener("click", () => closeModal(editAssetModal));

function populateEditDrawer(asset) {
    document.getElementById("editAssetId").value = asset.id;
    document.getElementById("editCategory").value = asset.category;
    document.getElementById("editAssetName").value = asset.assetName;
    document.getElementById("editMake").value = asset.make;
    document.getElementById("editSpecification").value = asset.specification;
    document.getElementById("editCost").value = asset.cost || "";
    document.getElementById("editTotal").value = asset.total;
    document.getElementById("editComponentType").value = asset.category;
    document.getElementById("editReturnTimeline").value = asset.returnTimeline || "Daily";
    document.getElementById("editLab").value = asset.lab;
    document.getElementById("editCupboard").value = asset.cupboard || "";
    document.getElementById("editShelf1").value = asset.shelf1 || "";
    document.getElementById("editCount1").value = asset.count1 || "";
    document.getElementById("editShelf2").value = asset.shelf2 || "";
    document.getElementById("editCount2").value = asset.count2 || "";
    document.getElementById("editPurpose").value = asset.purpose || "";
    document.getElementById("editComments").value = asset.comments || "";
    document.getElementById("editRemarks").value = asset.remarks || "";

    const storageSection = document.getElementById("editStorageSection");
    const additionalSection = document.getElementById("editAdditionalSection");
    const remarksSection = document.getElementById("editRemarksSection");
    const returnTimelineGroup = document.getElementById("returnTimelineGroup");

    if (asset.category === "Equipment") {
        storageSection.classList.add("hidden");
        additionalSection.classList.add("hidden");
        remarksSection.classList.remove("hidden");
        // Hide Return Timeline for Equipment
        if (returnTimelineGroup) {
            returnTimelineGroup.style.display = "none";
        }
    } else {
        storageSection.classList.remove("hidden");
        additionalSection.classList.remove("hidden");
        remarksSection.classList.add("hidden");
        // Show Return Timeline for Components and Tools
        if (returnTimelineGroup) {
            returnTimelineGroup.style.display = "block";
        }
    }
}

document.getElementById("saveChanges").addEventListener("click", function () {
    const asset = inventory.find(item => item.id === editingAssetId);
    if (!asset) {
        showToast("Asset not found.", "error");
        return;
    }

    asset.category = document.getElementById("editCategory").value;
    asset.assetName = document.getElementById("editAssetName").value;
    asset.make = document.getElementById("editMake").value;
    asset.specification = document.getElementById("editSpecification").value;
    asset.cost = document.getElementById("editCost").value;
    asset.total = Number(document.getElementById("editTotal").value);
    asset.remarks = document.getElementById("editRemarks").value;

    // Handle Equipment separately
    if (asset.category === "Equipment") {
        // Equipment always has available = total and issued = 0
        asset.available = asset.total;
        asset.issued = 0;

        // Equipment can be Available or Maintenance based on remarks
        if (asset.remarks.toLowerCase().includes("maintenance") || asset.remarks.toLowerCase().includes("repair")) {
            asset.status = "Maintenance";
        } else {
            asset.status = "Available";
        }
    } else {
        asset.available = Math.min(asset.available, asset.total);
        asset.issued = asset.total - asset.available;

        // Recalculate status for Components and Tools
        if (asset.available === 0) {
            asset.status = "Out of Stock";
        } else if (asset.available <= 5) {
            asset.status = "Low Stock";
        } else {
            asset.status = "Available";
        }
    }

    asset.returnTimeline = document.getElementById("editReturnTimeline").value;
    asset.lab = document.getElementById("editLab").value;
    asset.cupboard = document.getElementById("editCupboard").value;
    asset.shelf1 = document.getElementById("editShelf1").value;
    asset.count1 = document.getElementById("editCount1").value;
    asset.shelf2 = document.getElementById("editShelf2").value;
    asset.count2 = document.getElementById("editCount2").value;
    asset.purpose = document.getElementById("editPurpose").value;
    asset.comments = document.getElementById("editComments").value;

    filteredInventory = [...inventory];
    renderTable(filteredInventory);
    updateStats();
    closeModal(editAssetModal);
    showToast(`"${asset.assetName}" updated successfully!`);
});

/* =====================================================
   DELETE ASSET - FIXED
===================================================== */

document.getElementById("deleteAssetBtn").addEventListener("click", function (e) {
    e.stopPropagation();
    const asset = inventory.find(item => item.id === editingAssetId);
    if (asset) {
        document.getElementById("deleteAssetName").textContent = asset.assetName;
        // Close edit modal and open delete modal
        closeModal(editAssetModal);
        openModal(deleteAssetModal);
    } else {
        showToast("No asset selected to delete.", "error");
    }
});

document.getElementById("closeDeleteModal").addEventListener("click", () => closeModal(deleteAssetModal));
document.getElementById("cancelDelete").addEventListener("click", () => closeModal(deleteAssetModal));

document.getElementById("confirmDelete").addEventListener("click", function () {
    const index = inventory.findIndex(item => item.id === editingAssetId);
    if (index === -1) {
        showToast("Asset not found.", "error");
        closeModal(deleteAssetModal);
        return;
    }

    const assetName = inventory[index].assetName;
    inventory.splice(index, 1);
    inventory.forEach((asset, i) => { asset.id = i + 1; });

    filteredInventory = [...inventory];
    const totalPages = Math.ceil(filteredInventory.length / rowsPerPage);
    if (currentPage > totalPages) currentPage = totalPages || 1;

    renderTable(filteredInventory);
    updateStats();
    closeModal(deleteAssetModal);
    editingAssetId = null;
    showToast(`"${assetName}" has been deleted.`);
});

/* =====================================================
   VIEW / EDIT BUTTON EVENTS
===================================================== */

function attachViewButtonEvents() {
    document.querySelectorAll(".view-btn").forEach(button => {
        button.removeEventListener("click", handleViewClick);
        button.addEventListener("click", handleViewClick);
    });
}

function handleViewClick() {
    const assetId = Number(this.dataset.id);
    const asset = inventory.find(item => item.id === assetId);
    if (asset) openViewAssetModal(asset);
}

function attachEditButtonEvents() {
    document.querySelectorAll(".edit-btn").forEach(button => {
        button.removeEventListener("click", handleEditClick);
        button.addEventListener("click", handleEditClick);
    });
}

function handleEditClick() {
    const row = this.closest("tr");
    const viewBtn = row.querySelector(".view-btn");
    const assetId = Number(viewBtn.dataset.id);
    const asset = inventory.find(item => item.id === assetId);
    if (asset) openEditAssetModal(asset);
}

/* =====================================================
   BULK UPLOAD MODAL
===================================================== */

document.getElementById("openBulkUpload").addEventListener("click", () => openModal(bulkUploadModal));
document.getElementById("closeModal").addEventListener("click", () => closeModal(bulkUploadModal));
document.getElementById("cancelUpload").addEventListener("click", () => closeModal(bulkUploadModal));

// Make sure bulk upload uses the same closeAllModals
document.getElementById("bulkUploadModal").addEventListener("click", function (e) {
    if (e.target === this) closeModal(this);
});

document.getElementById("downloadTemplate").addEventListener("click", function () {
    showToast("Template download will be integrated with the backend.", "info");
});

document.getElementById("excelFile").addEventListener("change", function () {
    if (this.files.length > 0) {
        console.log("Selected File:", this.files[0].name);
    }
});

document.getElementById("importAssets").addEventListener("click", function () {
    const fileInput = document.getElementById("excelFile");
    if (fileInput.files.length === 0) {
        showToast("Please choose an Excel file.", "warning");
        return;
    }
    showToast(`Import started for "${fileInput.files[0].name}"`, "success");
    fileInput.value = "";
    closeModal(bulkUploadModal);
});

/* =====================================================
   EXPORT MODAL
===================================================== */

const exportModal = document.getElementById("exportModal");
let selectedExport = "all";

// Get DOM elements
const closeExportModal = document.getElementById("closeExportModal");
const cancelExport = document.getElementById("cancelExport");
const confirmExportBtn = document.getElementById("confirmExport");
const exportCards = document.querySelectorAll(".export-card");

// Update export counts
function updateExportCounts() {
    const allCount = inventory.length;
    const componentCount = inventory.filter(i => i.category === "Component").length;
    const toolCount = inventory.filter(i => i.category === "Tool").length;
    const equipmentCount = inventory.filter(i => i.category === "Equipment").length;

    document.getElementById("exportAllCount").textContent = allCount;
    document.getElementById("exportComponentCount").textContent = componentCount;
    document.getElementById("exportToolCount").textContent = toolCount;
    document.getElementById("exportEquipmentCount").textContent = equipmentCount;
}

// Open export modal
function openExportModal() {
    selectedExport = "all";
    exportCards.forEach(card => card.classList.remove("selected"));
    document.querySelector('.export-card[data-export="all"]').classList.add("selected");
    updateExportCounts();
    openModal(exportModal);
}

// Close export modal
function closeExportModalFn() {
    closeModal(exportModal);
}

// Handle export card selection
exportCards.forEach(card => {
    card.addEventListener("click", function () {
        exportCards.forEach(c => c.classList.remove("selected"));
        this.classList.add("selected");
        selectedExport = this.dataset.export;
    });
});

// Close events
closeExportModal.addEventListener("click", closeExportModalFn);
cancelExport.addEventListener("click", closeExportModalFn);

// Confirm export
confirmExportBtn.addEventListener("click", function () {
    let dataToExport = [];
    let fileName = "";

    if (selectedExport === "all") {
        dataToExport = [...inventory];
        fileName = "All_Assets";
    } else {
        dataToExport = inventory.filter(i => i.category === selectedExport);
        fileName = selectedExport + "s";
    }

    if (dataToExport.length === 0) {
        showToast("No assets found to export.", "warning");
        return;
    }

    // Export as CSV
    exportToCSV(dataToExport, fileName);
    closeModal(exportModal);
    showToast(`Exported ${dataToExport.length} assets successfully!`);
});

// CSV Export function
function exportToCSV(data, fileName) {
    // Define headers
    const headers = [
        "Sl No.",
        "Asset Name",
        "Category",
        "Make",
        "Specification",
        "Cost (₹)",
        "Total Count",
        "Available",
        "Issued",
        "Status",
        "Lab",
        "Cupboard",
        "Shelf 1",
        "Count 1",
        "Shelf 2",
        "Count 2",
        "Return Timeline",
        "Purpose",
        "Comments",
        "Remarks"
    ];

    // Create CSV rows
    const rows = data.map(asset => [
        asset.id,
        asset.assetName,
        asset.category,
        asset.make,
        asset.specification,
        asset.cost || "",
        asset.total,
        asset.category === "Equipment" ? "-" : asset.available,
        asset.category === "Equipment" ? "-" : asset.issued,
        asset.status,
        asset.lab,
        asset.cupboard || "",
        asset.shelf1 || "",
        asset.count1 || "",
        asset.shelf2 || "",
        asset.count2 || "",
        asset.returnTimeline || "",
        asset.purpose || "",
        asset.comments || "",
        asset.remarks || ""
    ]);

    // Combine headers and rows
    const csvContent = [
        headers.join(","),
        ...rows.map(row => row.join(","))
    ].join("\n");

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${fileName}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

// Attach export button event
document.querySelector('.toolbar .secondary-btn:has(.fa-download)').addEventListener("click", openExportModal);

// Also handle the Export button by its icon
document.querySelectorAll('.toolbar .secondary-btn').forEach(btn => {
    if (btn.querySelector('.fa-download')) {
        btn.addEventListener("click", openExportModal);
    }
});

/* =====================================================
   PREVENT MODAL CLOSE ON CLICK INSIDE
===================================================== */

document.querySelectorAll(".modal-content").forEach(content => {
    content.addEventListener("click", function (e) {
        e.stopPropagation();
    });
});

/* =====================================================
   INITIALIZATION
===================================================== */

filteredInventory = [...inventory];
currentPage = 1;
renderTable(filteredInventory);
updateStats();