// js/equipment-bookings.js

window.statusIcons = {
  'available': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`,
  'in-use': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15.91 11.672a.375.375 0 010 .656l-5.603 3.113a.375.375 0 01-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112z" /></svg>`,
  'maintenance': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.492-3.053 5.25 5.25-3.053 2.492-4.689-4.689zM5.72 5.72a3.75 3.75 0 015.304 0l3.054 3.054-2.493 3.053-5.25-5.25 3.053-2.493-3.054-3.054a3.75 3.75 0 010-5.304z" /></svg>`,
  'scheduled': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>`
};

// ═══════════════════════════════════════════════════════════
// MAINTENANCE MODAL — global helpers (called via inline HTML)
// ═══════════════════════════════════════════════════════════

// ─── Maintenance Modal: populate Equipment dropdown from labDB ────────────────
// Called once on DOMContentLoaded and again after refreshUI if needed
function populateMaintenanceEquipmentDropdown() {
  const sel = document.getElementById('maint-equipment');
  if (!sel || !window.labDB) return;
  // Preserve the placeholder option
  sel.innerHTML = '<option value="">— Select Equipment —</option>';
  window.labDB.equipmentCategories.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat.id;
    opt.textContent = cat.name;
    sel.appendChild(opt);
  });
}

/** Populate the unit dropdown based on selected category from labDB */
function updateEquipmentUnits() {
  const equipSel = document.getElementById('maint-equipment');
  const unitSel  = document.getElementById('maint-unit');
  const catId    = equipSel.value;

  unitSel.innerHTML = '';

  if (!catId || !window.labDB) {
    unitSel.innerHTML = '<option value="">— Select Equipment first —</option>';
    unitSel.disabled  = true;
    return;
  }

  const units = window.labDB.machines.filter(m => m.categoryId === catId);
  if (units.length === 0) {
    unitSel.innerHTML = '<option value="">— No units found —</option>';
    unitSel.disabled  = true;
    return;
  }

  unitSel.innerHTML = '<option value="">— Select Unit —</option>';
  units.forEach(m => {
    const opt = document.createElement('option');
    opt.value       = m.id;
    opt.textContent = `${m.id} – ${m.type}`;
    unitSel.appendChild(opt);
  });
  unitSel.disabled = false;
}

/** Validate, submit, and live-sync the maintenance form */
function submitMaintenance() {
  const catId     = document.getElementById('maint-equipment').value;
  const unit      = document.getElementById('maint-unit').value;
  const startDate = document.getElementById('maint-start-date').value;
  const startTime = document.getElementById('maint-start-time').value;
  const endDate   = document.getElementById('maint-end-date').value;
  const endTime   = document.getElementById('maint-end-time').value;
  const purpose   = document.getElementById('maint-purpose').value;

  if (!catId)     { alert('Please select an Equipment category.'); return; }
  if (!unit)      { alert('Please select an Equipment Unit.'); return; }
  if (!startDate || !startTime) { alert('Please enter a Start Date and Time.'); return; }
  if (!endDate || !endTime)     { alert('Please enter an End Date and Time.'); return; }

  // Parse dates (YYYY-MM-DD + HH:MM AM/PM)
  function parseDateTime(dateStr, timeStr) {
    const parts = dateStr.split('-');
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    const tm = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (tm) {
      let h = parseInt(tm[1]);
      const m = parseInt(tm[2]);
      const ampm = tm[3].toUpperCase();
      if (ampm === 'PM' && h !== 12) h += 12;
      if (ampm === 'AM' && h === 12) h = 0;
      d.setHours(h, m, 0, 0);
    }
    return d;
  }

  const startObj = parseDateTime(startDate, startTime);
  const endObj   = parseDateTime(endDate, endTime);
  if (isNaN(startObj.getTime()) || isNaN(endObj.getTime())) { alert('Invalid date/time format.'); return; }
  if (endObj <= startObj) { alert('End Time must be after Start Time.'); return; }

  // Push to labDB and trigger full page refresh
  if (window.labDB) {
    window.labDB.addMaintenance({ machineId: unit, startTime: startObj, endTime: endObj, purpose });
  }

  document.getElementById('new-booking-modal').classList.remove('is-open');

  // Reset form
  document.getElementById('maint-equipment').value = '';
  document.getElementById('maint-unit').innerHTML = '<option value="">— Select Equipment first —</option>';
  document.getElementById('maint-unit').disabled = true;
  document.getElementById('maint-start-date').value = '';
  document.getElementById('maint-start-time').value = '';
  document.getElementById('maint-end-date').value = '';
  document.getElementById('maint-end-time').value = '';
  document.getElementById('maint-purpose').value = '';

  // Live-sync: refresh all UI sections from updated labDB
  if (typeof window.refreshUI === 'function') window.refreshUI();
}

document.addEventListener('DOMContentLoaded', () => {
  const sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
  const calendarContainer = document.querySelector('.calendar-container');
  const sidebarToggleIcon = document.getElementById('sidebar-toggle-icon');

  if (sidebarToggleBtn && calendarContainer) {
    sidebarToggleBtn.addEventListener('click', () => {
      calendarContainer.classList.toggle('is-collapsed');
      if (calendarContainer.classList.contains('is-collapsed')) {
        sidebarToggleIcon.classList.remove('fa-chevron-left');
        sidebarToggleIcon.classList.add('fa-chevron-right');
      } else {
        sidebarToggleIcon.classList.remove('fa-chevron-right');
        sidebarToggleIcon.classList.add('fa-chevron-left');
      }
    });
  }

  // ═══════════════════════════════════════════════════════════
  // CONSTANTS
  // ═══════════════════════════════════════════════════════════

  // Total machines is always derived from labDB
  const CALENDAR_START_H  = 8;   // 08:00
  const CALENDAR_END_H    = 18;  // 18:00
  const MINS_PER_HOUR     = 60;
  const PX_PER_HOUR       = 64;  // must match CSS .calendar-time-slot { height: 64px }
  const PX_PER_MIN        = PX_PER_HOUR / MINS_PER_HOUR;

  // ═══════════════════════════════════════════════════════════
  // WEEK COMPUTATION — anchor to the Monday of the current week
  // The reference design shows Mon 18 → Sun 24 (July 2026)
  // ═══════════════════════════════════════════════════════════

  function getWeekStart(referenceDate) {
    const d = new Date(referenceDate);
    // Set to Monday (ISO week start)
    const day = d.getDay(); // 0=Sun, 1=Mon…
    const diff = (day === 0) ? -6 : 1 - day;
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
  }

  // Use today; JS can render relative to whichever week today falls in.
  const today         = new Date();
  const weekStart     = getWeekStart(today);

  // Build an array of 7 Date objects: Mon…Sun
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    return d;
  });

  // ═══════════════════════════════════════════════════════════
  // MOCK BOOKING DATA — matches the reference image dates
  // Dates: July 18 (Mon) – July 24 (Sun) 2026
  // ═══════════════════════════════════════════════════════════

  function makeDate(weekDayIndex, hour, minute = 0) {
    const d = new Date(weekDays[weekDayIndex]);
    d.setHours(hour, minute, 0, 0);
    return d;
  }

  // ─── Live reference to labDB bookings (always reads current state) ──────────
  // Using a getter so it always reflects post-mutation state
  function getMockBookings() {
    return window.labDB ? window.labDB.bookings : [];
  }
  // Proxy: existing code that references mockBookings directly reads via getter
  let mockBookings = window.labDB ? window.labDB.bookings : [];

  const _legacyBookingsStart = [
    // ── Monday (index 0) ─────────────────────────────────────
    {
      id: 'BK001',
      title: 'Solar Car Team',
      detail: 'Project Work',
      machineId: '3DP-01',
      type: 'project',
      startTime: makeDate(0, 9, 0),
      endTime:   makeDate(0, 11, 0),
      status: 'confirmed'
    },
    // 3-unit concurrent example: 3DP-01, 3DP-02, 3DP-03 all at 09:00–11:00
    {
      id: 'BK001B',
      title: 'Robotics Team',
      detail: 'Batch Print',
      machineId: '3DP-02',
      type: 'prototype',
      startTime: makeDate(0, 9, 0),
      endTime:   makeDate(0, 11, 0),
      status: 'confirmed'
    },
    {
      id: 'BK001C',
      title: 'Aero Team',
      detail: 'Wing Frames',
      machineId: '3DP-03',
      type: 'club',
      startTime: makeDate(0, 9, 0),
      endTime:   makeDate(0, 11, 0),
      status: 'pending'
    },
    {
      id: 'BK002',
      title: 'Mech Design Club',
      detail: 'Chassis Parts',
      machineId: 'LCR-01',
      type: 'project',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK003',
      title: 'Aero Team',
      detail: 'Pending Approval',
      machineId: '3DP-02',
      type: 'pending',
      startTime: makeDate(0, 16, 0),
      endTime:   makeDate(0, 17, 30),
      status: 'pending'
    },
    // 5-unit concurrent example: 3DP-01..05 all at 13:00–15:00
    {
      id: 'BK001D',
      title: 'Solar Car Team',
      detail: 'Shell Prints',
      machineId: '3DP-01',
      type: 'project',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK001E',
      title: 'Electronics Club',
      detail: 'Enclosures',
      machineId: '3DP-02',
      type: 'club',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK001F',
      title: 'Robotics Team',
      detail: 'Jig Fixtures',
      machineId: '3DP-03',
      type: 'prototype',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK001G',
      title: 'Mech Design Club',
      detail: 'Gear Models',
      machineId: '3DP-04',
      type: 'project',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK001H',
      title: 'Product Design',
      detail: 'Prototype Cases',
      machineId: '3DP-05',
      type: 'testing',
      startTime: makeDate(0, 13, 0),
      endTime:   makeDate(0, 15, 0),
      status: 'pending'
    },

    // ── Tuesday (index 1) ────────────────────────────────────
    {
      id: 'BK004',
      title: 'Robotics Team',
      detail: 'Prototype Build',
      machineId: 'CNC-01',
      type: 'prototype',
      startTime: makeDate(1, 8, 0),
      endTime:   makeDate(1, 10, 0),
      status: 'confirmed'
    },
    {
      id: 'BK005',
      title: 'Aero Team',
      detail: 'Model Printing',
      machineId: '3DP-03',
      type: 'maintenance',
      startTime: makeDate(1, 11, 0),
      endTime:   makeDate(1, 13, 0),
      status: 'confirmed'
    },
    {
      id: 'BK006',
      title: 'Mech Design Club',
      detail: 'Component Test',
      machineId: 'LCR-01',
      type: 'testing',
      startTime: makeDate(1, 13, 0),
      endTime:   makeDate(1, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK007',
      title: 'LCR-02',
      detail: 'Product Design Team',
      machineId: 'LCR-02',
      type: 'pending',
      startTime: makeDate(1, 15, 0),
      endTime:   makeDate(1, 16, 30),
      status: 'pending'
    },
    {
      id: 'BK008',
      title: 'Electronics Club',
      detail: 'Enclosure Parts',
      machineId: '3DP-03',
      type: 'club',
      startTime: makeDate(1, 16, 0),
      endTime:   makeDate(1, 17, 30),
      status: 'confirmed'
    },

    // ── Wednesday (index 2) ──────────────────────────────────
    {
      id: 'BK009',
      title: 'Solar Car Team',
      detail: 'Batch Print',
      machineId: '3DP-01',
      type: 'project',
      startTime: makeDate(2, 9, 0),
      endTime:   makeDate(2, 12, 0),
      status: 'confirmed'
    },
    {
      id: 'BK010',
      title: 'MLG-01',
      detail: 'Electronics Club',
      machineId: 'MLG-01',
      type: 'club',
      startTime: makeDate(2, 13, 0),
      endTime:   makeDate(2, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK011',
      title: 'CNC-02',
      detail: 'Calibration',
      machineId: 'CNC-02',
      type: 'maintenance',
      startTime: makeDate(2, 16, 0),
      endTime:   makeDate(2, 18, 0),
      status: 'confirmed'
    },
    {
      id: 'BK012',
      title: 'Robotics Team',
      detail: 'Jig Printing',
      machineId: 'MLG-01',
      type: 'project',
      startTime: makeDate(2, 13, 0),
      endTime:   makeDate(2, 15, 0),
      status: 'confirmed'
    },

    // ── Thursday (index 3) ───────────────────────────────────
    {
      id: 'BK013',
      title: 'LCR-01',
      detail: 'Mech Design Club',
      machineId: 'LCR-01',
      type: 'project',
      startTime: makeDate(3, 8, 0),
      endTime:   makeDate(3, 10, 0),
      status: 'confirmed'
    },
    {
      id: 'BK014',
      title: 'Aero Team',
      detail: 'Parts Printing',
      machineId: '3DP-02',
      type: 'pending',
      startTime: makeDate(3, 10, 30),
      endTime:   makeDate(3, 12, 0),
      status: 'pending'
    },
    {
      id: 'BK015',
      title: 'Robotics Team',
      detail: 'Jig Printing',
      machineId: 'MLG-01',
      type: 'project',
      startTime: makeDate(3, 13, 0),
      endTime:   makeDate(3, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK016',
      title: 'Mech Design Club',
      detail: 'Functional Parts',
      machineId: 'CNC-01',
      type: 'prototype',
      startTime: makeDate(3, 14, 0),
      endTime:   makeDate(3, 16, 0),
      status: 'confirmed'
    },

    // ── Friday (index 4) ─────────────────────────────────────
    {
      id: 'BK017',
      title: 'All 3D Printers',
      detail: 'Preventive Maintenance',
      machineId: '3DP-ALL',
      type: 'maintenance',
      startTime: makeDate(4, 8, 0),
      endTime:   makeDate(4, 12, 0),
      status: 'confirmed'
    },
    {
      id: 'BK018',
      title: 'LCR-02',
      detail: 'Product Design Team',
      machineId: 'LCR-02',
      type: 'pending',
      startTime: makeDate(4, 9, 0),
      endTime:   makeDate(4, 11, 0),
      status: 'pending'
    },
    {
      id: 'BK019',
      title: '3DP-01',
      detail: 'Solar Car Team',
      machineId: '3DP-01',
      type: 'project',
      startTime: makeDate(4, 13, 0),
      endTime:   makeDate(4, 15, 0),
      status: 'confirmed'
    },
    {
      id: 'BK020',
      title: 'MLG-01',
      detail: 'Electronics Club',
      machineId: 'MLG-01',
      type: 'club',
      startTime: makeDate(4, 16, 0),
      endTime:   makeDate(4, 18, 0),
      status: 'confirmed'
    },

    // ── Saturday (index 5) ───────────────────────────────────
    {
      id: 'BK021',
      title: 'LCR-02',
      detail: 'Product Design Team',
      machineId: 'LCR-02',
      type: 'pending',
      startTime: makeDate(5, 9, 0),
      endTime:   makeDate(5, 11, 0),
      status: 'pending'
    },
    {
      id: 'BK022',
      title: 'CNC-01',
      detail: 'Mounts & Cases',
      machineId: 'CNC-01',
      type: 'project',
      startTime: makeDate(5, 13, 0),
      endTime:   makeDate(5, 15, 0),
      status: 'confirmed'
    },

    // ── Sunday (index 6) ─────────────────────────────────────
    {
      id: 'BK023',
      title: 'CNC-02',
      detail: 'Deep Cleaning & Calibration',
      machineId: 'CNC-02',
      type: 'maintenance',
      startTime: makeDate(6, 10, 0),
      endTime:   makeDate(6, 16, 0),
      status: 'confirmed'
    },
    {
      id: 'BK024',
      title: 'MLG-01',
      detail: 'Electronics Club',
      machineId: 'MLG-01',
      type: 'club',
      startTime: makeDate(6, 16, 0),
      endTime:   makeDate(6, 18, 0),
      status: 'confirmed'
    }
  ];
  // Legacy mock list is superseded; point mockBookings at labDB
  // (the array above is intentionally empty — data comes from db.js)
  mockBookings = window.labDB ? window.labDB.bookings : _legacyBookingsStart;
  window.equipmentBookingsData = mockBookings;

  // ═══════════════════════════════════════════════════════════
  // OVERVIEW CARD STATS
  // ═══════════════════════════════════════════════════════════

  function calculateOverviewStats() {
    // Always delegate to labDB for authoritative stats
    if (window.labDB) return window.labDB.computeStats();
    // Fallback (no db loaded)
    return { totalMachines: 0, inUse: 0, currentlyFree: 0, inMaintenance: 0, scheduledMaintenance: 0, pendingApproval: 0 };
  }

  function updateOverviewCards(stats) {
    const map = {
      '.stat-card--machines  .stat-card__value': stats.totalMachines,
      '.stat-card--in-use    .stat-card__value': stats.inUse,
      '.stat-card--available .stat-card__value': stats.currentlyFree,
      '.stat-card--maintenance .stat-card__value': stats.inMaintenance,
      '.stat-card--types     .stat-card__value': stats.scheduledMaintenance,
      '.stat-card--cancelled .stat-card__value': stats.pendingApproval,
    };
    for (const [sel, val] of Object.entries(map)) {
      const el = document.querySelector(sel);
      if (el) el.textContent = val;
    }
    // Also sync the sidebar alerts panel if it has been initialized
    if (typeof window._syncAlertsAfterUpdate === 'function') {
      window._syncAlertsAfterUpdate(stats);
    }
  }

  const currentStats = calculateOverviewStats();
  updateOverviewCards(currentStats);

  // \u2500\u2500\u2500 Central UI Orchestrator \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  // window.refreshUI() \u2014 call this after any labDB mutation to sync ALL UI.
  // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
  window.refreshUI = function () {
    // Keep mockBookings reference in sync with labDB
    mockBookings = window.labDB ? window.labDB.bookings : [];

    // 1. Stats cards
    const stats = calculateOverviewStats();
    updateOverviewCards(stats);

    // 2. Calendar view (re-render whichever view is active)
    if (typeof currentView !== 'undefined') {
      if (currentView === 'day') {
        if (typeof renderDay === 'function') renderDay(currentDayAnchor);
      } else {
        if (typeof renderWeek === 'function') renderWeek(currentWeekStart);
      }
    }

    // 3. Explorer modal (if open, rebuild sidebar + machine list + filter counts)
    const explorerModalEl = document.getElementById('explorer-modal');
    if (explorerModalEl && explorerModalEl.classList.contains('is-open')) {
      if (typeof renderExplorerSidebar === 'function') renderExplorerSidebar();
      if (typeof updateFilterCounts === 'function') updateFilterCounts();
      if (typeof renderExplorerMachineList === 'function') {
        renderExplorerMachineList(undefined, undefined);
      }
    }

    // 4. Approval list modal (if open, re-render rows)
    const approvalListEl = document.getElementById('approval-list-modal');
    if (approvalListEl && approvalListEl.classList.contains('is-open')) {
      if (typeof renderApprovalList === 'function') renderApprovalList();
    }

    // 5. Mini-calendar in details modal (if open)
    const detailsModalEl = document.getElementById('details-modal');
    if (detailsModalEl && detailsModalEl.classList.contains('is-open')) {
      const name = detailsModalEl.querySelector('.details-sidebar__name');
      if (name && typeof renderDetailsMiniCalendar === 'function') {
        renderDetailsMiniCalendar(name.textContent);
      }
    }

    // 6. Maintenance dropdown (regenerate in case machines changed)
    if (typeof populateMaintenanceEquipmentDropdown === 'function') {
      populateMaintenanceEquipmentDropdown();
    }
  };

  // ═══════════════════════════════════════════════════════════
  // TOOLBAR — date range label
  // ═══════════════════════════════════════════════════════════

    let currentWeekStart = getWeekStart(today);
  let currentView = 'week';            // 'day' | 'week'
  let currentDayAnchor = new Date(today); // for day view navigation

  /** Format a Date as HH:MM */
  function formatTimeLocal(date) {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  function renderWeek(anchorMonday) {
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(anchorMonday);
      d.setDate(anchorMonday.getDate() + i);
      return d;
    });

    const monthNames  = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const titleEl = document.querySelector('.calendar-toolbar__title');
    if (titleEl) {
      const sDay = days[0].getDate(), eDay = days[6].getDate();
      const sMonth = monthNames[days[0].getMonth()];
      const eMonth = monthNames[days[6].getMonth()];
      const year = days[6].getFullYear();
      titleEl.textContent = sMonth === eMonth
        ? `${sMonth} ${sDay} \u2013 ${eDay}, ${year}`
        : `${sMonth} ${sDay} \u2013 ${eMonth} ${eDay}, ${year}`;
    }

    const grid = document.querySelector('.calendar-grid-week');
    if (!grid) return;
    grid.innerHTML = '';

    const DAY_NAMES   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const TODAY       = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
    const TOTAL_MINS  = (CALENDAR_END_H - CALENDAR_START_H) * MINS_PER_HOUR;
    const MIN_CAPSULE_H = 20; // minimum capsule height px when many overlaps
    const ROW_PAD_FRAC  = 0.08; // fraction of row height used for top/bottom padding

    // ── Sticky time-axis header ───────────────────────────────────────
    const hdr = document.createElement('div');
    hdr.className = 'cal-time-header-row';
    const corner = document.createElement('div');
    corner.className = 'cal-corner-cell';
    hdr.appendChild(corner);
    for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
      const tick = document.createElement('div');
      tick.className = 'cal-time-tick';
      tick.textContent = `${String(h).padStart(2,'0')}:00`;
      hdr.appendChild(tick);
    }
    grid.appendChild(hdr);

    // ── Scrollable body ───────────────────────────────────────────────
    const wrap = document.createElement('div');
    wrap.className = 'cal-body-rows-wrap';

    // We collect per-row metadata to do a second-pass layout after paint
    const rowMeta = [];

    days.forEach(day => {
      const isToday  = day.getTime() === TODAY.getTime();
      const dayStart = new Date(day); dayStart.setHours(0, 0, 0, 0);
      const dayEnd   = new Date(day); dayEnd.setHours(23, 59, 59, 999);
      const calStart = new Date(day); calStart.setHours(CALENDAR_START_H, 0, 0, 0);
      const calEnd   = new Date(day); calEnd.setHours(CALENDAR_END_H, 0, 0, 0);

      const dateRow = document.createElement('div');
      dateRow.className = 'cal-date-row' + (isToday ? ' cal-date-row--today' : '');

      // Left label
      const lbl = document.createElement('div');
      lbl.className = 'cal-row-label';
      const nm = document.createElement('span');
      nm.className = 'cal-row-label__name';
      nm.textContent = DAY_NAMES[day.getDay()];
      const num = document.createElement('span');
      num.className = 'cal-row-label__num' + (isToday ? ' cal-row-label__num--today' : '');
      num.textContent = day.getDate();
      lbl.appendChild(nm); lbl.appendChild(num);
      dateRow.appendChild(lbl);

      // Timeline
      const tl = document.createElement('div');
      tl.className = 'cal-row-timeline';

      // Vertical hour grid lines
      for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
        const vl = document.createElement('div');
        vl.className = 'cal-vline cal-vline--hour';
        vl.style.left = `${((h - CALENDAR_START_H) / (CALENDAR_END_H - CALENDAR_START_H)) * 100}%`;
        tl.appendChild(vl);
      }

      // Gather bookings
      const dayBks = mockBookings.filter(b => b.startTime < dayEnd && b.endTime > dayStart && b.status !== 'rejected');
      const capsuleMetas = [];

      if (dayBks.length > 0) {
        const withEff = dayBks.map(b => ({
          booking: b,
          effStart: b.startTime < calStart ? calStart : b.startTime,
          effEnd:   b.endTime   > calEnd   ? calEnd   : b.endTime,
        })).filter(x => x.effEnd > x.effStart);

        const sorted = [...withEff].sort((a, b) => a.effStart - b.effStart);
        const slotEnds = [];
        const assigned = sorted.map(item => {
          let slot = slotEnds.findIndex(e => e <= item.effStart);
          if (slot === -1) { slot = slotEnds.length; slotEnds.push(item.effEnd); }
          else { slotEnds[slot] = item.effEnd; }
          return { ...item, slot };
        });
        const nSlots = slotEnds.length;

        assigned.forEach(({ booking, effStart, effEnd, slot }) => {
          const startMins = (effStart.getHours() - CALENDAR_START_H) * 60 + effStart.getMinutes();
          const durMins   = (effEnd - effStart) / 60000;
          if (durMins <= 0) return;

          const leftPct  = (startMins / TOTAL_MINS) * 100;
          const widthPct = Math.max(0.5, (durMins / TOTAL_MINS) * 100);

          let tc = booking.status === 'pending' ? 'event-pending'
                 : booking.type === 'maintenance' ? 'event-maintenance'
                 : 'event-in-use';

          const blk = document.createElement('div');
          blk.className = `event-block ${tc}`;
          // Placeholder positioning — updated in second pass
          blk.style.top    = '4px';
          blk.style.height = '24px';
          blk.style.left   = `calc(${leftPct}% + 2px)`;
          blk.style.width  = `calc(${widthPct}% - 4px)`;
          blk.dataset.bookingId = booking.id;

          blk.addEventListener('click', () => {
            if (booking.status === 'pending') {
              const am = document.getElementById('approval-details-modal');
              if (am) {
                am.dataset.currentBookingId = booking.id;
                am.classList.add('is-open');
                if (typeof openApprovalDetailsModal === 'function') openApprovalDetailsModal(booking.id);
              }
            } else {
              if (typeof openDetailsModal === 'function') {
                openDetailsModal(booking.machineId);
              } else {
                const dm = document.getElementById('details-modal');
                if (dm) dm.classList.add('is-open');
              }
            }
          });

          const team = window.labDB ? window.labDB.getTeam(booking.teamId) : null;
          const ttxt = team ? team.name : (booking.type === 'maintenance' ? 'Maintenance' : booking.machineId);
          const machine = window.labDB ? window.labDB.getMachine(booking.machineId) : null;
          const unitLabel = machine
            ? `${booking.machineId} · ${machine.type}`
            : booking.machineId || '';

          const td = document.createElement('div'); td.className = 'event-block__time';
          td.textContent = `${formatTimeLocal(booking.startTime)}\u2013${formatTimeLocal(booking.endTime)}`;
          const tit = document.createElement('div'); tit.className = 'event-block__title';
          tit.innerHTML = `<strong>${ttxt}</strong>`;
          const unit = document.createElement('div'); unit.className = 'event-block__unit';
          unit.textContent = unitLabel;
          const det = document.createElement('div'); det.className = 'event-block__detail';
          det.textContent = booking.detail || '';
          const st = document.createElement('div'); st.className = 'event-block__status';
          if (booking.status === 'pending') {
            st.innerHTML = '<span>Pending</span>'; st.classList.add('event-block__status--pending');
          } else if (booking.type === 'maintenance') {
            st.innerHTML = '<span>Maintenance</span>';
          } else {
            st.innerHTML = '<span>Confirmed</span>';
          }

          blk.appendChild(td); blk.appendChild(tit); blk.appendChild(unit); blk.appendChild(det); blk.appendChild(st);
          tl.appendChild(blk);

          capsuleMetas.push({ blk, slot, nSlots });
        });
      }

      dateRow.appendChild(tl);
      wrap.appendChild(dateRow);
      rowMeta.push({ tl, capsuleMetas });
    });

    grid.appendChild(wrap);

    // ── Shared layout function (used in rAF and ResizeObserver) ──────
    function applyCapsuleLayout() {
      rowMeta.forEach(({ tl, capsuleMetas }) => {
        if (capsuleMetas.length === 0) return;
        const rowH = tl.getBoundingClientRect().height;
        if (rowH <= 0) return;

        const nSlots  = capsuleMetas[0].nSlots;
        const padPx   = Math.round(rowH * ROW_PAD_FRAC);
        const usableH = rowH - padPx * 2;
        const GAP     = 2;
        const capsH   = Math.max(MIN_CAPSULE_H, Math.floor((usableH - (nSlots - 1) * GAP) / nSlots));
        const neededH = padPx * 2 + nSlots * MIN_CAPSULE_H + (nSlots - 1) * GAP;
        if (neededH > rowH) {
          tl.closest('.cal-date-row').style.minHeight = `${neededH}px`;
        } else {
          // Clear any previously forced min-height so flex can reclaim space
          tl.closest('.cal-date-row').style.minHeight = '';
        }

        capsuleMetas.forEach(({ blk, slot }) => {
          const topPx = padPx + slot * (capsH + GAP);
          blk.style.top    = `${topPx}px`;
          blk.style.height = `${capsH}px`;
        });
      });
    }

    // Second pass after initial paint
    requestAnimationFrame(applyCapsuleLayout);

    // Re-run on resize (fullscreen toggle, sidebar collapse, window resize)
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => requestAnimationFrame(applyCapsuleLayout));
      ro.observe(wrap);
      // Clean up when renderWeek rebuilds the grid
      const prevRo = grid._calResizeObserver;
      if (prevRo) prevRo.disconnect();
      grid._calResizeObserver = ro;
    }

    const calMain = document.querySelector('.calendar-main');
    const oldLeg = calMain && calMain.querySelector('.calendar-legend');
    if (oldLeg) oldLeg.remove();
  }

  // Initial render — default to Day view
  // renderWeek is defined earlier in the file; default view is Week
  setTimeout(() => renderWeek(currentWeekStart), 0);

  const navBtns = document.querySelectorAll('.calendar-toolbar__nav .btn--icon');
  if (navBtns[0]) navBtns[0].addEventListener('click', () => {
    if (currentView === 'day') {
      currentDayAnchor = new Date(currentDayAnchor);
      currentDayAnchor.setDate(currentDayAnchor.getDate() - 1);
      renderDay(currentDayAnchor);
    } else {
      currentWeekStart = new Date(currentWeekStart);
      currentWeekStart.setDate(currentWeekStart.getDate() - 7);
      renderWeek(currentWeekStart);
    }
  });
  if (navBtns[1]) navBtns[1].addEventListener('click', () => {
    if (currentView === 'day') {
      currentDayAnchor = new Date(currentDayAnchor);
      currentDayAnchor.setDate(currentDayAnchor.getDate() + 1);
      renderDay(currentDayAnchor);
    } else {
      currentWeekStart = new Date(currentWeekStart);
      currentWeekStart.setDate(currentWeekStart.getDate() + 7);
      renderWeek(currentWeekStart);
    }
  });

  const todayBtn = document.querySelector('.calendar-toolbar__left .btn--outline');
  if (todayBtn) todayBtn.addEventListener('click', () => {
    if (currentView === 'day') {
      currentDayAnchor = new Date(today);
      renderDay(currentDayAnchor);
    } else {
      currentWeekStart = getWeekStart(new Date());
      renderWeek(currentWeekStart);
    }
  });

  // ═══════════════════════════════════════════════════════════
  // MODAL TRIGGERS & INTERACTIONS (Task 7.1 & 7.3)
  // ═══════════════════════════════════════════════════════════

  // Task 7.1: Modal Triggers
  const approvalStatCard = document.querySelector('.stat-card--cancelled');
  if (approvalStatCard) {
    approvalStatCard.style.cursor = 'pointer';
    approvalStatCard.addEventListener('click', () => {
      const modal = document.getElementById('approval-list-modal');
      if (modal) modal.classList.add('is-open');
    });
  }

  const otherCalendarsHeader = Array.from(document.querySelectorAll('.sidebar-section__header'))
    .find(header => header.textContent.includes('Other Calendars'));
  if (otherCalendarsHeader) {
    otherCalendarsHeader.style.cursor = 'pointer';
    otherCalendarsHeader.addEventListener('click', (e) => {
      e.preventDefault();
      const modal = document.getElementById('explorer-modal');
      if (modal) modal.classList.add('is-open');
    });
  }





  // --- ADDITIONAL IMPLEMENTATIONS ---
  
  function formatTime(date) {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  // ═══════════════════════════════════════════════════════════
  // ENHANCED MINI-CALENDAR — week highlight + click navigation
  // ═══════════════════════════════════════════════════════════

  function buildMiniCalendar(container, baseDate) {
    let current = new Date(baseDate.getFullYear(), baseDate.getMonth(), 1);
    const MONTH_NAMES = ['January','February','March','April','May','June',
                         'July','August','September','October','November','December'];

    function getViewedWeekRange() {
      // When in day view, derive the week from currentDayAnchor; otherwise use currentWeekStart
      const anchor = currentView === 'day' ? getWeekStart(currentDayAnchor) : new Date(currentWeekStart);
      const ws = new Date(anchor);
      const we = new Date(anchor);
      we.setDate(ws.getDate() + 6);
      return { ws, we };
    }

    function render() {
      const year = current.getFullYear();
      const month = current.getMonth();
      container.querySelector('.mini-calendar__month').textContent =
        `${MONTH_NAMES[month]} ${year}`;
      const grid = container.querySelector('.mini-calendar__grid');
      grid.querySelectorAll('.mini-calendar__day').forEach(el => el.remove());
      const firstDay = new Date(year, month, 1).getDay(); // 0=Sun
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const daysInPrev  = new Date(year, month, 0).getDate();
      const todayDate   = new Date();
      const { ws, we } = getViewedWeekRange();

      // The selected day anchor (for day view active highlight)
      const selDate = currentView === 'day' ? currentDayAnchor : null;

      function dateKey(d, y, m) { return new Date(y, m, d).getTime(); }
      function inViewedWeek(d, y, m) {
        const t = dateKey(d, y, m);
        return t >= new Date(ws.getFullYear(), ws.getMonth(), ws.getDate()).getTime() &&
               t <= new Date(we.getFullYear(), we.getMonth(), we.getDate()).getTime();
      }
      function isWeekStart(d, y, m) {
        return dateKey(d, y, m) === new Date(ws.getFullYear(), ws.getMonth(), ws.getDate()).getTime();
      }
      function isWeekEnd(d, y, m) {
        return dateKey(d, y, m) === new Date(we.getFullYear(), we.getMonth(), we.getDate()).getTime();
      }
      function isSelected(d, y, m) {
        // Week view: all 7 days in week are "active" (dark blue)
        // Day view: only the currentDayAnchor is "active"
        if (currentView === 'week') return inViewedWeek(d, y, m);
        return selDate &&
               d === selDate.getDate() &&
               m === selDate.getMonth() &&
               y === selDate.getFullYear();
      }
      function isTodayDate(d, y, m) {
        return d === todayDate.getDate() && m === todayDate.getMonth() && y === todayDate.getFullYear();
      }

      function applyDayClasses(el, d, y, m, muted) {
        const today = isTodayDate(d, y, m);
        const selected = isSelected(d, y, m);
        const inWeek = inViewedWeek(d, y, m);

        if (selected) {
          el.classList.add('mini-calendar__day--active'); // dark blue circle
        } else if (today) {
          el.classList.add('mini-calendar__day--today');  // bold blue text, no circle
        }
        if (inWeek) {
          el.classList.add('mini-calendar__day--in-week');
          if (isWeekStart(d, y, m)) el.classList.add('mini-calendar__day--week-start');
          if (isWeekEnd(d, y, m))   el.classList.add('mini-calendar__day--week-end');
        }
      }

      // Leading days from previous month (muted)
      const prevYear = month === 0 ? year - 1 : year;
      const prevMonth = month === 0 ? 11 : month - 1;
      for (let i = firstDay - 1; i >= 0; i--) {
        const dayNum = daysInPrev - i;
        const el = document.createElement('div');
        el.className = 'mini-calendar__day mini-calendar__day--muted';
        el.textContent = dayNum;
        applyDayClasses(el, dayNum, prevYear, prevMonth, true);
        el.addEventListener('click', () => navigateToDate(new Date(prevYear, prevMonth, dayNum)));
        grid.appendChild(el);
      }

      // Current month days
      for (let d = 1; d <= daysInMonth; d++) {
        const el = document.createElement('div');
        el.className = 'mini-calendar__day';
        el.textContent = d;
        applyDayClasses(el, d, year, month, false);
        el.addEventListener('click', () => navigateToDate(new Date(year, month, d)));
        grid.appendChild(el);
      }

      // Trailing days from next month (muted)
      const totalFilled = firstDay + daysInMonth;
      const rem = totalFilled % 7 === 0 ? 0 : 7 - (totalFilled % 7);
      const nextYear = month === 11 ? year + 1 : year;
      const nextMonth = month === 11 ? 0 : month + 1;
      for (let d = 1; d <= rem; d++) {
        const el = document.createElement('div');
        el.className = 'mini-calendar__day mini-calendar__day--muted';
        el.textContent = d;
        applyDayClasses(el, d, nextYear, nextMonth, true);
        el.addEventListener('click', () => navigateToDate(new Date(nextYear, nextMonth, d)));
        grid.appendChild(el);
      }
    }

    function navigateToDate(date) {
      if (currentView === 'week') {
        currentWeekStart = getWeekStart(date);
        renderWeek(currentWeekStart);
        // re-render mini-cal to show new week highlight
        current = new Date(currentWeekStart.getFullYear(), currentWeekStart.getMonth(), 1);
        render();
      } else {
        currentDayAnchor = new Date(date);
        renderDay(currentDayAnchor);
        render();
      }
      // Re-apply filter highlighting after navigation
      if (activeSmartFilter) {
        setTimeout(() => applyFilterHighlighting(activeSmartFilter), 10);
      }
    }

    const [prevBtn, nextBtn] = container.querySelectorAll('.mini-calendar__header .btn--icon');
    if (prevBtn) prevBtn.addEventListener('click', () => {
      current = new Date(current.getFullYear(), current.getMonth() - 1, 1);
      render();
    });
    if (nextBtn) nextBtn.addEventListener('click', () => {
      current = new Date(current.getFullYear(), current.getMonth() + 1, 1);
      render();
    });

    render();

    // Expose re-render so main nav buttons can refresh the highlight
    container._refreshMiniCal = render;
    // Expose reset so the ↺ Today button can jump back to a specific month
    container._resetToDate = function(date) {
      current = new Date(date.getFullYear(), date.getMonth(), 1);
      render();
    };
  }

  const miniCalContainer = document.querySelector('.mini-calendar');
  if (miniCalContainer) buildMiniCalendar(miniCalContainer, today);

  function refreshMiniCalIfMounted() {
    const mc = document.querySelector('.mini-calendar');
    if (mc && mc._refreshMiniCal) mc._refreshMiniCal();
  }

  // Main-calendar nav buttons → also refresh mini-cal highlight
  if (navBtns[0]) navBtns[0].addEventListener('click', refreshMiniCalIfMounted);
  if (navBtns[1]) navBtns[1].addEventListener('click', refreshMiniCalIfMounted);
  if (todayBtn)   todayBtn.addEventListener('click', refreshMiniCalIfMounted);

  // ↺ Today sidebar reset button
  const resetTodayBtn = document.getElementById('mini-cal-reset-today');
  if (resetTodayBtn) {
    resetTodayBtn.addEventListener('click', () => {
      const t = new Date();
      if (currentView === 'week') {
        currentWeekStart = getWeekStart(t);
        renderWeek(currentWeekStart);
      } else {
        currentDayAnchor = new Date(t);
        renderDay(currentDayAnchor);
      }
      // Sync mini-cal month to today and redraw
      const mc = document.querySelector('.mini-calendar');
      if (mc && mc._refreshMiniCal) {
        // Reset the mini-cal's internal `current` to today's month
        mc._resetToDate(t);
      }
      if (activeSmartFilter) setTimeout(() => applyFilterHighlighting(activeSmartFilter), 10);
    });
  }

  // ═══════════════════════════════════════════════════════════
  // SMART FILTER TOGGLES
  // ═══════════════════════════════════════════════════════════

  let activeSmartFilter = null; // null | 'confirmed-bookings' | 'scheduled' | 'pending-approvals'

  function applySmartFilter(filter) {
    activeSmartFilter = filter;

    // Update button active states
    document.querySelectorAll('.smart-filter-btn').forEach(btn => {
      btn.classList.toggle('is-active', btn.dataset.filter === filter);
    });

    // Re-render the calendar then apply visual highlighting
    if (currentView === 'week') {
      renderWeek(currentWeekStart);
    } else {
      renderDay(currentDayAnchor);
    }
    // Apply highlighting after the DOM has updated
    setTimeout(() => applyFilterHighlighting(filter), 10);
  }

  function getFilteredBookings(filter) {
    if (!filter) return mockBookings;
    const now = new Date();

    switch (filter) {
      case 'available':
        // Show EMPTY slots — effectively hide all bookings so only free time is visible
        // We dim non-available blocks
        return mockBookings.map(b => ({ ...b, _dimmed: b.type !== 'project' ? false : false }));
      case 'confirmed-bookings':
        // Show all confirmed bookings regardless of time
        return mockBookings.filter(b =>
          b.status === 'confirmed' && b.type !== 'maintenance'
        );
      case 'maintenance':
        // Currently active maintenance
        return mockBookings.filter(b =>
          b.type === 'maintenance' && b.startTime <= now && b.endTime >= now
        );
      case 'scheduled':
        // All maintenance (past, present, future)
        return mockBookings.filter(b => b.type === 'maintenance');
      case 'pending-approvals':
        // All bookings awaiting approval
        return mockBookings.filter(b => b.status === 'pending');
      default:
        return mockBookings;
    }
  }

  function renderWeekFiltered(anchorMonday, filter) {
    const filteredBookings = getFilteredBookings(filter);
    // Temporarily override mockBookings reference used in renderWeek
    const original = window._filteredBookings;
    window._filteredBookings = filteredBookings;
    renderWeek(anchorMonday);
    window._filteredBookings = original;
  }

  function renderDayFiltered(day, filter) {
    const filteredBookings = getFilteredBookings(filter);
    window._filteredBookings = filteredBookings;
    if (typeof renderDay === 'function') renderDay(day);
    window._filteredBookings = null;
  }

  // Wire up smart filter buttons
  document.querySelectorAll('.smart-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;
      if (activeSmartFilter === filter) {
        // Toggle off — clear filter and show all
        activeSmartFilter = null;
        btn.classList.remove('is-active');
        if (currentView === 'day') {
          renderDay(currentDayAnchor);
        } else {
          renderWeek(currentWeekStart);
        }
        // Clear any residual highlighting
        setTimeout(() => applyFilterHighlighting(null), 10);
      } else {
        applySmartFilter(filter);
      }
    });
  });

  // Patch renderWeek to respect _filteredBookings
  const _originalRenderWeek = renderWeek;
  // Note: renderWeek already uses mockBookings directly, so we augment the data source
  // The filter is applied by replacing event-block rendering visibility below.

  // ─── Helper: resolve a booking's equipment category via its machineId ─────────
  function getBookingCategoryId(booking) {
    if (!window.labDB) return null;
    const machine = window.labDB.machines.find(m => m.id === booking.machineId);
    return machine ? machine.categoryId : null;
  }

  // ─── Category visibility set — all categories shown by default ───────────────
  let activeCategories = new Set(['printers', 'laser', 'cnc', 'pcb', 'testing', 'solder', 'robotics']);

  // Simpler approach: add CSS class to dim non-matching blocks
  function applyFilterHighlighting(filter) {
    // If no smart filter, just apply category visibility
    if (!filter) {
      document.querySelectorAll('.event-block').forEach(el => {
        const bookingId = el.dataset.bookingId;
        const booking = mockBookings.find(b => b.id === bookingId);
        const catId = booking ? getBookingCategoryId(booking) : null;
        const catVisible = !catId || activeCategories.has(catId);
        el.style.opacity = catVisible ? '' : '0';
        el.style.boxShadow = catVisible ? '' : 'none';
        el.style.visibility = catVisible ? '' : 'hidden';
        el.style.pointerEvents = catVisible ? '' : 'none';
        el.style.filter = '';
        el.style.outline = '';
        el.style.outlineOffset = '';
      });
      return;
    }
    const now = new Date();
    document.querySelectorAll('.event-block').forEach(el => {
      const bookingId = el.dataset.bookingId;
      const booking = mockBookings.find(b => b.id === bookingId);
      if (!booking) return;

      let match = false;
      switch (filter) {
        case 'available':
          // No block matches "available" — dim all events to show free time
          match = false;
          break;
        case 'confirmed-bookings':
          match = booking.status === 'confirmed' && booking.type !== 'maintenance';
          break;
        case 'maintenance':
          match = booking.type === 'maintenance' &&
                  booking.startTime <= now && booking.endTime >= now;
          break;
        case 'scheduled':
          match = booking.type === 'maintenance';
          break;
        case 'pending-approvals':
          match = booking.status === 'pending';
          break;
      }

      if (match) {
        // Also check category filter
        const catId = getBookingCategoryId(booking);
        const catVisible = !catId || activeCategories.has(catId);
        if (catVisible) {
          el.style.opacity = '1';
          el.style.filter = 'none';
          el.style.boxShadow = '';
          el.style.visibility = '';
          el.style.pointerEvents = '';
          el.style.outline = '';
          el.style.outlineOffset = '';
        } else {
          el.style.opacity = '0';
          el.style.boxShadow = 'none';
          el.style.visibility = 'hidden';
          el.style.pointerEvents = 'none';
          el.style.filter = '';
          el.style.outline = '';
          el.style.outlineOffset = '';
        }
      } else {
        el.style.opacity = '0.2';
        el.style.boxShadow = 'none';
        el.style.visibility = '';
        el.style.pointerEvents = 'none';
        el.style.filter = 'grayscale(0.6)';
        el.style.outline = '';
        el.style.outlineOffset = '';
      }
    });
  }

  // Re-apply filter after any calendar render
  const _postRender = () => {
    setTimeout(() => applyFilterHighlighting(activeSmartFilter), 10);
  };

  // Patch nav buttons and today button to re-apply filter after navigation
  if (navBtns[0]) navBtns[0].addEventListener('click', _postRender);
  if (navBtns[1]) navBtns[1].addEventListener('click', _postRender);
  if (todayBtn)   todayBtn.addEventListener('click',   _postRender);

  // ═══════════════════════════════════════════════════════════
  // EQUIPMENT CLASS FILTERS (machine-category checkboxes)
  // ═══════════════════════════════════════════════════════════

  (function initEquipmentClassFilters() {
    const catCheckboxes = document.querySelectorAll('input[data-category]');
    const selectAllBtn  = document.getElementById('eq-filter-select-all');

    function updateSelectAllLabel() {
      if (!selectAllBtn) return;
      const allChecked = [...catCheckboxes].every(cb => cb.checked);
      selectAllBtn.textContent = allChecked ? 'None' : 'All';
    }

    function applyCategoryFilter() {
      // Rebuild the active set
      activeCategories = new Set(
        [...catCheckboxes]
          .filter(cb => cb.checked)
          .map(cb => cb.dataset.category)
      );
      updateSelectAllLabel();
      // Re-apply combined highlighting (smart filter + category)
      setTimeout(() => applyFilterHighlighting(activeSmartFilter), 10);
    }

    catCheckboxes.forEach(cb => {
      cb.addEventListener('change', applyCategoryFilter);
    });

    if (selectAllBtn) {
      selectAllBtn.addEventListener('click', () => {
        const allChecked = [...catCheckboxes].every(cb => cb.checked);
        // Toggle: if all checked → uncheck all; otherwise → check all
        catCheckboxes.forEach(cb => { cb.checked = !allChecked; });
        applyCategoryFilter();
      });
    }

    // Initial label sync
    updateSelectAllLabel();
  })();


  function syncAlertsPanel(stats) {
    const pendingCountEl = document.getElementById('alert-pending-count');
    const maintCountEl = document.getElementById('alert-maintenance-count');
    if (pendingCountEl) pendingCountEl.textContent = stats.pendingApproval;
    if (maintCountEl) maintCountEl.textContent = stats.inMaintenance;

    // Hide the alerts panel if there's nothing to action
    const alertsPanel = document.getElementById('sidebar-alerts');
    if (alertsPanel) {
      const hasAlerts = stats.pendingApproval > 0 || stats.inMaintenance > 0;
      alertsPanel.style.display = hasAlerts ? '' : 'none';
    }

    // Dim individual rows if count is 0
    const pendingRow = document.getElementById('alert-pending-approvals');
    const maintRow = document.getElementById('alert-offline-machines');
    if (pendingRow) pendingRow.style.opacity = stats.pendingApproval > 0 ? '1' : '0.4';
    if (maintRow) maintRow.style.opacity = stats.inMaintenance > 0 ? '1' : '0.4';
  }

  // Wire up alerts panel clicks
  const alertPendingRow = document.getElementById('alert-pending-approvals');
  if (alertPendingRow) {
    alertPendingRow.addEventListener('click', () => {
      const modal = document.getElementById('approval-list-modal');
      if (modal) modal.classList.add('is-open');
    });
  }

  const alertMaintRow = document.getElementById('alert-offline-machines');
  if (alertMaintRow) {
    alertMaintRow.addEventListener('click', () => {
      // Activate the scheduled maintenance smart filter to highlight them
      applySmartFilter('scheduled');
      applyFilterHighlighting('scheduled');
    });
  }

  // Initial sync
  syncAlertsPanel(currentStats);

  // Patch updateOverviewCards to also sync alerts
  const _origUpdateOverviewCards = updateOverviewCards;
  // Re-define to also call syncAlertsPanel
  // (We already called updateOverviewCards once; patch future calls via a wrapper)
  window._syncAlertsAfterUpdate = syncAlertsPanel;

  // Issues 4,5,6: Equipment Explorer
  // Source of truth is now window.labDB
  const equipmentCategories = window.labDB ? window.labDB.equipmentCategories : [];

  // Build a flat list of all machines with category info
  function getAllMachinesFlat() {
    return window.labDB ? window.labDB.getAllMachinesFlat() : [];
  }

  // Compute per-filter counts across the whole equipment list
  function updateFilterCounts() {
    const all = getAllMachinesFlat();
    const countMap = { all: all.length, 'in-use': 0, available: 0, maintenance: 0, scheduled: 0 };
    all.forEach(m => {
      if (m.status === 'in-use')      countMap['in-use']++;
      if (m.status === 'available')   countMap.available++;
      if (m.status === 'maintenance') countMap.maintenance++;
      if (m.status === 'scheduled')   countMap.scheduled++;
    });
    Object.entries(countMap).forEach(([key, val]) => {
      const el = document.getElementById(`filter-count-${key}`);
      if (el) el.textContent = val;
    });
  }

  // Render the explorer sidebar category list dynamically from labDB
  function renderExplorerSidebar() {
    const sidebar = document.getElementById('explorer-cat-sidebar');
    if (!sidebar) return;
    // Keep the title
    const title = sidebar.querySelector('.explorer-sidebar__title');
    sidebar.innerHTML = '';
    if (title) sidebar.appendChild(title);

    equipmentCategories.forEach(cat => {
      const machines = window.labDB ? window.labDB.machines.filter(m => m.categoryId === cat.id) : [];
      const el = document.createElement('div');
      el.className = 'explorer-cat';
      el.dataset.catId = cat.id;
      el.innerHTML = `
        <div class="explorer-cat__icon ${cat.colorClass}"><i class="fas fa-cube"></i></div>
        <div class="explorer-cat__name">${cat.name}</div>
        <div class="explorer-cat__count">${machines.length}</div>
        <i class="fas fa-chevron-right explorer-cat__arrow"></i>
      `;
      el.addEventListener('click', () => {
        sidebar.querySelectorAll('.explorer-cat').forEach(c => c.classList.remove('explorer-cat--active'));
        el.classList.add('explorer-cat--active');
        renderExplorerMachineList(cat.id, undefined);
      });
      sidebar.appendChild(el);
    });
  }

  // Cross-filter state
  let currentCatId    = 'all';   // category selected in left sidebar
  let currentFilter   = 'all';   // status filter selected in top filter bar

  function renderExplorerMachineList(catId, filter) {
    // Update persisted state
    if (catId    !== undefined) currentCatId  = catId;
    if (filter   !== undefined) currentFilter = filter;

    // Update category counts in sidebar based on active filter
    const catSidebar = document.getElementById('explorer-cat-sidebar');
    if (catSidebar) {
      catSidebar.querySelectorAll('.explorer-cat[data-cat-id]').forEach(catEl => {
        const loopCatId = catEl.dataset.catId;
        const machines  = window.labDB ? window.labDB.machines.filter(m => m.categoryId === loopCatId) : [];
        let matchCount  = machines.length;
        if (currentFilter !== 'all') {
          matchCount = machines.filter(m => m.status === currentFilter).length;
        }
        const countEl = catEl.querySelector('.explorer-cat__count');
        if (countEl) countEl.textContent = matchCount;
      });
    }

    const allMachinesFlat = getAllMachinesFlat();
    const cat = currentCatId === 'all' ? null : equipmentCategories.find(c => c.id === currentCatId);

    // Step 1: filter by category
    let machines = cat
      ? allMachinesFlat.filter(m => m.catId === cat.id)
      : allMachinesFlat;

    // Step 2: filter by status
    if (currentFilter !== 'all') {
      machines = machines.filter(m => m.status === currentFilter);
    }

    // Update header (use IDs added by HTML refactor)
    const titleEl    = document.getElementById('explorer-main-title');
    const subtitleEl = document.getElementById('explorer-main-subtitle');
    const iconWrapEl = document.getElementById('explorer-main-icon');
    if (titleEl)    titleEl.textContent = cat ? cat.name : 'All Equipment';
    if (subtitleEl) subtitleEl.textContent = `${machines.length} Machine${machines.length !== 1 ? 's' : ''}`;
    if (iconWrapEl) {
      iconWrapEl.className = `explorer-cat__icon ${cat ? cat.colorClass : 'color-primary'}`;
      iconWrapEl.innerHTML = `<i class="fas fa-cube"></i>`;
    }

    const list = document.getElementById('machine-list');
    if (!list) return;
    list.innerHTML = '';

    if (machines.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'machine-list__empty';
      empty.textContent = 'No machines match the selected filters.';
      list.appendChild(empty);
      return;
    }

    machines.forEach(m => {
      const badgeMap = {
        'available':   ['badge--available', 'Available', window.statusIcons['available']],
        'in-use':      ['badge--in-use', 'In Use', window.statusIcons['in-use']],
        'maintenance': ['badge--maintenance', 'Maintenance', window.statusIcons['maintenance']],
        'scheduled':   ['badge--scheduled', 'Scheduled', window.statusIcons['scheduled']],
      };
      const [badgeCls, badgeLabel, badgeSvg] = badgeMap[m.status] || ['badge--available', 'Unknown', ''];
      const item = document.createElement('div');
      item.className = 'machine-item';
      item.innerHTML = `
        <div class="machine-item__icon ${m.catColorClass || 'color-blue'}"><i class="fas fa-cube"></i></div>
        <div class="machine-item__info">
          <div class="machine-item__name">${m.id}</div>
          <div class="machine-item__desc">${m.type} &bull; ${m.location}</div>
        </div>
        <span class="badge ${badgeCls}">${badgeSvg}<span>${badgeLabel}</span></span>
        <i class="fas fa-chevron-right machine-item__arrow"></i>
      `;
      item.addEventListener('click', () => openDetailsModal(m.id));
      list.appendChild(item);
    });
  }

  // Sidebar category listeners
  document.querySelectorAll('.explorer-cat[data-cat-id]').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.explorer-cat').forEach(c => c.classList.remove('explorer-cat--active'));
      el.classList.add('explorer-cat--active');
      renderExplorerMachineList(el.dataset.catId, undefined);
    });
  });

  // Status filter tab listeners (top bar)
  document.querySelectorAll('.explorer-filter[data-filter]').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.explorer-filter').forEach(f => f.classList.remove('explorer-filter--active'));
      el.classList.add('explorer-filter--active');
      renderExplorerMachineList(undefined, el.dataset.filter);
    });
  });

  // Wire the → View button to open the explorer modal
  const openExplorerBtn = document.getElementById('open-explorer-btn');
  if (openExplorerBtn) {
    openExplorerBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const modal = document.getElementById('explorer-modal');
      if (modal) modal.classList.add('is-open');
    });
  }

  const explorerModal = document.getElementById('explorer-modal');
  if (explorerModal) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          if (explorerModal.classList.contains('is-open')) {
            // Reset state on open
            currentCatId  = 'all';
            currentFilter = 'all';
            // Rebuild category sidebar from labDB each time (picks up new machines)
            renderExplorerSidebar();
            document.querySelectorAll('.explorer-filter').forEach(f => f.classList.remove('explorer-filter--active'));
            const firstFilter = document.querySelector('.explorer-filter[data-filter="all"]');
            if (firstFilter) firstFilter.classList.add('explorer-filter--active');
            updateFilterCounts();
            renderExplorerMachineList('all', 'all');
          }
        }
      });
    });
    observer.observe(explorerModal, { attributes: true });
  }

  // Issue 7: Details mini calendar
  function renderDetailsMiniCalendar(machineId) {
    const container = document.getElementById('details-mini-cal');
    if (!container) return;
    container.innerHTML = '';

    const filteredBks = mockBookings.filter(b => b.machineId === machineId);
    const TOTAL_MINS  = (CALENDAR_END_H - CALENDAR_START_H) * MINS_PER_HOUR;
    const ROW_H       = 26;
    const ROW_GAP     = 3;
    const ROW_PAD     = 4;
    const DAY_NAMES   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const TODAY       = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

    const currentDays = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(currentWeekStart);
      d.setDate(currentWeekStart.getDate() + i);
      return d;
    });

    // ── Sticky time-axis header ───────────────────────────────────────
    const hdr = document.createElement('div');
    hdr.className = 'cal-time-header-row';
    const corner = document.createElement('div');
    corner.className = 'cal-corner-cell';
    hdr.appendChild(corner);
    for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
      const tick = document.createElement('div');
      tick.className = 'cal-time-tick';
      tick.textContent = `${String(h).padStart(2,'0')}:00`;
      hdr.appendChild(tick);
    }
    container.appendChild(hdr);

    // ── Body rows ─────────────────────────────────────────────────────
    const wrap = document.createElement('div');
    wrap.className = 'cal-body-rows-wrap';

    currentDays.forEach(day => {
      const isToday  = day.getTime() === TODAY.getTime();
      const dayStart = new Date(day); dayStart.setHours(0, 0, 0, 0);
      const dayEnd   = new Date(day); dayEnd.setHours(23, 59, 59, 999);
      const calStart = new Date(day); calStart.setHours(CALENDAR_START_H, 0, 0, 0);
      const calEnd   = new Date(day); calEnd.setHours(CALENDAR_END_H, 0, 0, 0);

      const dateRow = document.createElement('div');
      dateRow.className = 'cal-date-row' + (isToday ? ' cal-date-row--today' : '');

      const lbl = document.createElement('div');
      lbl.className = 'cal-row-label';
      const nm = document.createElement('span');
      nm.className = 'cal-row-label__name';
      nm.textContent = DAY_NAMES[day.getDay()];
      const num = document.createElement('span');
      num.className = 'cal-row-label__num' + (isToday ? ' cal-row-label__num--today' : '');
      num.textContent = day.getDate();
      lbl.appendChild(nm); lbl.appendChild(num);
      dateRow.appendChild(lbl);

      const tl = document.createElement('div');
      tl.className = 'cal-row-timeline';

      for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
        const vl = document.createElement('div');
        vl.className = 'cal-vline cal-vline--hour';
        vl.style.left = `${((h - CALENDAR_START_H) / (CALENDAR_END_H - CALENDAR_START_H)) * 100}%`;
        tl.appendChild(vl);
      }

      const dayBks = filteredBks.filter(b => b.startTime < dayEnd && b.endTime > dayStart);

      if (dayBks.length > 0) {
        const withEff = dayBks.map(b => ({
          booking: b,
          effStart: b.startTime < calStart ? calStart : b.startTime,
          effEnd:   b.endTime   > calEnd   ? calEnd   : b.endTime,
        })).filter(x => x.effEnd > x.effStart);

        const sorted = [...withEff].sort((a, b) => a.effStart - b.effStart);
        const slotEnds = [];
        const assigned = sorted.map(item => {
          let slot = slotEnds.findIndex(e => e <= item.effStart);
          if (slot === -1) { slot = slotEnds.length; slotEnds.push(item.effEnd); }
          else { slotEnds[slot] = item.effEnd; }
          return { ...item, slot };
        });
        const nSlots = slotEnds.length;
        const minH   = ROW_PAD * 2 + nSlots * ROW_H + Math.max(0, nSlots - 1) * ROW_GAP;
        dateRow.style.minHeight = `${Math.max(36, minH)}px`;
        tl.style.minHeight = `${Math.max(36, minH)}px`;

        assigned.forEach(({ booking, effStart, effEnd, slot }) => {
          const startMins = (effStart.getHours() - CALENDAR_START_H) * 60 + effStart.getMinutes();
          const durMins   = (effEnd - effStart) / 60000;
          if (durMins <= 0) return;

          const leftPct  = (startMins / TOTAL_MINS) * 100;
          const widthPct = Math.max(0.5, (durMins / TOTAL_MINS) * 100);
          const topPx    = ROW_PAD + slot * (ROW_H + ROW_GAP);

          let tc = booking.status === 'pending' ? 'event-pending'
                 : booking.type === 'maintenance' ? 'event-maintenance'
                 : 'event-in-use';

          const blk = document.createElement('div');
          blk.className = `event-block ${tc}`;
          blk.style.top    = `${topPx}px`;
          blk.style.height = `${ROW_H}px`;
          blk.style.left   = `calc(${leftPct}% + 2px)`;
          blk.style.width  = `calc(${widthPct}% - 4px)`;

          const _team = window.labDB ? window.labDB.getTeam(booking.teamId) : null;
          const _ttxt = _team ? _team.name : (booking.type === 'maintenance' ? 'Maintenance' : booking.machineId);

          const td = document.createElement('div'); td.className = 'event-block__time';
          td.textContent = `${formatTime(booking.startTime)}\u2013${formatTime(booking.endTime)}`;
          const tit = document.createElement('div'); tit.className = 'event-block__title';
          tit.innerHTML = `<strong>${_ttxt}</strong>`;

          blk.appendChild(td); blk.appendChild(tit);
          tl.appendChild(blk);
        });
      }

      dateRow.appendChild(tl);
      wrap.appendChild(dateRow);
    });

    container.appendChild(wrap);
    // Legend removed as per request
  }

  // Issue 8 & 9: Approval list & details — sourced from labDB.getPendingApprovals()
  function getPendingBookingDetails() {
    if (!window.labDB) return {};
    const arr = window.labDB.getPendingApprovals();
    const map = {};
    arr.forEach(b => { map[b.bookingId] = b; });
    return map;
  }

  function getAllBookingDetails() {
    if (!window.labDB) return {};
    const pending = window.labDB.getPendingApprovals();
    const history = window.labDB.getBookingHistory ? window.labDB.getBookingHistory() : [];
    const map = {};
    [...pending, ...history].forEach(b => { map[b.bookingId] = b; });
    return map;
  }

  // Global tab state for the approval-list modal
  window.currentApprovalTab = window.currentApprovalTab || 'pending';

  window.renderApprovalList = renderApprovalList;

  // ── Pagination state ──────────────────────────────────────────────────────
  const APPROVAL_ITEMS_PER_PAGE = 8;
  window.approvalCurrentPage = window.approvalCurrentPage || 1;

  function renderApprovalList(resetPage) {
    const tbody = document.getElementById('approval-list-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    const isHistory = window.currentApprovalTab === 'history';

    // Reset to page 1 on tab switch or explicit request
    if (resetPage) window.approvalCurrentPage = 1;

    // Update tab active state
    document.querySelectorAll('#approval-tab-nav .tab-nav__item').forEach(btn => {
      btn.classList.toggle('tab-nav__item--active', btn.dataset.tab === window.currentApprovalTab);
    });

    // Update action column header
    const actionCol = document.getElementById('approval-action-col');
    if (actionCol) actionCol.textContent = isHistory ? 'RESPONSE' : 'ACTION';

    const searchInput = document.querySelector('#approval-list-modal .search-box__input');
    const query = searchInput ? searchInput.value.trim() : '';
    const q = query.toLowerCase();

    // Init dropdowns if empty
    const teamSelect = document.getElementById('approval-team-filter');
    const facultySelect = document.getElementById('approval-faculty-filter');
    const statusSelect = document.getElementById('approval-status-filter');
    const dateInput = document.getElementById('approval-date-filter');

    const allItems = window.labDB
      ? (isHistory
          ? (window.labDB.getBookingHistory ? window.labDB.getBookingHistory() : [])
          : window.labDB.getPendingApprovals())
      : [];

    // Update tab counts
    const pendingCountEl = document.getElementById('tab-pending-count');
    const historyCountEl = document.getElementById('tab-history-count');
    if (pendingCountEl && window.labDB) {
      pendingCountEl.textContent = window.labDB.getPendingApprovals().length;
    }
    if (historyCountEl && window.labDB && window.labDB.getBookingHistory) {
      historyCountEl.textContent = window.labDB.getBookingHistory().length;
    }

    if (teamSelect && teamSelect.options.length <= 1) {
      const teams = [...new Set(allItems.map(b => b.team))].filter(Boolean).sort();
      teams.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t;
        opt.textContent = t;
        teamSelect.appendChild(opt);
      });
    }

    if (facultySelect && facultySelect.options.length <= 1) {
      const faculties = [...new Set(allItems.map(b => b.faculty))].filter(Boolean).sort();
      faculties.forEach(f => {
        const opt = document.createElement('option');
        opt.value = f;
        opt.textContent = f;
        facultySelect.appendChild(opt);
      });
    }

    if (statusSelect && statusSelect.options.length <= 1) {
      const statusOpts = isHistory ? ['Approved', 'Rejected'] : ['Pending'];
      statusOpts.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.toLowerCase();
        opt.textContent = s;
        statusSelect.appendChild(opt);
      });
    }

    const teamFilter = teamSelect ? teamSelect.value : '';
    const facultyFilter = facultySelect ? facultySelect.value : '';
    const statusFilter = statusSelect ? statusSelect.value : '';
    const dateFilter = dateInput ? dateInput.value : ''; // "YYYY-MM-DD"

    let items = allItems;

    if (teamFilter) {
      items = items.filter(b => b.team === teamFilter);
    }
    if (facultyFilter) {
      items = items.filter(b => b.faculty === facultyFilter);
    }
    if (statusFilter && isHistory) {
      if (statusFilter === 'approved') {
        items = items.filter(b => b.status === 'confirmed');
      } else if (statusFilter === 'rejected') {
        items = items.filter(b => b.status === 'rejected');
      }
    }
    if (dateFilter) {
      // dateFilter is YYYY-MM-DD. Convert it to match b.date (DD Mon YYYY)
      const parts = dateFilter.split('-');
      if (parts.length === 3) {
        const d = new Date(parts[0], parts[1] - 1, parts[2]);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const formattedDate = `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
        items = items.filter(b => b.date === formattedDate);
      }
    }

    if (query) {
       items = items.filter(b =>
         b.bookingId.toLowerCase().includes(q) ||
         b.team.toLowerCase().includes(q) ||
         b.faculty.toLowerCase().includes(q) ||
         b.equipment.toLowerCase().includes(q) ||
         b.date.toLowerCase().includes(q) ||
         b.timeSlot.toLowerCase().includes(q)
       );
    }

    const highlight = (text) => {
        if (!query) return text;
        const safeQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(${safeQuery})`, 'gi');
        return text.replace(regex, '<mark style="background-color: yellow;">$1</mark>');
    };

    // ── Pagination maths ──────────────────────────────────────────────────────
    const totalItems = items.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / APPROVAL_ITEMS_PER_PAGE));

    // Clamp current page
    if (window.approvalCurrentPage > totalPages) window.approvalCurrentPage = totalPages;
    if (window.approvalCurrentPage < 1) window.approvalCurrentPage = 1;

    const pageStart = (window.approvalCurrentPage - 1) * APPROVAL_ITEMS_PER_PAGE;
    const pageEnd   = Math.min(pageStart + APPROVAL_ITEMS_PER_PAGE, totalItems);
    const pageItems = items.slice(pageStart, pageEnd);

    pageItems.forEach(b => {
      const tr = document.createElement('tr');
      // Build last column differently for pending vs history
      let actionCell;
      if (isHistory) {
        const isApproved = b.response === 'Approved';
        actionCell = `
          <td class="col-right">
            <div style="display: flex; gap: 8px; justify-content: flex-end; align-items: center;">
              <span class="badge ${isApproved ? 'badge--confirmed' : 'badge--rejected'}" style="font-size: 0.75rem; padding: 4px 10px;">
                ${isApproved ? '<i class="fas fa-check" style="margin-right:4px;"></i>Approved' : '<i class="fas fa-times" style="margin-right:4px;"></i>Rejected'}
              </span>
              <button class="btn btn--outline btn--sm view-history-btn" data-booking-id="${b.bookingId}">View</button>
            </div>
          </td>`;
      } else {
        actionCell = `
          <td class="col-right">
            <div style="display: flex; gap: 8px; justify-content: flex-end; align-items: center;">
              <button class="btn btn--icon approval-approve-btn" title="Approve" data-booking-id="${b.bookingId}" style="border: 1px solid var(--clr-success-500, #10b981); color: var(--clr-success-600, #059669); border-radius: 4px; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: #ecfdf5;">
                <i class="fas fa-check"></i>
              </button>
              <button class="btn btn--icon approval-reject-btn" title="Reject" data-booking-id="${b.bookingId}" style="border: 1px solid var(--clr-danger-500, #ef4444); color: var(--clr-danger-600, #dc2626); border-radius: 4px; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; background: #fef2f2;">
                <i class="fas fa-times"></i>
              </button>
              <button class="btn btn--outline btn--sm view-pending-btn" data-booking-id="${b.bookingId}">View</button>
            </div>
          </td>`;
      }
      tr.innerHTML = `
        <td><span class="machine-id">${highlight(b.bookingId)}</span></td>
        <td>${highlight(b.team)}</td>
        <td>${highlight(b.faculty)}</td>
        <td>${highlight(b.equipment)}</td>
        <td>
          <div class="table-booking__team">${highlight(b.date)}</div>
          <div class="table-booking__slot">${highlight(b.timeSlot)}</div>
        </td>
        ${actionCell}
      `;
      if (isHistory) {
        tr.querySelector('.view-history-btn').addEventListener('click', () => openApprovalDetailsModal(b.bookingId));
      } else {
        tr.querySelector('.view-pending-btn').addEventListener('click', () => openApprovalDetailsModal(b.bookingId));
        tr.querySelector('.approval-approve-btn').addEventListener('click', () => {
          if (window.labDB) window.labDB.approveBooking(b.bookingId);
          if (typeof window.refreshUI === 'function') window.refreshUI();
          renderApprovalList();
          if (typeof window.showToast === 'function') window.showToast('Request has been approved.', 'success');
        });
        tr.querySelector('.approval-reject-btn').addEventListener('click', () => {
          window.currentRejectionBookingId = b.bookingId;
          const rejectModal = document.getElementById('rejection-reason-modal');
          const reasonInput = document.getElementById('rejection-reason-input');
          if (rejectModal && reasonInput) {
              reasonInput.value = '';
              rejectModal.classList.add('is-open');
          }
        });
      }
      tbody.appendChild(tr);
    });

    // ── Update pagination UI ──────────────────────────────────────────────────
    const infoEl   = document.getElementById('approval-pagination-info');
    const prevBtn  = document.getElementById('approval-page-prev');
    const nextBtn  = document.getElementById('approval-page-next');
    const numsCont = document.getElementById('approval-page-numbers');

    if (infoEl) {
      if (totalItems === 0) {
        infoEl.textContent = `No ${isHistory ? 'records' : 'requests'} found`;
      } else {
        infoEl.textContent = `Showing ${pageStart + 1}–${pageEnd} of ${totalItems} ${isHistory ? 'records' : 'requests'}`;
      }
    }

    if (prevBtn) {
      prevBtn.disabled = window.approvalCurrentPage <= 1;
      prevBtn.onclick = () => { window.approvalCurrentPage--; renderApprovalList(); };
    }
    if (nextBtn) {
      nextBtn.disabled = window.approvalCurrentPage >= totalPages;
      nextBtn.onclick = () => { window.approvalCurrentPage++; renderApprovalList(); };
    }

    if (numsCont) {
      numsCont.innerHTML = '';
      // Show up to 5 page buttons around the current page
      const range = 2;
      const start = Math.max(1, window.approvalCurrentPage - range);
      const end   = Math.min(totalPages, window.approvalCurrentPage + range);

      if (start > 1) {
        const btn = document.createElement('button');
        btn.className = 'pagination__btn';
        btn.textContent = '1';
        btn.onclick = () => { window.approvalCurrentPage = 1; renderApprovalList(); };
        numsCont.appendChild(btn);
        if (start > 2) {
          const dots = document.createElement('span');
          dots.textContent = '…';
          dots.style.cssText = 'display:flex;align-items:center;padding:0 4px;color:var(--clr-gray-400,#9ca3af);font-size:0.85rem;';
          numsCont.appendChild(dots);
        }
      }

      for (let p = start; p <= end; p++) {
        const btn = document.createElement('button');
        btn.className = `pagination__btn${p === window.approvalCurrentPage ? ' pagination__btn--active' : ''}`;
        btn.textContent = p;
        const pg = p;
        btn.onclick = () => { window.approvalCurrentPage = pg; renderApprovalList(); };
        numsCont.appendChild(btn);
      }

      if (end < totalPages) {
        if (end < totalPages - 1) {
          const dots = document.createElement('span');
          dots.textContent = '…';
          dots.style.cssText = 'display:flex;align-items:center;padding:0 4px;color:var(--clr-gray-400,#9ca3af);font-size:0.85rem;';
          numsCont.appendChild(dots);
        }
        const btn = document.createElement('button');
        btn.className = 'pagination__btn';
        btn.textContent = totalPages;
        btn.onclick = () => { window.approvalCurrentPage = totalPages; renderApprovalList(); };
        numsCont.appendChild(btn);
      }
    }
  }


  // Call it on load
  renderApprovalList();

  // Tab switching logic for the approval-list modal
  document.querySelectorAll('#approval-tab-nav .tab-nav__item').forEach(btn => {
    btn.addEventListener('click', () => {
      window.currentApprovalTab = btn.dataset.tab;
      window.approvalCurrentPage = 1; // reset to page 1 on tab switch
      // Reset status-filter dropdown so it re-populates with correct options
      const statusSelect = document.getElementById('approval-status-filter');
      if (statusSelect) {
        while (statusSelect.options.length > 1) statusSelect.remove(1);
        statusSelect.value = '';
      }
      // Also reset team/faculty dropdowns so they repopulate for new tab
      const teamSelect = document.getElementById('approval-team-filter');
      if (teamSelect) { while (teamSelect.options.length > 1) teamSelect.remove(1); teamSelect.value = ''; }
      const facultySelect = document.getElementById('approval-faculty-filter');
      if (facultySelect) { while (facultySelect.options.length > 1) facultySelect.remove(1); facultySelect.value = ''; }
      renderApprovalList();
    });
  });

  // Reset tab to 'pending' when the approval-list modal is closed
  const approvalListModal = document.getElementById('approval-list-modal');
  if (approvalListModal) {
    approvalListModal.querySelector('.modal-close').addEventListener('click', () => {
      // Clear search input so the next open starts with an empty search
      const searchInput = document.querySelector('#approval-list-modal .search-box__input');
      if (searchInput) searchInput.value = '';
    });
  }

  // ═══════════════════════════════════════════════════════════
  // VIEW ALL RESERVATIONS — opens history tab filtered by equipment
  // ═══════════════════════════════════════════════════════════
  const viewAllReservationsBtn = document.getElementById('view-all-reservations-btn');
  if (viewAllReservationsBtn) {
    viewAllReservationsBtn.addEventListener('click', () => {
      // 1. Get the machine name from the currently open details modal
      const detailsModal = document.getElementById('details-modal');
      const machineNameEl = detailsModal && detailsModal.querySelector('.details-sidebar__name');
      const machineName = machineNameEl ? machineNameEl.textContent.trim() : '';

      // 2. Close details modal (and explorer modal if open)
      if (detailsModal) detailsModal.classList.remove('is-open');
      const explorerModalEl = document.getElementById('explorer-modal');
      if (explorerModalEl) explorerModalEl.classList.remove('is-open');

      // 3. Open the approval list modal
      const approvalModal = document.getElementById('approval-list-modal');
      if (!approvalModal) return;
      approvalModal.classList.add('is-open');

      // 4. Switch to the 'Previously Approved / Rejected' (history) tab
      //    clicking the button triggers all existing state/dropdown resets
      const historyTabBtn = document.querySelector('#approval-tab-nav [data-tab="history"]');
      if (historyTabBtn) {
        historyTabBtn.click();
      }

      // 5. Pre-fill the search input with the equipment machine name
      const searchInput = document.querySelector('#approval-list-modal .search-box__input');
      if (searchInput && machineName) {
        searchInput.value = machineName;
      }

      // 6. Re-render the list so the search filter is applied immediately
      if (typeof renderApprovalList === 'function') {
        renderApprovalList();
      }
    });
  }

  function openApprovalDetailsModal(bookingId) {
    const map = getAllBookingDetails();
    const b = map[bookingId];
    if (!b) return;
    const modal = document.getElementById('approval-details-modal');
    if (!modal) return;
    modal.dataset.currentBookingId = bookingId;

    const isPending = b.status === 'pending' || !b.response; // pending items from getPendingApprovals

    const imagePlaceholder = modal.querySelector('.request-image-placeholder');
    if (imagePlaceholder) {
      if (b.catImage) {
        imagePlaceholder.innerHTML = `<img src="${b.catImage}" alt="${b.equipment}" style="width: 100%; height: 100%; object-fit: cover; border-radius: inherit;" />`;
        if (b.catColorClass) {
          imagePlaceholder.className = `request-image-placeholder ${b.catColorClass}`;
        }
      } else {
        imagePlaceholder.innerHTML = `<i class="fas fa-cube"></i>`;
      }
    }

    modal.querySelector('.request-title').textContent  = b.equipment;
    const reqValues = modal.querySelectorAll('.req-value');
    if (reqValues[0]) reqValues[0].innerHTML = `<i class="far fa-user mt-1"></i>
      <div><strong>${b.requester}</strong> <span class="text-muted">(${b.studentId})</span><br>
      <span class="text-sm text-muted">${b.team}</span></div>`;
    if (reqValues[1]) reqValues[1].innerHTML = `<i class="far fa-calendar-alt mt-1"></i> ${b.date}`;
    if (reqValues[2]) reqValues[2].innerHTML = `<i class="far fa-clock mt-1"></i>
      <div>${b.timeSlot}<br><span class="text-sm text-muted">(${b.duration})</span></div>`;
    if (reqValues[3]) reqValues[3].innerHTML = `<i class="far fa-clock mt-1"></i> ${b.requestedOn}`;

    const notesText = modal.querySelector('.notes-text');
    if (notesText) notesText.textContent = b.purpose;

    // Toggle between pending (action buttons) and history (status badge) modes
    const pendingActions = document.getElementById('approval-details-pending-actions');
    const historyStatus  = document.getElementById('approval-details-history-status');
    const statusBadge    = document.getElementById('approval-details-status-badge');
    const rejectionBlock = document.getElementById('approval-details-rejection-reason');
    const rejectionText  = document.getElementById('approval-details-rejection-text');

    if (isPending) {
      if (pendingActions) pendingActions.style.display = 'flex';
      if (historyStatus)  historyStatus.style.display  = 'none';
      if (rejectionBlock) rejectionBlock.style.display  = 'none';
    } else {
      if (pendingActions) pendingActions.style.display = 'none';
      if (historyStatus)  historyStatus.style.display  = 'flex';
      if (rejectionBlock) rejectionBlock.style.display  = 'none';

      if (statusBadge) {
        const isApproved = b.response === 'Approved';
        statusBadge.className = `badge ${isApproved ? 'badge--confirmed' : 'badge--rejected'}`;
        statusBadge.innerHTML = isApproved
          ? '<i class="fas fa-check" style="margin-right:4px;"></i>Approved'
          : '<i class="fas fa-times" style="margin-right:4px;"></i>Rejected';
      }

      // Show rejection reason if applicable
      if (b.response === 'Rejected' && b.rejectionReason) {
        if (rejectionBlock) rejectionBlock.style.display = 'block';
        if (rejectionText)  rejectionText.textContent = b.rejectionReason;
      }
    }

    modal.classList.add('is-open');
  }

  // Wire up the Approve/Reject buttons inside the details modal
  (function() {
    const approveBtn = document.getElementById('approval-details-approve-btn');
    const rejectBtn  = document.getElementById('approval-details-reject-btn');
    const modal      = document.getElementById('approval-details-modal');
    if (approveBtn && modal) {
      approveBtn.addEventListener('click', () => {
        const bookingId = modal.dataset.currentBookingId;
        if (bookingId && window.labDB) window.labDB.approveBooking(bookingId);
        if (typeof window.refreshUI === 'function') window.refreshUI();
        modal.classList.remove('is-open');
        renderApprovalList();
        if (typeof window.showToast === 'function') window.showToast('Request has been approved.', 'success');
      });
    }
    if (rejectBtn && modal) {
      rejectBtn.addEventListener('click', () => {
        const bookingId = modal.dataset.currentBookingId;
        window.currentRejectionBookingId = bookingId;
        modal.classList.remove('is-open');
        const rejectModal = document.getElementById('rejection-reason-modal');
        const reasonInput = document.getElementById('rejection-reason-input');
        if (rejectModal && reasonInput) {
          reasonInput.value = '';
          rejectModal.classList.add('is-open');
        }
      });
    }
  })();


  // Issue 10: Search — reset to page 1 on new search query
  const searchInput = document.querySelector('#approval-list-modal .search-box__input');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      window.approvalCurrentPage = 1;
      renderApprovalList();
    });
  }

  // Issue 11: Machine Specs — sourced live from labDB.getMachineSpec()
  function openDetailsModal(machineId) {
    const spec = window.labDB ? window.labDB.getMachineSpec(machineId) : null;
    const fallback = { status: 'available', location: '—', currentUser: '—',
      nextBooking: '—', lastMaint: '—', health: '—', firmware: '—', usageToday: '—' };
    const s = spec || fallback;
    const modal = document.getElementById('details-modal');
    if (!modal) return;
    modal.querySelector('.details-sidebar__name').textContent = machineId;
    const badge = modal.querySelector('.details-sidebar .badge');
    if (badge) {
      const statusKey = s.status.replace(' ', '-');
      const badgeSvg = window.statusIcons[statusKey] || '';
      const badgeText = s.status.charAt(0).toUpperCase() + s.status.slice(1).replace('-', ' ');
      badge.className = `badge badge--${statusKey}`;
      badge.innerHTML = `${badgeSvg}<span>${badgeText}</span>`;
    }
    const specValues = modal.querySelectorAll('.spec-row .spec-value');
    const vals = [s.currentUser, s.nextBooking, s.lastMaint, s.usageToday];
    specValues.forEach((el, i) => { if (vals[i] !== undefined) el.textContent = vals[i]; });
    const title = modal.querySelector('.details-main__title');
    if (title) title.textContent = `SCHEDULES (${machineId})`;
    const breadcrumb = modal.querySelector('.modal-subtitle');
    if (breadcrumb) {
      const catObj = window.labDB ? window.labDB.getCategoryForMachine(machineId) : null;
      const catName = catObj ? catObj.name : 'Equipment';
      breadcrumb.textContent = `All Equipment / ${catName} / ${machineId}`;
      const imgEl = modal.querySelector('#details-machine-image');
      if (imgEl) {
        if (catObj && catObj.image) {
          imgEl.src = catObj.image;
          imgEl.style.display = 'block';
        } else {
          imgEl.style.display = 'none';
        }
      }
    }
    renderDetailsMiniCalendar(machineId);
    const explorerModalEl = document.getElementById('explorer-modal');
    if (explorerModalEl) explorerModalEl.classList.remove('is-open');
    modal.classList.add('is-open');
  }

  // ═══════════════════════════════════════════════════════════
  // EQUIPMENT TYPE GROUPS — sourced from labDB for Day View columns
  // ═══════════════════════════════════════════════════════════

  const EQUIPMENT_TYPE_GROUPS = window.labDB ? window.labDB.equipmentTypeGroups : [];

  function getEquipmentGroup(machineId) {
    if (!machineId) return null;
    return EQUIPMENT_TYPE_GROUPS.find(g =>
      g.prefixes.some(p => machineId.toUpperCase().startsWith(p.toUpperCase()))
    ) || null;
  }


  // ═══════════════════════════════════════════════════════════
  // DAY VIEW RENDER
  // ═══════════════════════════════════════════════════════════


  /**
   * Given a list of bookings that may overlap in time within the same column,
   * compute {left, width} as percentages so they sit side-by-side.
   * Simple "max concurrency" layout: group by overlap clusters.
   *
   * @param {Array}  bookings           - booking objects
   * @param {Object} [effectiveTimesMap] - optional map of bookingId →
   *   { effStart: Date, effEnd: Date } for multi-day clamped rendering
   */
  function computeOverlapLayout(bookings, effectiveTimesMap = {}) {
    // Use effective times when available (multi-day clamping), else original times
    function getEffStart(b) {
      return (effectiveTimesMap[b.id] && effectiveTimesMap[b.id].effStart) || b.startTime;
    }
    function getEffEnd(b) {
      return (effectiveTimesMap[b.id] && effectiveTimesMap[b.id].effEnd) || b.endTime;
    }
    // Sort by effective start time
    const sorted = [...bookings].sort((a, b) => getEffStart(a) - getEffStart(b));
    // Assign columns within the group
    const columns = []; // each element is the furthest eff-end-time of that sub-column
    const layout = sorted.map(b => {
      const effStart = getEffStart(b);
      const effEnd   = getEffEnd(b);
      let col = columns.findIndex(endTime => endTime <= effStart);
      if (col === -1) { col = columns.length; columns.push(effEnd); }
      else { columns[col] = effEnd; }
      return { booking: b, col };
    });
    // We use the number of columns assigned as the number of "slots"
    const totalSlots = columns.length;
    return layout.map(({ booking, col }) => ({
      booking,
      left: (col / totalSlots) * 100,
      width: (1 / totalSlots) * 100,
    }));
  }

  function renderDay(anchorDate) {
    const MONTH_NAMES = ['January','February','March','April','May','June',
                        'July','August','September','October','November','December'];
    const DAY_NAMES   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

    const titleEl = document.querySelector('.calendar-toolbar__title');
    if (titleEl) {
      titleEl.textContent = `${DAY_NAMES[anchorDate.getDay()]}, ${MONTH_NAMES[anchorDate.getMonth()]} ${anchorDate.getDate()}, ${anchorDate.getFullYear()}`;
    }

    const grid = document.querySelector('.calendar-grid-week');
    if (!grid) return;
    grid.innerHTML = '';

    const TOTAL_MINS = (CALENDAR_END_H - CALENDAR_START_H) * MINS_PER_HOUR;
    const ROW_H      = 30;
    const ROW_GAP    = 4;
    const ROW_PAD    = 6;

    const dayStart   = new Date(anchorDate); dayStart.setHours(0, 0, 0, 0);
    const dayEnd     = new Date(anchorDate); dayEnd.setHours(23, 59, 59, 999);
    const calStart   = new Date(anchorDate); calStart.setHours(CALENDAR_START_H, 0, 0, 0);
    const calEnd     = new Date(anchorDate); calEnd.setHours(CALENDAR_END_H, 0, 0, 0);

    const dayBks = mockBookings.filter(b => b.startTime < dayEnd && b.endTime > dayStart && b.status !== 'rejected');

    // ── Sticky time-axis header ───────────────────────────────────────
    const hdr = document.createElement('div');
    hdr.className = 'cal-time-header-row';
    const corner = document.createElement('div');
    corner.className = 'cal-corner-cell';
    hdr.appendChild(corner);
    for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
      const tick = document.createElement('div');
      tick.className = 'cal-time-tick';
      tick.textContent = `${String(h).padStart(2,'0')}:00`;
      hdr.appendChild(tick);
    }
    grid.appendChild(hdr);

    // ── Scrollable body ───────────────────────────────────────────────
    const wrap = document.createElement('div');
    wrap.className = 'cal-body-rows-wrap';

    EQUIPMENT_TYPE_GROUPS.forEach(group => {
      const groupBks = dayBks.filter(b =>
        group.prefixes.some(p => b.machineId.toUpperCase().startsWith(p.toUpperCase()))
      );

      const dateRow = document.createElement('div');
      dateRow.className = 'cal-date-row';

      // Left label with group icon and name
      const lbl = document.createElement('div');
      lbl.className = 'cal-row-label';
      const ico = document.createElement('span');
      ico.className = 'cal-row-label__icon';
      ico.innerHTML = `<i class="fas fa-cube"></i>`;
      const txt = document.createElement('span');
      txt.className = 'cal-row-label__text';
      txt.textContent = group.label;
      lbl.appendChild(ico); lbl.appendChild(txt);
      dateRow.appendChild(lbl);

      // Timeline
      const tl = document.createElement('div');
      tl.className = 'cal-row-timeline';

      // Vertical hour grid lines
      for (let h = CALENDAR_START_H; h < CALENDAR_END_H; h++) {
        const vl = document.createElement('div');
        vl.className = 'cal-vline cal-vline--hour';
        vl.style.left = `${((h - CALENDAR_START_H) / (CALENDAR_END_H - CALENDAR_START_H)) * 100}%`;
        tl.appendChild(vl);
      }

      if (groupBks.length > 0) {
        const effMap = {};
        groupBks.forEach(b => {
          effMap[b.id] = {
            effStart: b.startTime < calStart ? calStart : b.startTime,
            effEnd:   b.endTime   > calEnd   ? calEnd   : b.endTime,
          };
        });

        const withEff = groupBks.map(b => ({ booking: b, ...effMap[b.id] }))
          .filter(x => x.effEnd > x.effStart);

        const sorted = [...withEff].sort((a, b) => a.effStart - b.effStart);
        const slotEnds = [];
        const assigned = sorted.map(item => {
          let slot = slotEnds.findIndex(e => e <= item.effStart);
          if (slot === -1) { slot = slotEnds.length; slotEnds.push(item.effEnd); }
          else { slotEnds[slot] = item.effEnd; }
          return { ...item, slot };
        });
        const nSlots = slotEnds.length;
        const minH   = ROW_PAD * 2 + nSlots * ROW_H + Math.max(0, nSlots - 1) * ROW_GAP;
        dateRow.style.minHeight = `${Math.max(48, minH)}px`;
        tl.style.minHeight = `${Math.max(48, minH)}px`;

        assigned.forEach(({ booking, effStart, effEnd, slot }) => {
          const startMins = (effStart.getHours() - CALENDAR_START_H) * 60 + effStart.getMinutes();
          const durMins   = (effEnd - effStart) / 60000;
          if (durMins <= 0) return;

          const leftPct  = (startMins / TOTAL_MINS) * 100;
          const widthPct = Math.max(0.5, (durMins / TOTAL_MINS) * 100);
          const topPx    = ROW_PAD + slot * (ROW_H + ROW_GAP);

          let tc = booking.status === 'pending' ? 'event-pending'
                 : booking.type === 'maintenance' ? 'event-maintenance'
                 : 'event-in-use';

          const blk = document.createElement('div');
          blk.className = `event-block ${tc}`;
          blk.style.top    = `${topPx}px`;
          blk.style.height = `${ROW_H}px`;
          blk.style.left   = `calc(${leftPct}% + 2px)`;
          blk.style.width  = `calc(${widthPct}% - 4px)`;
          blk.dataset.bookingId = booking.id;

          blk.addEventListener('click', () => {
            if (booking.status === 'pending') {
              const am = document.getElementById('approval-details-modal');
              if (am) {
                am.dataset.currentBookingId = booking.id;
                am.classList.add('is-open');
                if (typeof openApprovalDetailsModal === 'function') openApprovalDetailsModal(booking.id);
              }
            } else {
              if (typeof openDetailsModal === 'function') {
                openDetailsModal(booking.machineId);
              } else {
                const dm = document.getElementById('details-modal');
                if (dm) dm.classList.add('is-open');
              }
            }
          });

          const teamObj = window.labDB ? window.labDB.getTeam(booking.teamId) : null;
          const ttxt    = teamObj ? teamObj.name : (booking.type === 'maintenance' ? 'Maintenance' : booking.machineId);

          const td = document.createElement('div'); td.className = 'event-block__time';
          td.textContent = `${formatTimeLocal(booking.startTime)}\u2013${formatTimeLocal(booking.endTime)}`;
          const tit = document.createElement('div'); tit.className = 'event-block__title';
          tit.innerHTML = `<strong>${booking.machineId}</strong>`;
          const det = document.createElement('div'); det.className = 'event-block__detail';
          det.textContent = ttxt;
          const st = document.createElement('div'); st.className = 'event-block__status';
          if (booking.status === 'pending') {
            st.innerHTML = '<span>Pending</span>'; st.classList.add('event-block__status--pending');
          } else if (booking.type === 'maintenance') {
            st.innerHTML = '<span>Maintenance</span>';
          } else {
            st.innerHTML = '<span>Confirmed</span>';
          }

          blk.appendChild(td); blk.appendChild(tit); blk.appendChild(det); blk.appendChild(st);
          tl.appendChild(blk);
        });
      }

      dateRow.appendChild(tl);
      wrap.appendChild(dateRow);
    });

    grid.appendChild(wrap);

    const calMain = document.querySelector('.calendar-main');
    const oldLeg = calMain && calMain.querySelector('.calendar-legend');
    if (oldLeg) oldLeg.remove();
  }


  // ═══════════════════════════════════════════════════════════
  // VIEW SWITCHER — wire Day / Week buttons
  // ═══════════════════════════════════════════════════════════

  document.querySelectorAll('.view-switcher__btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.view-switcher__btn')
        .forEach(b => b.classList.remove('view-switcher__btn--active'));
      btn.classList.add('view-switcher__btn--active');

      currentView = btn.dataset.view || 'week';
      if (currentView === 'day') {
        renderDay(currentDayAnchor);
      } else {
        renderWeek(currentWeekStart);
      }
      // Refresh mini-cal to immediately reflect new view's highlighting
      refreshMiniCalIfMounted();
      // Re-apply filter highlighting after view switch
      if (activeSmartFilter) {
        setTimeout(() => applyFilterHighlighting(activeSmartFilter), 10);
      }
    });
  });

  // Issue 17: + New Booking button
  const newBookingBtn = document.querySelector('.calendar-toolbar__right .btn--primary');
  if (newBookingBtn) {
    newBookingBtn.addEventListener('click', () => {
      const modal = document.getElementById('new-booking-modal');
      if (modal) modal.classList.add('is-open');
    });
  }
  
  // Make openApprovalDetailsModal globally available if needed
  window.openApprovalDetailsModal = openApprovalDetailsModal;
  window.openDetailsModal = openDetailsModal;

  // ── Fullscreen toggle ──────────────────────────────────────────────
  const fsBtn = document.getElementById('fullscreen-toggle-btn');
  const calMain = document.querySelector('.calendar-main');
  if (fsBtn && calMain) {
    fsBtn.addEventListener('click', () => {
      const isFs = calMain.classList.toggle('is-fullscreen');
      const ico  = fsBtn.querySelector('i');
      if (ico) {
        ico.classList.toggle('fa-expand', !isFs);
        ico.classList.toggle('fa-compress', isFs);
      }
    });
  }

  // Populate the maintenance modal equipment dropdown from labDB on init
  populateMaintenanceEquipmentDropdown();

  // Initial explorer sidebar render (in case modal was pre-opened)
  renderExplorerSidebar();

  // Also re-render sidebar sidebar calendar filter labels from labDB
  // (handled by sidebar script; labDB is globally available for it to read)


});

/* =============================================
   MATERIAL DESIGN CLOCK TIME PICKER — VANILLA JS
   ============================================= */
(function() {
    const overlay  = document.getElementById('mtpOverlay');
    const clock    = document.getElementById('mtpClock');
    const hand     = document.getElementById('mtpHand');
    const hourSeg  = document.getElementById('mtpHourSeg');
    const minSeg   = document.getElementById('mtpMinSeg');
    const amEl     = document.getElementById('mtpAM');
    const pmEl     = document.getElementById('mtpPM');

    let _mode       = 'hour';  // 'hour' | 'min'
    let _hour       = 12;
    let _min        = 0;
    let _ampm       = 'AM';
    let _targetId   = null;

    window.openMTP = function(target) {
        _targetId = target;
        const existing = document.getElementById(_targetId).value;
        if (existing) {
            const parsed = parseTime12(existing);
            if (parsed) { _hour = parsed.h12; _min = parsed.m; _ampm = parsed.ampm; }
        } else { _hour = 12; _min = 0; _ampm = 'AM'; }
        _mode = 'hour';
        renderClock();
        overlay.classList.add('active');
    };

    window.closeMTP = function() { overlay.classList.remove('active'); };

    window.confirmMTP = function() {
        const h = String(_hour).padStart(2,'0');
        const m = String(_min).padStart(2,'0');
        document.getElementById(_targetId).value = `${h}:${m} ${_ampm}`;
        overlay.classList.remove('active');
    };

    window.mtpSetAMPM = function(val) {
        _ampm = val;
        amEl.classList.toggle('active', val === 'AM');
        pmEl.classList.toggle('active', val === 'PM');
    };

    function parseTime12(str) {
        const m = str.match(/(\d+):(\d+)\s*(AM|PM)/i);
        if (!m) return null;
        return { h12: parseInt(m[1]), m: parseInt(m[2]), ampm: m[3].toUpperCase() };
    }

    hourSeg.addEventListener('click', () => { _mode = 'hour'; hourSeg.classList.add('active'); minSeg.classList.remove('active'); renderClock(); });
    minSeg.addEventListener('click',  () => { _mode = 'min';  minSeg.classList.add('active'); hourSeg.classList.remove('active'); renderClock(); });

    function renderClock() {
        // Header
        hourSeg.textContent = String(_hour).padStart(2,'0');
        minSeg.textContent  = String(_min).padStart(2,'0');
        amEl.classList.toggle('active', _ampm === 'AM');
        pmEl.classList.toggle('active', _ampm === 'PM');

        // Clear old numbers
        clock.querySelectorAll('.mtp-clock-num').forEach(n => n.remove());

        const cx = 128, cy = 128, r = 104;
        let count, values, current;

        if (_mode === 'hour') {
            count  = 12;
            values = [12,1,2,3,4,5,6,7,8,9,10,11];
            current = _hour;
        } else {
            count  = 12;
            values = [0,5,10,15,20,25,30,35,40,45,50,55];
            current = Math.round(_min / 5) * 5;
        }

        for (let i = 0; i < count; i++) {
            const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
            const x = cx + r * Math.cos(angle);
            const y = cy + r * Math.sin(angle);
            const num = document.createElement('div');
            num.className = 'mtp-clock-num' + (values[i] === current ? ' selected' : '');
            num.textContent = _mode === 'min' ? String(values[i]).padStart(2,'0') : values[i];
            num.style.left = x + 'px';
            num.style.top  = y + 'px';
            num.addEventListener('click', (e) => { e.stopPropagation(); pickValue(values[i]); });
            clock.appendChild(num);
        }

        // Hand
        let handAngle;
        if (_mode === 'hour') {
            const idx = values.indexOf(current);
            handAngle = idx < 0 ? 0 : (idx / 12) * 360;
        } else {
            handAngle = (current / 60) * 360;
        }
        const handLen = r - 14;
        hand.style.height  = handLen + 'px';
        hand.style.transform = `translateX(-50%) rotate(${handAngle}deg)`;
    }

    function pickValue(val) {
        if (_mode === 'hour') {
            _hour = val;
            // Auto-switch to minute
            setTimeout(() => { _mode = 'min'; minSeg.classList.add('active'); hourSeg.classList.remove('active'); renderClock(); }, 200);
        } else {
            _min = val;
        }
        renderClock();
    }

    // Drag on clock
    let dragging = false;
    clock.addEventListener('mousedown', startDrag);
    clock.addEventListener('touchstart', startDrag, { passive: true });
    document.addEventListener('mousemove', onDrag);
    document.addEventListener('touchmove', onDrag, { passive: true });
    document.addEventListener('mouseup', () => { dragging = false; });
    document.addEventListener('touchend', () => { dragging = false; });

    function startDrag(e) { dragging = true; onDrag(e); }
    function onDrag(e) {
        if (!dragging) return;
        const rect = clock.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        const px = (e.touches ? e.touches[0].clientX : e.clientX) - cx;
        const py = (e.touches ? e.touches[0].clientY : e.clientY) - cy;
        let angle = Math.atan2(py, px) * 180 / Math.PI + 90;
        if (angle < 0) angle += 360;
        if (_mode === 'hour') {
            const rawH = Math.round(angle / 30) % 12 || 12;
            _hour = rawH;
        } else {
            const rawM = Math.round(angle / 6) % 60;
            _min = rawM;
        }
        renderClock();
    }

    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeMTP(); });
})();

// Material Date Picker (MDP) Logic
(function() {
    const overlay = document.getElementById('mdpOverlay');
    const calendarGrid = document.getElementById('mdpCalendarGrid');
    const yearGrid = document.getElementById('mdpYearGrid');
    const yearLabel = document.getElementById('mdpYearLabel');
    const dateLabel = document.getElementById('mdpDateLabel');
    const monthYearLabel = document.getElementById('mdpMonthYear');
    const monthNav = document.querySelector('.mdp-month-nav');

    let _targetId = null;
    let _nextTarget = null;
    let _selectedDate = new Date();
    let _viewDate = new Date();
    let _mode = 'date'; // 'date' | 'year'

    window.openMDP = function(target, nextTarget) {
        _targetId = target;
        _nextTarget = nextTarget;
        const existing = document.getElementById(_targetId).value;
        if (existing) {
            // parse YYYY-MM-DD correctly in local time
            const parts = existing.split('-');
            if (parts.length === 3) {
                _selectedDate = new Date(parts[0], parts[1] - 1, parts[2]);
            } else {
                _selectedDate = new Date();
            }
        } else {
            _selectedDate = new Date();
        }
        _viewDate = new Date(_selectedDate);
        _mode = 'date';
        renderMDP();
        overlay.classList.add('active');
    };

    window.closeMDP = function() { overlay.classList.remove('active'); };

    window.confirmMDP = function() {
        const y = _selectedDate.getFullYear();
        const m = String(_selectedDate.getMonth() + 1).padStart(2, '0');
        const d = String(_selectedDate.getDate()).padStart(2, '0');
        const el = document.getElementById(_targetId);
        if (el) {
            el.value = `${y}-${m}-${d}`;
            el.dispatchEvent(new Event('change'));
        }
        overlay.classList.remove('active');
        if (_nextTarget) {
            if (window.openMTP) window.openMTP(_nextTarget);
        }
    };

    window.mdpSetMode = function(mode) {
        _mode = mode;
        renderMDP();
    };

    window.mdpChangeMonth = function(delta) {
        _viewDate.setMonth(_viewDate.getMonth() + delta);
        renderMDP();
    };

    function renderMDP() {
        yearLabel.textContent = _selectedDate.getFullYear();
        yearLabel.style.opacity = _mode === 'year' ? '1' : '0.7';
        dateLabel.style.opacity = _mode === 'date' ? '1' : '0.7';

        const options = { weekday: 'short', month: 'short', day: 'numeric' };
        dateLabel.textContent = _selectedDate.toLocaleDateString('en-US', options);

        if (_mode === 'year') {
            calendarGrid.style.display = 'none';
            monthNav.style.display = 'none';
            yearGrid.style.display = 'grid';
            renderYears();
        } else {
            calendarGrid.style.display = 'grid';
            monthNav.style.display = 'flex';
            yearGrid.style.display = 'none';
            renderCalendar();
        }
    }

    function renderYears() {
        yearGrid.innerHTML = '';
        const currentYear = new Date().getFullYear();
        for (let i = currentYear - 10; i <= currentYear + 10; i++) {
            const el = document.createElement('div');
            el.className = 'mdp-year-item';
            if (i === _selectedDate.getFullYear()) el.classList.add('selected');
            el.textContent = i;
            el.onclick = () => {
                _selectedDate.setFullYear(i);
                _viewDate.setFullYear(i);
                _mode = 'date';
                renderMDP();
            };
            yearGrid.appendChild(el);
        }
        setTimeout(() => {
            const selected = yearGrid.querySelector('.selected');
            if (selected) {
                selected.scrollIntoView({ block: 'center' });
            }
        }, 10);
    }

    function renderCalendar() {
        // Keep weekdays
        calendarGrid.innerHTML = `
            <div class="mdp-weekday">S</div><div class="mdp-weekday">M</div><div class="mdp-weekday">T</div>
            <div class="mdp-weekday">W</div><div class="mdp-weekday">T</div><div class="mdp-weekday">F</div><div class="mdp-weekday">S</div>
        `;

        const monthOpts = { month: 'long', year: 'numeric' };
        monthYearLabel.textContent = _viewDate.toLocaleDateString('en-US', monthOpts);

        const year = _viewDate.getFullYear();
        const month = _viewDate.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        for (let i = 0; i < firstDay; i++) {
            const el = document.createElement('div');
            el.className = 'mdp-day empty';
            calendarGrid.appendChild(el);
        }

        for (let i = 1; i <= daysInMonth; i++) {
            const el = document.createElement('div');
            el.className = 'mdp-day';
            el.textContent = i;
            if (
                year === _selectedDate.getFullYear() &&
                month === _selectedDate.getMonth() &&
                i === _selectedDate.getDate()
            ) {
                el.classList.add('selected');
            }
            el.onclick = () => {
                _selectedDate = new Date(year, month, i);
                renderMDP();
            };
            calendarGrid.appendChild(el);
        }
    }

    if (overlay) {
        overlay.addEventListener('click', (e) => { if (e.target === overlay) closeMDP(); });
    }
})();

// Toast Notification Utility
window.showToast = function(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    
    let iconClass = 'fas fa-check-circle';
    if (type === 'danger') iconClass = 'fas fa-exclamation-circle';
    else if (type === 'warning') iconClass = 'fas fa-exclamation-triangle';
    else if (type === 'info') iconClass = 'fas fa-info-circle';

    toast.innerHTML = `
        <i class="${iconClass}"></i>
        <div class="toast-message">${message}</div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;

    container.appendChild(toast);

    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => removeToast(toast));

    setTimeout(() => {
        removeToast(toast);
    }, 4000);
};

function removeToast(toast) {
    if (toast.classList.contains('fade-out')) return;
    toast.classList.add('fade-out');
    toast.addEventListener('animationend', () => {
        toast.remove();
    });
}
(function() {
    const confirmRejectBtn = document.getElementById('confirm-rejection-btn');
    if (confirmRejectBtn) {
        confirmRejectBtn.addEventListener('click', () => {
            const reasonInput = document.getElementById('rejection-reason-input');
            const reason = reasonInput ? reasonInput.value.trim() : '';
            if (!reason) {
                // If it's empty, we might want to alert or just let the required attribute handle it (but it's not a form)
                if (typeof window.showToast === 'function') window.showToast('Please provide a reason for rejection.', 'danger');
                return;
            }
            
            if (window.labDB && window.currentRejectionBookingId) {
                // Pass the reason to rejectBooking so history records it
                window.labDB.rejectBooking(window.currentRejectionBookingId, reason);
            }
            
            const rejectModal = document.getElementById('rejection-reason-modal');
            if (rejectModal) {
                rejectModal.classList.remove('is-open');
            }
            
            if (typeof window.refreshUI === 'function') window.refreshUI();
            
            if (typeof renderApprovalList === 'function') {
                renderApprovalList();
            } else if (typeof window.renderApprovalList === 'function') {
                window.renderApprovalList();
            }
            
            document.dispatchEvent(new Event('bookingRejected'));
            
            if (typeof window.showToast === 'function') {
                window.showToast('Request has been rejected.', 'danger');
            }
            
            window.currentRejectionBookingId = null;
        });
    }
})();
