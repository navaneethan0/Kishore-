/* ============================================================
   GLOBAL HEADER — Notifications + Profile Modal
   Shared across ALL portal pages.
   Must be loaded LAST (after all page-specific JS).
   ============================================================ */

(function () {
    // Default notification data shown on every page
    var DEFAULT_NOTIFICATIONS = [
        { id: 1, message: 'New deadline approaching for Team Alpha', time: '2 hours ago', read: false, type: 'deadline' },
        { id: 2, message: 'Ticket requires attention', time: '5 hours ago', read: false, type: 'ticket' },
        { id: 3, message: 'Team Beta submitted Stage 4 report', time: '1 day ago', read: true, type: 'project' }
    ];

    var iconColors = {
        deadline: { bg: '#fef2f2', color: '#ef4444' },
        ticket: { bg: '#fffbeb', color: '#f59e0b' },
        project: { bg: '#dbeafe', color: '#3b82f6' }
    };

    function getNotifications() {
        try {
            if (window.__RPL_DB__ && window.__RPL_DB__.notifications) {
                return window.__RPL_DB__.notifications;
            }
        } catch (e) { }
        return DEFAULT_NOTIFICATIONS;
    }

    function renderNotificationList(list, notifications) {
        if (!list) return;

        if (!notifications || notifications.length === 0) {
            list.innerHTML = '<li style="padding:16px;color:#94a3b8;font-size:13px;text-align:center;">No notifications</li>';
            return;
        }

        list.innerHTML = notifications.map(function (n) {
            var ic = iconColors[n.type] || iconColors.project;
            return '<li class="notification-item ' + (n.read ? '' : 'unread') + '" data-id="' + n.id + '" style="display:flex;gap:12px;padding:14px 16px;border-bottom:1px solid #f1f5f9;cursor:pointer;transition:background 0.2s;">' +
                '<div style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:' + ic.bg + ';color:' + ic.color + ';">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' +
                '</div>' +
                '<div style="display:flex;flex-direction:column;gap:3px;">' +
                '<p style="font-size:13px;color:#1e293b;line-height:1.4;margin:0;">' + n.message + '</p>' +
                '<span style="font-size:11px;color:#94a3b8;">' + n.time + '</span>' +
                '</div>' +
                '</li>';
        }).join('');

        // Click to mark individual as read
        list.querySelectorAll('.notification-item').forEach(function (item) {
            item.addEventListener('click', function () {
                var id = parseInt(item.dataset.id, 10);
                var notifications = getNotifications();
                var notif = notifications.find(function (n) { return n.id === id; });
                if (notif) {
                    notif.read = true;
                    item.classList.remove('unread');
                    item.style.background = '';
                    updateBadge(notifications);
                }
            });
        });
    }

    function updateBadge(notifications) {
        var badge = document.getElementById('notificationBadge');
        if (!badge) return;
        var unread = notifications.filter(function (n) { return !n.read; }).length;
        if (unread > 0) {
            badge.textContent = unread;
            badge.style.display = '';
        } else {
            badge.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {

        /* ---- Notification Dropdown ---- */
        var notifBtn = document.getElementById('notificationBtn');
        var notifDropdown = document.getElementById('notificationDropdown');
        var notifList = document.getElementById('notificationList');
        var markReadBtn = document.getElementById('markAllReadBtn');

        if (notifBtn && notifDropdown) {
            var notifications = getNotifications();

            // Populate the list
            renderNotificationList(notifList, notifications);
            updateBadge(notifications);

            // Toggle dropdown on bell click
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                var isOpen = notifDropdown.classList.contains('active');
                // Close all other dropdowns first
                document.querySelectorAll('.notification-dropdown.active').forEach(function (d) {
                    d.classList.remove('active');
                });
                if (!isOpen) {
                    notifDropdown.classList.add('active');
                }
            });

            // Prevent clicks inside dropdown from closing it
            notifDropdown.addEventListener('click', function (e) {
                e.stopPropagation();
            });

            // Close when clicking elsewhere
            document.addEventListener('click', function () {
                notifDropdown.classList.remove('active');
            });

            // Mark all read
            if (markReadBtn) {
                markReadBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    notifications.forEach(function (n) { n.read = true; });
                    renderNotificationList(notifList, notifications);
                    updateBadge(notifications);
                });
            }
        }

        /* ---- Profile Modal ---- */
        var profileBtn = document.getElementById('profileBtn');
        var profileModal = document.getElementById('globalProfileModal');
        var closeBtn = document.getElementById('closeGlobalProfileModal');
        var cancelBtn = document.getElementById('cancelGlobalProfileModal');

        function openProfile() {
            if (profileModal) {
                profileModal.classList.add('active');
            }
        }

        function closeProfile() {
            if (profileModal) {
                profileModal.classList.remove('active');
            }
        }

        if (profileBtn) {
            profileBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                openProfile();
            });
        }

        if (closeBtn) closeBtn.addEventListener('click', closeProfile);
        if (cancelBtn) cancelBtn.addEventListener('click', closeProfile);

        if (profileModal) {
            profileModal.addEventListener('click', function (e) {
                if (e.target === profileModal) closeProfile();
            });
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeProfile();
        });

        /* ---- Re-render Lucide icons ---- */
        if (window.lucide && window.lucide.createIcons) {
            window.lucide.createIcons();
        }
    });

})();

    // ---- Sidebar Unified JS ---- //
    function initGlobalSidebar() {
        var hamburgerBtn = document.getElementById('hamburgerBtn');
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('sidebarOverlay');
        
        
        // Auto-expand dropdowns that contain an initially active sub-item
        document.querySelectorAll('.dropdown-menu, .sub-dropdown-menu').forEach(function(menu) {
            if (menu.querySelector('.sub-nav-item.active')) {
                menu.classList.add('active');
                if (menu.id) {
                    var toggle = document.querySelector('[aria-controls="' + menu.id + '"]');
                    if (toggle) {
                        toggle.classList.add('active');
                        toggle.setAttribute('aria-expanded', 'true');
                    }
                }
            }
        });
if(hamburgerBtn && sidebar && overlay) {
            hamburgerBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('open');
                overlay.classList.toggle('active');
            });
            overlay.addEventListener('click', function() {
                sidebar.classList.remove('open');
                overlay.classList.remove('active');
            });
        }

        // We use event delegation on the sidebar for all nav item interactions.
        if (sidebar) {
            sidebar.addEventListener('click', function(e) {
                var clickedToggle = e.target.closest('.dropdown-toggle, .sub-dropdown-toggle');
                var clickedLink = e.target.closest('.nav-item'); // This matches both normal links and toggles (since toggles have .nav-item)
                
                if (clickedToggle) {
                    var isSubToggle = clickedToggle.classList.contains('sub-dropdown-toggle');
                    
                    var targetId = clickedToggle.getAttribute('aria-controls');
                    var menu = document.getElementById(targetId);
                    if (!menu && clickedToggle.parentElement) {
                        menu = clickedToggle.parentElement.querySelector('.dropdown-menu, .sub-dropdown-menu');
                    }
                    
                    var wasActive = clickedToggle.classList.contains('active');
                    
                    if (!isSubToggle) {
                        // Close ALL top-level and sub-dropdown menus
                        document.querySelectorAll('.dropdown-toggle').forEach(function(btn) {
                            btn.classList.remove('active');
                            btn.setAttribute('aria-expanded', 'false');
                        });
                        document.querySelectorAll('.dropdown-menu').forEach(function(m) { m.classList.remove('active'); });
                        
                        document.querySelectorAll('.sub-dropdown-toggle').forEach(function(btn) {
                            btn.classList.remove('active');
                            btn.setAttribute('aria-expanded', 'false');
                        });
                        document.querySelectorAll('.sub-dropdown-menu').forEach(function(m) { m.classList.remove('active'); });

                        // Remove active class from any standalone top-level links (like Trainee List)
                        // so they don't remain highlighted when a dropdown is manipulated.
                        document.querySelectorAll('.nav-item').forEach(function(item) {
                            // Leave sub-nav items alone (they will be hidden anyway if parent closes)
                            if (!item.classList.contains('sub-nav-item') && !item.classList.contains('dropdown-toggle')) {
                                item.classList.remove('active');
                            }
                        });
                    } else {
                        // Only close other sub-dropdowns
                        document.querySelectorAll('.sub-dropdown-toggle').forEach(function(btn) {
                            btn.classList.remove('active');
                            btn.setAttribute('aria-expanded', 'false');
                        });
                        document.querySelectorAll('.sub-dropdown-menu').forEach(function(m) { m.classList.remove('active'); });
                    }

                    if (!wasActive) {
                        clickedToggle.classList.add('active');
                        clickedToggle.setAttribute('aria-expanded', 'true');
                        if (menu) menu.classList.add('active');
                    }
                } 
                else if (clickedLink && !clickedToggle) {
                    // Clicked a normal link without dropdown (e.g. Trainee List or Asset Management)
                    var isSubLink = clickedLink.classList.contains('sub-nav-item');
                    
                    if (isSubLink) {
                        // Keep its own highlight, clear other top-level normal items
                        document.querySelectorAll('.nav-item').forEach(function(item) {
                            if (!item.classList.contains('sub-nav-item') && !item.classList.contains('dropdown-toggle')) {
                                item.classList.remove('active');
                            }
                        });
                        // Allow its parent dropdown-toggle to stay active
                    } else {
                        // Clicked a top-level link (e.g., Trainee List). 
                        // Strip active from EVERYTHING else.
                        document.querySelectorAll('.nav-item').forEach(function(item) {
                            item.classList.remove('active');
                        });
                        document.querySelectorAll('.dropdown-toggle').forEach(function(btn) {
                            btn.setAttribute('aria-expanded', 'false');
                        });
                        document.querySelectorAll('.dropdown-menu, .sub-dropdown-menu').forEach(function(m) { 
                            m.classList.remove('active'); 
                        });
                    }
                    clickedLink.classList.add('active');
                }
            });
        }
    }
    
    // Attach to DOMContentLoaded (since we are injecting inside the existing IIFE)
    document.addEventListener('DOMContentLoaded', initGlobalSidebar);
