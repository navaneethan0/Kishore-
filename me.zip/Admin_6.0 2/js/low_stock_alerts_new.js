/* ============================================================
   LOW STOCK ALERT — NEW UI JAVASCRIPT
   Handles: data, KPI cards, table render, filters, search,
            detail modal, confirm modal, Received→Resolved workflow,
            localStorage persistence, sidebar/hamburger wiring
   ============================================================ */

/* ---- STORAGE KEY ---- */
const LSA_STORAGE_KEY = 'lsa_requests_v2';

/* ---- SEED DATA (used only if localStorage is empty) ---- */
const LSA_SEED_DATA = [
    {
        id: 'LSR-001',
        component: 'IR Proximity Sensor',
        category: 'Sensors',
        requestedQty: 44,
        availableQty: 0,
        lab: 'Embedded Lab',
        raisedBy: 'Dr. Priya Sharma',
        facultyId: 'FAC-001',
        raisedDate: '10 Jul 2026',
        priority: 'Critical',
        status: 'Received',
        notes: 'Urgent replacement required for student projects',
        componentMeta: 'Sensors \u2022 Electronics Lab \u2022 Available 0 pcs'
    },
    {
        id: 'LSR-002',
        component: 'Linear Rod 8mm (300mm)',
        category: 'Mechanical',
        requestedQty: 42,
        availableQty: 2,
        lab: 'Mechanical Lab',
        raisedBy: 'Dr. Aravind Kumar',
        facultyId: 'FAC-002',
        raisedDate: '09 Jul 2026',
        priority: 'Critical',
        status: 'Received',
        notes: 'Required for ongoing projects on CNC machines.',
        componentMeta: 'Mechanical \u2022 Mechanical Lab \u2022 Available 2 pcs'
    },
    {
        id: 'LSR-003',
        component: 'Timing Belt GT2 (1m)',
        category: 'Mechanical',
        requestedQty: 95,
        availableQty: 1,
        lab: 'Manufacturing Lab',
        raisedBy: 'Dr. Aravind Kumar',
        facultyId: 'FAC-002',
        raisedDate: '09 Jul 2026',
        priority: 'Critical',
        status: 'Received',
        notes: 'Belts wear out quickly during high-volume runs.',
        componentMeta: 'Mechanical \u2022 Manufacturing Lab \u2022 Available 1 pcs'
    },
    {
        id: 'LSR-004',
        component: 'PLA Filament 1KG (White)',
        category: '3D Printing',
        requestedQty: 20,
        availableQty: 1,
        lab: 'IoT Lab',
        raisedBy: 'Dr. Karthik S',
        facultyId: 'FAC-003',
        raisedDate: '08 Jul 2026',
        priority: 'High',
        status: 'Pending',
        notes: 'No additional notes provided.',
        componentMeta: '3D Printing \u2022 IoT Lab \u2022 Available 1 pcs'
    },
    {
        id: 'LSR-005',
        component: 'Raspberry Pi 4 Model B',
        category: 'Electronics',
        requestedQty: 15,
        availableQty: 0,
        lab: 'AI Lab',
        raisedBy: 'Dr. Karthik S',
        facultyId: 'FAC-003',
        raisedDate: '11 Jul 2026',
        priority: 'Critical',
        status: 'Received',
        notes: 'Essential for AI project demos next week.',
        componentMeta: 'Electronics \u2022 AI Lab \u2022 Available 0 pcs'
    },
    {
        id: 'LSR-006',
        component: 'Laser Cutter Lens (Focal length 50.8mm)',
        category: 'Fabrication',
        requestedQty: 2,
        availableQty: 0,
        lab: 'Fabrication Lab',
        raisedBy: 'Dr. Lakshmi N',
        facultyId: 'FAC-004',
        raisedDate: '05 Jul 2026',
        priority: 'High',
        status: 'Received',
        notes: 'Lens was cracked and needs urgent replacement.',
        componentMeta: 'Fabrication \u2022 Fabrication Lab \u2022 Available 0 pcs'
    },
    {
        id: 'LSR-007',
        component: 'NEMA 17 Stepper Motor',
        category: 'Actuators',
        requestedQty: 25,
        availableQty: 4,
        lab: 'Mechanical Lab',
        raisedBy: 'Dr. Aravind Kumar',
        facultyId: 'FAC-002',
        raisedDate: '10 Jul 2026',
        priority: 'Critical',
        status: 'Pending',
        notes: 'No additional notes provided.',
        componentMeta: 'Actuators \u2022 Mechanical Lab \u2022 Available 4 pcs'
    },
    {
        id: 'LSR-008',
        component: 'ESP32 DevKit V1',
        category: 'Electronics',
        requestedQty: 30,
        availableQty: 3,
        lab: 'IoT Lab',
        raisedBy: 'Dr. Karthik S',
        facultyId: 'FAC-003',
        raisedDate: '07 Jul 2026',
        priority: 'High',
        status: 'Resolved',
        notes: 'Used in batch of IoT student projects.',
        componentMeta: 'Electronics \u2022 IoT Lab \u2022 Available 3 pcs'
    },
    {
        id: 'LSR-009',
        component: 'Servo Motor SG90',
        category: 'Actuators',
        requestedQty: 50,
        availableQty: 5,
        lab: 'Embedded Lab',
        raisedBy: 'Dr. Priya Sharma',
        facultyId: 'FAC-001',
        raisedDate: '06 Jul 2026',
        priority: 'High',
        status: 'Resolved',
        notes: 'High usage in robotics workshop.',
        componentMeta: 'Actuators \u2022 Embedded Lab \u2022 Available 5 pcs'
    },
    {
        id: 'LSR-010',
        component: 'Filament PLA (1KG, White)',
        category: '3D Printing',
        requestedQty: 10,
        availableQty: 2,
        lab: 'Fabrication Lab',
        raisedBy: 'Dr. Lakshmi N',
        facultyId: 'FAC-004',
        raisedDate: '11 Jul 2026',
        priority: 'High',
        status: 'Pending',
        notes: 'No additional notes provided.',
        componentMeta: '3D Printing \u2022 Fabrication Lab \u2022 Available 2 pcs'
    }
];

/* ---- LOAD / SAVE from localStorage ---- */
function lsaLoadData() {
    try {
        const saved = localStorage.getItem(LSA_STORAGE_KEY);
        if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length) return parsed;
        }
    } catch (e) { /* ignore */ }
    lsaSaveData(LSA_SEED_DATA);
    return JSON.parse(JSON.stringify(LSA_SEED_DATA));
}

function lsaSaveData(data) {
    try {
        localStorage.setItem(LSA_STORAGE_KEY, JSON.stringify(data));
    } catch (e) { /* ignore */ }
}

/* ---- STATE ---- */
let lsaRequests = lsaLoadData();
let lsaCurrentId = null;
let lsaPendingAction = null;

const lsaState = {
    search: '',
    lab: 'all',
    status: 'all'
};

/* ---- HELPERS ---- */
function lsaGetById(id) {
    return lsaRequests.find(r => r.id === id) || null;
}

function lsaGetLabs() {
    return [...new Set(lsaRequests.map(r => r.lab))].sort();
}

function lsaFilteredRequests() {
    return lsaRequests.filter(r => {
        const s = lsaState.search.toLowerCase();
        const matchSearch = !s ||
            r.id.toLowerCase().includes(s) ||
            r.component.toLowerCase().includes(s) ||
            r.lab.toLowerCase().includes(s) ||
            r.raisedBy.toLowerCase().includes(s);
        const matchLab = lsaState.lab === 'all' || r.lab === lsaState.lab;
        const matchStatus = lsaState.status === 'all' || r.status === lsaState.status;
        return matchSearch && matchLab && matchStatus;
    });
}

/* ---- KPI CARDS ---- */
function lsaRenderKpis() {
    const total = lsaRequests.length;
    const pending = lsaRequests.filter(r => r.status === 'Pending').length;
    const received = lsaRequests.filter(r => r.status === 'Received').length;
    const resolved = lsaRequests.filter(r => r.status === 'Resolved').length;

    document.getElementById('lsaKpiTotal').textContent = total;
    document.getElementById('lsaKpiPending').textContent = pending;
    document.getElementById('lsaKpiReceived').textContent = received;
    document.getElementById('lsaKpiResolved').textContent = resolved;

    const badge = document.getElementById('lsaNotifBadge');
    if (badge) badge.textContent = received;
}

/* ---- POPULATE LAB FILTER ---- */
function lsaPopulateLabFilter() {
    const sel = document.getElementById('lsaLabFilter');
    const labs = lsaGetLabs();
    while (sel.options.length > 1) sel.remove(1);
    labs.forEach(lab => {
        const opt = document.createElement('option');
        opt.value = lab;
        opt.textContent = lab;
        sel.appendChild(opt);
    });
}

/* ---- RENDER TABLE ---- */
function lsaRenderTable() {
    const tbody = document.getElementById('lsaTableBody');
    const filtered = lsaFilteredRequests();

    if (!filtered.length) {
        tbody.innerHTML = '<tr class="lsa-empty-row"><td colspan="10">No records found.</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map((r, idx) => {
        const cls = r.status.toLowerCase();
        return '<tr>' +
            '<td class="lsa-td-slno">' + (idx + 1) + '</td>' +
            '<td class="lsa-td-reqid">' + r.id + '</td>' +
            '<td>' + r.component + '</td>' +
            '<td class="lsa-td-qty">' + r.requestedQty + '</td>' +
            '<td class="lsa-td-qty">' + r.availableQty + '</td>' +
            '<td>' + r.lab + '</td>' +
            '<td>' + r.raisedBy + '</td>' +
            '<td>' + r.raisedDate + '</td>' +
            '<td><span class="lsa-status-badge ' + cls + '">' + r.status + '</span></td>' +
            '<td><button class="lsa-view-btn" onclick="lsaOpenDetail(\'' + r.id + '\')">View</button></td>' +
            '</tr>';
    }).join('');
}

/* ---- RENDER ALL ---- */
function lsaRenderAll() {
    lsaRenderKpis();
    lsaRenderTable();
}

/* ---- DETAIL MODAL ---- */
function lsaOpenDetail(id) {
    const r = lsaGetById(id);
    if (!r) return;
    lsaCurrentId = id;

    document.getElementById('lsaDetailInfo').innerHTML =
        '<p>Procurement request raised by Lab Incharge</p>' +
        '<p>Request ID: ' + r.id + '</p>' +
        '<p>Raised By: ' + r.raisedBy + '</p>' +
        '<p>Faculty ID: ' + r.facultyId + '</p>' +
        '<p>Lab: ' + r.lab + '</p>' +
        '<p>Raised Date: ' + r.raisedDate + '</p>' +
        '<p>Priority: <span class="lsa-priority-badge ' + r.priority.toLowerCase() + '">' + r.priority + '</span></p>' +
        '<p>Status: &nbsp;<strong>' + r.status + '</strong></p>';

    document.getElementById('lsaComponentCard').innerHTML =
        '<div class="lsa-component-main">' +
        '<div class="lsa-component-name">' + r.component + '</div>' +
        '<div class="lsa-component-meta">' + r.componentMeta + '</div>' +
        '</div>' +
        '<div class="lsa-component-qty">' +
        '<div class="qty-num">' + r.requestedQty + '</div>' +
        '<div class="qty-label">ORDER QTY</div>' +
        '</div>';

    document.getElementById('lsaNotesText').textContent = r.notes || 'No additional notes provided.';

    const actionBtn = document.getElementById('lsaActionBtn');
    if (r.status === 'Pending') {
        actionBtn.textContent = 'Received';
        actionBtn.className = 'lsa-btn-action received-action';
        actionBtn.disabled = false;
    } else if (r.status === 'Received') {
        actionBtn.textContent = 'Resolved';
        actionBtn.className = 'lsa-btn-action resolved-action';
        actionBtn.disabled = false;
    } else {
        actionBtn.textContent = 'Resolved';
        actionBtn.className = 'lsa-btn-action disabled-action';
        actionBtn.disabled = true;
    }

    document.getElementById('lsaDetailModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function lsaCloseDetail() {
    document.getElementById('lsaDetailModal').classList.remove('active');
    document.body.style.overflow = '';
    lsaCurrentId = null;
}

/* ---- CONFIRM MODAL ---- */
function lsaOpenConfirm(actionType) {
    lsaPendingAction = actionType;
    document.getElementById('lsaConfirmMsg').textContent =
        actionType === 'received' ? 'Mark this request as Received?' : 'Mark this request as Resolved?';
    document.getElementById('lsaConfirmOverlay').classList.add('active');
}

function lsaCloseConfirm() {
    document.getElementById('lsaConfirmOverlay').classList.remove('active');
    lsaPendingAction = null;
}

/* ---- STATUS WORKFLOW ---- */
function lsaApplyAction() {
    if (!lsaCurrentId || !lsaPendingAction) return;
    const r = lsaGetById(lsaCurrentId);
    if (!r) return;

    if (lsaPendingAction === 'received' && r.status === 'Pending') {
        r.status = 'Received';
        lsaShowToast(r.id + ' marked as Received.');
    } else if (lsaPendingAction === 'resolved' && r.status === 'Received') {
        r.status = 'Resolved';
        lsaShowToast(r.id + ' marked as Resolved.');
    }

    lsaSaveData(lsaRequests);
    lsaCloseConfirm();
    lsaCloseDetail();
    lsaRenderAll();
}

/* ---- TOAST ---- */
let lsaToastTimer;
function lsaShowToast(msg) {
    const t = document.getElementById('lsaToast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(lsaToastTimer);
    lsaToastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

/* ---- SIDEBAR HELPERS ---- */
function lsaInitSidebar() {
    // Main dropdown toggles
    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const menuId = btn.getAttribute('aria-controls');
            const menu = document.getElementById(menuId);
            const icon = btn.querySelector('.dropdown-icon');
            const isOpen = btn.getAttribute('aria-expanded') === 'true';

            // Close sibling menus
            document.querySelectorAll('.dropdown-toggle').forEach(other => {
                if (other !== btn) {
                    other.setAttribute('aria-expanded', 'false');
                    other.classList.remove('active');
                    const otherMenu = document.getElementById(other.getAttribute('aria-controls'));
                    if (otherMenu) otherMenu.classList.remove('active');
                    const oi = other.querySelector('.dropdown-icon');
                    if (oi) oi.style.transform = '';
                }
            });

            btn.setAttribute('aria-expanded', String(!isOpen));
            btn.classList.toggle('active', !isOpen);
            if (menu) menu.classList.toggle('active', !isOpen);
            if (icon) icon.style.transform = !isOpen ? 'rotate(180deg)' : '';
        });
    });

    // Sub-dropdown toggles
    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', e => {
            e.stopPropagation();
            const menuId = btn.getAttribute('aria-controls');
            const menu = document.getElementById(menuId);
            const icon = btn.querySelector('.sub-dropdown-icon');
            const isOpen = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', String(!isOpen));
            if (menu) menu.classList.toggle('active', !isOpen);
            if (icon) icon.style.transform = !isOpen ? 'rotate(180deg)' : '';
        });
    });

    // Hamburger / mobile overlay
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    function openSidebar() { if (sidebar) sidebar.classList.add('open'); if (sidebarOverlay) sidebarOverlay.classList.add('active'); }
    function closeSidebar() { if (sidebar) sidebar.classList.remove('open'); if (sidebarOverlay) sidebarOverlay.classList.remove('active'); }

    if (hamburgerBtn) hamburgerBtn.addEventListener('click', () => sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar());
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

    // Sign out
    }

/* ---- INIT ---- */
document.addEventListener('DOMContentLoaded', () => {
    // Render Lucide icons (sidebar, header icons)
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();

    // Sidebar interactions
    lsaInitSidebar();

    // Data
    lsaPopulateLabFilter();
    lsaRenderAll();

    // Search
    document.getElementById('lsaSearchInput').addEventListener('input', e => {
        lsaState.search = e.target.value;
        lsaRenderTable();
    });

    // Lab filter
    document.getElementById('lsaLabFilter').addEventListener('change', e => {
        lsaState.lab = e.target.value;
        lsaRenderTable();
    });

    // Status filter
    document.getElementById('lsaStatusFilter').addEventListener('change', e => {
        lsaState.status = e.target.value;
        lsaRenderTable();
    });

    // Clear filters
    document.getElementById('lsaClearFilters').addEventListener('click', () => {
        lsaState.search = '';
        lsaState.lab = 'all';
        lsaState.status = 'all';
        document.getElementById('lsaSearchInput').value = '';
        document.getElementById('lsaLabFilter').value = 'all';
        document.getElementById('lsaStatusFilter').value = 'all';
        lsaRenderTable();
    });

    // Detail modal close buttons
    document.getElementById('lsaDetailClose').addEventListener('click', lsaCloseDetail);
    document.getElementById('lsaDetailCloseBtn').addEventListener('click', lsaCloseDetail);
    document.getElementById('lsaDetailModal').addEventListener('click', e => {
        if (e.target === document.getElementById('lsaDetailModal')) lsaCloseDetail();
    });

    // Action button (Received / Resolved)
    document.getElementById('lsaActionBtn').addEventListener('click', () => {
        const r = lsaGetById(lsaCurrentId);
        if (!r || r.status === 'Resolved') return;
        lsaOpenConfirm(r.status === 'Pending' ? 'received' : 'resolved');
    });

    // Confirm modal
    document.getElementById('lsaConfirmClose').addEventListener('click', lsaCloseConfirm);
    document.getElementById('lsaConfirmCancel').addEventListener('click', lsaCloseConfirm);
    document.getElementById('lsaConfirmYes').addEventListener('click', lsaApplyAction);
    document.getElementById('lsaConfirmOverlay').addEventListener('click', e => {
        if (e.target === document.getElementById('lsaConfirmOverlay')) lsaCloseConfirm();
    });

    // ESC key
    document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        if (document.getElementById('lsaConfirmOverlay').classList.contains('active')) {
            lsaCloseConfirm();
        } else if (document.getElementById('lsaDetailModal').classList.contains('active')) {
            lsaCloseDetail();
        }
    });
});
