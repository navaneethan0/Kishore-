﻿/* ============================================================
   EQUIPMENT TRACKING — NEW UI SCRIPT
   ============================================================ */

/* ---- MOCK DATA ---- */
const eqpData = [
    {
        id: 'EQ-001',
        name: '3D Printer',
        lab: 'Mechanical Lab',
        category: 'Manufacturing',
        status: 'Available',
        utilization: 71, // percent
        nextBookingTime: '03:00 PM – 05:00 PM',
        nextBookingTeam: 'TEAM-002',
        maintenance: 'None'
    },
    {
        id: 'EQ-005',
        name: 'CNC Milling Machine',
        lab: 'Mechanical Lab',
        category: 'Manufacturing',
        status: 'Under Maintenance',
        utilization: 0,
        nextBookingTime: 'Not Available',
        nextBookingTeam: '',
        maintenance: 'Today',
        maintTime: '09:00 AM – 05:00 PM'
    },
    {
        id: 'EQ-006',
        name: 'Digital Oscilloscope',
        lab: 'Electronics Lab',
        category: 'Electronics',
        status: 'Available',
        utilization: 88,
        nextBookingTime: 'No upcoming',
        nextBookingTeam: '',
        maintenance: 'Today',
        maintTime: '03:00 PM – 05:00 PM'
    },
    {
        id: 'EQ-010',
        name: 'Laser Cutter',
        lab: 'Mechanical Lab',
        category: 'Manufacturing',
        status: 'Available',
        utilization: 44,
        nextBookingTime: 'No upcoming',
        nextBookingTeam: '',
        maintenance: 'Tomorrow',
        maintTime: '03:00 PM – 06:00 PM'
    },
    {
        id: 'EQ-012',
        name: 'Soldering Station',
        lab: 'Electronics Lab',
        category: 'Electronics',
        status: 'Available',
        utilization: 70,
        nextBookingTime: '03:00 PM – 05:00 PM',
        nextBookingTeam: 'TEAM-005',
        maintenance: 'None'
    }
];

const mockSchedule = [
    { time: '09:00 AM – 09:45 AM', type: 'Available', label: 'Available' },
    { time: '09:45 AM – 10:45 AM', type: 'Booked', team: 'TEAM-003', project: 'Agriculture Bot' },
    { time: '10:45 AM – 11:30 AM', type: 'Available', label: 'Available' },
    { time: '11:30 AM – 12:00 PM', type: 'Available', label: 'Available' },
    { time: '12:00 PM – 01:00 PM', type: 'Lunch', label: 'Lunch Break' },
    { time: '01:00 PM – 02:30 PM', type: 'Booked', team: 'TEAM-001', project: 'Solar Car Project' },
    { time: '02:30 PM – 03:45 PM', type: 'Available', label: 'Available' },
    { time: '03:45 PM – 04:45 PM', type: 'Available', label: 'Available' },
    { time: '04:45 PM – 05:00 PM', type: 'Available', label: 'Available' }
];

/* ---- STATE ---- */
let state = {
    search: '',
    lab: 'all',
    cat: 'all',
    status: 'all',
    avail: 'all',
    activeEqp: null
};

/* ---- HELPERS ---- */
function getUtilColorClass(pct) {
    if (pct < 30) return 'low';
    if (pct < 75) return 'mid';
    return 'high';
}
function renderStatusBadge(status) {
    let cls = 'available';
    if (status === 'Under Maintenance') cls = 'maintenance';
    if (status === 'Booked') cls = 'booked';
    return `<span class="et-badge ${cls}">${status}</span>`;
}

function showToast(msg) {
    const t = document.getElementById('etToast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
}

/* ---- OVERVIEW LIST ---- */
function renderOverview() {
    const tbody = document.getElementById('etTableBody');
    if (!tbody) return;

    let filtered = eqpData.filter(e => {
        let matchS = !state.search || e.name.toLowerCase().includes(state.search) || e.id.toLowerCase().includes(state.search);
        let matchL = state.lab === 'all' || e.lab === state.lab;
        let matchC = state.cat === 'all' || e.category === state.cat;
        let matchSt = state.status === 'all' || e.status === state.status;
        return matchS && matchL && matchC && matchSt;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr class="et-empty-row"><td colspan="8">No equipment found matching criteria.</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(e => {
        let maintHtml = `<span class="et-maint-none">None</span>`;
        if (e.maintenance === 'Today') {
            maintHtml = `<div class="et-maint-today">Today</div><div class="et-maint-time">${e.maintTime}</div>`;
        } else if (e.maintenance === 'Tomorrow') {
            maintHtml = `<div class="et-maint-tomorrow">Tomorrow</div><div class="et-maint-time">${e.maintTime}</div>`;
        }

        let utilClass = getUtilColorClass(e.utilization);
        let bookingHtml = e.nextBookingTeam
            ? `<div class="et-booking-time">${e.nextBookingTime}</div><div class="et-booking-team">${e.nextBookingTeam}</div>`
            : `<span class="et-no-booking">${e.nextBookingTime}</span>`;

        return `
            <tr>
                <td>
                    <div class="et-eqp-cell">
                        <div class="et-eqp-icon"><i data-lucide="settings"></i></div>
                        <div>
                            <div class="et-eqp-id">${e.id}</div>
                            <div class="et-eqp-name">${e.name}</div>
                        </div>
                    </div>
                </td>
                <td style="font-weight:500">${e.lab}</td>
                <td>${e.category}</td>
                <td>${renderStatusBadge(e.status)}</td>
                <td>
                    <div class="et-util-wrap">
                        <span class="et-util-pct">${e.utilization}%</span>
                        <div class="et-util-bar-bg"><div class="et-util-bar-fill ${utilClass}" style="width:${e.utilization}%"></div></div>
                    </div>
                </td>
                <td>${bookingHtml}</td>
                <td>${maintHtml}</td>
                <td><button class="et-manage-btn" onclick="openPlanner('${e.id}')"><i data-lucide="calendar"></i> Manage Schedule <i data-lucide="chevron-right" style="width:12px;height:12px;margin-left:2px"></i></button></td>
            </tr>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons();
}

function handleFilters() {
    document.getElementById('etSearch').addEventListener('input', e => { state.search = e.target.value.toLowerCase(); renderOverview(); });
    document.getElementById('etCatFilter').addEventListener('change', e => { state.cat = e.target.value; renderOverview(); });
    document.getElementById('etStatusFilter').addEventListener('change', e => { state.status = e.target.value; renderOverview(); });

    document.getElementById('etResetBtn').addEventListener('click', () => {
        state = { search: '', lab: 'all', cat: 'all', status: 'all', avail: 'all', activeEqp: null };
        document.getElementById('etSearch').value = '';
        document.getElementById('etCatFilter').value = 'all';
        document.getElementById('etStatusFilter').value = 'all';
        renderOverview();
    });
}

/* ---- PLANNER ---- */
function openPlanner(id) {
    const eq = eqpData.find(e => e.id === id);
    if (!eq) return;

    document.getElementById('etOverviewSection').style.display = 'none';
    document.getElementById('etPlannerSection').style.display = 'block';

    document.getElementById('etPlannerBreadcrumbTitle').textContent = `${eq.name} (${eq.id})`;

    document.getElementById('pdId').textContent = eq.id;
    document.getElementById('pdName').textContent = eq.name;
    document.getElementById('pdLab').textContent = eq.lab;
    document.getElementById('pdCat').textContent = eq.category;
    document.getElementById('pdStatus').innerHTML = renderStatusBadge(eq.status);

    document.getElementById('pdUtilText').textContent = eq.utilization + '%';
    document.getElementById('pdUtilBar').style.width = eq.utilization + '%';
    document.getElementById('pdUtilBar').className = 'et-util-bar-fill-sm ' + getUtilColorClass(eq.utilization);

    renderTimeline();
}

function closePlanner() {
    document.getElementById('etOverviewSection').style.display = 'block';
    document.getElementById('etPlannerSection').style.display = 'none';
}

function renderTimeline() {
    const slots = document.getElementById('etTimelineSlots');
    slots.innerHTML = mockSchedule.map(s => {
        if (s.type === 'Available') {
            return `
                <div class="et-slot available">
                    <div class="et-slot-time">${s.time}</div>
                    <div class="et-slot-dot green"></div>
                    <div class="et-slot-label green">Available</div>
                </div>
            `;
        } else if (s.type === 'Booked') {
            return `
                <div class="et-slot booked">
                    <div class="et-slot-time">${s.time}</div>
                    <div class="et-slot-dot blue"></div>
                    <div>
                        <div class="et-slot-team">${s.team}</div>
                        <div class="et-slot-project">Project: ${s.project}</div>
                    </div>
                </div>
            `;
        } else if (s.type === 'Lunch') {
            return `
                <div class="et-slot lunch">
                    <div class="et-slot-time">${s.time}</div>
                    <div class="et-slot-dot gray"></div>
                    <div class="et-slot-label gray">Lunch Break</div>
                </div>
            `;
        }
        return '';
    }).join('');
}

/* ---- SIDEBAR HELPERS ---- */
function initSidebar() {
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    function openSidebar() {
        if (sidebar) sidebar.classList.add('open');
        if (sidebarOverlay) sidebarOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('open');
        if (sidebarOverlay) sidebarOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (hamburgerBtn) hamburgerBtn.addEventListener('click', () => {
        sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const menuId = btn.getAttribute('aria-controls');
            const menu = document.getElementById(menuId);
            const icon = btn.querySelector('.dropdown-icon');
            const isOpen = btn.getAttribute('aria-expanded') === 'true';

            // Close siblings
            document.querySelectorAll('.dropdown-toggle').forEach(other => {
                if (other !== btn) {
                    other.setAttribute('aria-expanded', 'false');
                    other.classList.remove('active');
                    const otherMenu = document.getElementById(other.getAttribute('aria-controls'));
                    if (otherMenu) otherMenu.classList.remove('active');
                    const otherIcon = other.querySelector('.dropdown-icon');
                    if (otherIcon) otherIcon.style.transform = '';
                }
            });

            btn.setAttribute('aria-expanded', String(!isOpen));
            btn.classList.toggle('active', !isOpen);
            if (menu) menu.classList.toggle('active', !isOpen);
            if (icon) icon.style.transform = !isOpen ? 'rotate(180deg)' : '';
        });
    });

    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', e => {
            e.stopPropagation();
            const menuId = btn.getAttribute('aria-controls');
            const menu = document.getElementById(menuId);
            const icon = btn.querySelector('.sub-dropdown-icon');
            const isOpen = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', String(!isOpen));
            if (menu) menu.classList.toggle('active', !isOpen);
            if (icon) icon.style.transform = !isOpen ? 'rotate(180deg)' : '';
        });
    });
}

/* ---- INIT ---- */
document.addEventListener('DOMContentLoaded', () => {
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    initSidebar();

    // Wire up events
    handleFilters();
    renderOverview();

    document.getElementById('etBackBtn').addEventListener('click', closePlanner);

    const blockBtn = document.getElementById('blockMaintBtn');
    if (blockBtn) {
        blockBtn.addEventListener('click', () => {
            showToast('Maintenance schedule submitted.');
            setTimeout(closePlanner, 800);
        });
    }

    const cancelBtn = document.querySelector('.et-cancel-btn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closePlanner);
    }
});
