﻿/* ============================================================
   RETURN STATUS — SCRIPTS
   ============================================================ */

/* ---- MOCK DATA ---- */
const mockComponents = [
    {
        teamId: 'TEAM-001', retId: 'RET-001', status: 'Pending', project: 'Solar Car Project',
        items: [
            { id: 'EQ-006', name: 'Digital Oscilloscope', issued: 1, c_ret: 1, good: true, statStr: 'Returned (Good)', statCls: 'good' },
            { id: 'EQ-010', name: 'Laser Cutter', issued: 1, c_ret: 0, good: false, statStr: 'Out with Team', statCls: 'out' },
            { id: 'EQ-001', name: '3D Printer', issued: 1, c_ret: 0, good: false, statStr: 'Overdue', statCls: 'over' }
        ]
    },
    {
        teamId: 'TEAM-002', retId: 'RET-005', status: 'Pending', project: 'Smart Home Hub',
        items: [
            { id: 'C-011', name: 'Soldering Station', issued: 1, c_ret: 1, good: true, statStr: 'Returned (Good)', statCls: 'good' },
            { id: 'EQ-006', name: 'Digital Oscilloscope', issued: 1, c_ret: 0, good: false, statStr: 'Out with Team', statCls: 'out' },
            { id: 'C-088', name: 'Hot Air Rework Station', issued: 1, c_ret: 0, good: false, statStr: 'Overdue', statCls: 'over' }
        ]
    },
    {
        teamId: 'TEAM-003', retId: 'RET-002', status: 'Pending', project: 'Agriculture Bot',
        items: [
            { id: 'M-02', name: 'Bench Multimeter', issued: 1, c_ret: 0, good: false, statStr: 'Overdue', statCls: 'over' },
            { id: 'C-011', name: 'Soldering Station', issued: 1, c_ret: 0, good: false, statStr: 'Out with Team', statCls: 'out' },
            { id: 'PWR-1', name: 'Variable DC Power Supply', issued: 1, c_ret: 1, good: true, statStr: 'Returned (Good)', statCls: 'good' }
        ]
    }
];

const mockTools = [
    {
        teamId: 'TEAM-001', retId: 'TRET-001', status: 'Pending', project: 'Solar Car Project',
        items: [
            { id: 'T001', name: 'Screw Driver Set', issued: 1, c_ret: 0, good: false, statStr: 'Out with Team', statCls: 'out' }
        ]
    },
    {
        teamId: 'TEAM-002', retId: 'TRET-002', status: 'Returned', project: 'Smart Home Hub',
        items: [
            { id: 'T042', name: 'Soldering Iron', issued: 2, c_ret: 2, good: true, statStr: 'Returned (Good)', statCls: 'good' }
        ]
    },
    {
        teamId: 'TEAM-003', retId: 'TRET-003', status: 'Pending', project: 'Agriculture Bot',
        items: [
            { id: 'T019', name: 'Digital Multimeter', issued: 3, c_ret: 0, good: false, statStr: 'Overdue', statCls: 'over' }
        ]
    }
];

const kpiData = {
    components: { total: 35, overdue: 14, returned: 11, damaged: 0 },
    tools: { total: 9, overdue: 4, returned: 3, damaged: 0 }
};

/* ---- STATE ---- */
let currentTab = 'components'; // 'components' or 'tools'
let currentFilter = 'all'; // 'all', 'out', 'returned'
let searchQuery = '';

/* ---- DOM ELEMENTS ---- */
const cardsGrid = document.getElementById('rsCardsGrid');
const kpiTotal = document.getElementById('kpiTotal');
const kpiOverdue = document.getElementById('kpiOverdue');
const kpiReturned = document.getElementById('kpiReturned');
const kpiDamaged = document.getElementById('kpiDamaged');

/* Panel Elements */
const panelOverlay = document.getElementById('rsPanelOverlay');
const panel = document.getElementById('rsPanel');
const plProjectName = document.getElementById('plProjectName');
const plTeamId = document.getElementById('plTeamId');
const plActiveCount = document.getElementById('plActiveCount');
const plOverdueCount = document.getElementById('plOverdueCount');

const plTableHeadRow = document.getElementById('plTableHeadRow');
const plTableBody = document.getElementById('plTableBody');

const lblSumIssued = document.getElementById('lblSumIssued');
const lblSumReturned = document.getElementById('lblSumReturned');
const plSumIssued = document.getElementById('plSumIssued');
const plSumReturned = document.getElementById('plSumReturned');
const plSumDamaged = document.getElementById('plSumDamaged');
const plSumOverall = document.getElementById('plSumOverall');

const chkConfirm = document.getElementById('chkConfirmInspect');
const btnSubmit = document.getElementById('btnProcessSubmit');
const toast = document.getElementById('rsToast');

/* ---- RENDER LOGIC ---- */
function getActiveData() {
    let base = currentTab === 'components' ? mockComponents : mockTools;

    let filteredData = base.reduce((acc, c) => {
        let titleMatch = c.teamId.toLowerCase().includes(searchQuery) || c.retId.toLowerCase().includes(searchQuery);
        let itemsMatch = c.items.some(i => i.name.toLowerCase().includes(searchQuery));

        if (currentTab === 'tools') {
            let filterMatch = true;
            if (currentFilter === 'out') filterMatch = c.status === 'Pending';
            if (currentFilter === 'returned') filterMatch = c.status === 'Returned';

            if ((titleMatch || itemsMatch) && filterMatch) {
                acc.push(c);
            }
        } else {
            // Components logic: filter items within the card
            let filteredItems = c.items.filter(i => {
                let fMatch = true;
                if (currentFilter === 'out') {
                    fMatch = i.statStr === 'Out with Team' || i.statStr === 'Overdue';
                } else if (currentFilter === 'returned') {
                    fMatch = i.statStr.includes('Returned');
                }

                let sMatch = (searchQuery === '') || titleMatch || i.name.toLowerCase().includes(searchQuery);
                return fMatch && sMatch;
            });

            if (filteredItems.length > 0) {
                acc.push({ ...c, items: filteredItems });
            }
        }
        return acc;
    }, []);

    return filteredData;
}

function updateKPIs() {
    let d = currentTab === 'components' ? kpiData.components : kpiData.tools;
    kpiTotal.textContent = String(d.total).padStart(2, '0');
    kpiOverdue.textContent = String(d.overdue).padStart(2, '0');
    kpiReturned.textContent = String(d.returned).padStart(2, '0');
    kpiDamaged.textContent = String(d.damaged).padStart(2, '0');
}

function renderCards() {
    const data = getActiveData();
    if (data.length === 0) {
        cardsGrid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:#64748b;">No returns match your criteria.</div>`;
        return;
    }

    cardsGrid.innerHTML = data.map((c, i) => {
        const bdgCls = c.status === 'Pending' ? 'pending' : 'returned';

        let itemsHtml = c.items.map(it => `
            <div class="rs-item-row">
                <span class="rs-item-name">${it.name} (x${it.issued})</span>
                <span class="rs-item-stat ${it.statCls}">${it.statStr}</span>
            </div>
        `).join('');

        let isRet = c.status === 'Returned';
        let btnHtml = isRet
            ? `<button class="rs-view-btn">View Return Details</button>`
            : `<button class="rs-process-btn" onclick="openProcessPanel('${c.retId}')">Process Return</button>`;

        return `
            <div class="rs-card">
                <div class="rs-badge ${bdgCls}">${c.status}</div>
                <div style="margin-top:20px;"></div>
                <div class="rs-meta-grid">
                    <div class="rs-meta-label">TEAM ID</div>
                    <div class="rs-meta-val">${c.teamId}</div>
                    <div class="rs-meta-label">RETURN ID</div>
                    <div class="rs-meta-val">${c.retId}</div>
                </div>
                <div class="rs-list-title">ITEMS LIST</div>
                <div style="margin-bottom:20px;">
                    ${itemsHtml}
                </div>
                <div class="rs-card-footer">
                    ${btnHtml}
                </div>
            </div>
        `;
    }).join('');
}

/* ---- TAB & FILTER BINDINGS ---- */
document.getElementById('btnTabComponents').addEventListener('click', e => {
    e.target.classList.add('active');
    document.getElementById('btnTabTools').classList.remove('active');
    currentTab = 'components';
    updateKPIs();
    renderCards();
});

document.getElementById('btnTabTools').addEventListener('click', e => {
    e.target.classList.add('active');
    document.getElementById('btnTabComponents').classList.remove('active');
    currentTab = 'tools';
    updateKPIs();
    renderCards();
});

document.querySelectorAll('.rs-filter-btn').forEach(btn => {
    btn.addEventListener('click', e => {
        document.querySelectorAll('.rs-filter-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        currentFilter = e.target.getAttribute('data-filter');
        renderCards();
    });
});

document.getElementById('rsSearchInput').addEventListener('input', e => {
    searchQuery = e.target.value.toLowerCase();
    renderCards();
});

/* ---- SLIDE-OUT PANEL ---- */
function openProcessPanel(retId) {
    let source = currentTab === 'components' ? mockComponents : mockTools;
    let act = source.find(x => x.retId === retId);
    if (!act) return;

    chkConfirm.checked = false;
    btnSubmit.disabled = true;

    // Header content
    plProjectName.textContent = act.project;
    plTeamId.textContent = `${act.teamId}  |  ${act.status === 'Pending' ? '<span class="rs-badge pending" style="position:relative;top:auto;left:auto;padding:2px 10px;font-size:11px;margin-left:8px;">Pending</span>' : ''}`;
    plTeamId.innerHTML = `${act.teamId} <span class="rs-badge pending" style="position:relative;top:auto;left:auto;padding:2px 10px;font-size:11px;margin-left:12px;">Pending</span>`;

    let overCount = act.items.filter(x => x.statStr === 'Overdue').length;
    let actCount = act.items.filter(x => x.statStr === 'Out with Team' || x.statStr === 'Overdue').length;
    plActiveCount.textContent = actCount;
    plOverdueCount.textContent = overCount;

    lblSumIssued.textContent = currentTab === 'components' ? 'Total Items Issued' : 'Total Tools Issued';
    lblSumReturned.textContent = currentTab === 'components' ? 'Total Items Returned' : 'Total Tools Returned';

    // Table Titles
    plTableHeadRow.innerHTML = currentTab === 'tools'
        ? `<th>Tool ID</th><th>Tool Name</th><th>Issued Count</th><th style="text-align:center">Returned Count</th><th style="text-align:center">Returned in Good Condition</th>`
        : `<th>Item ID</th><th>Item Name</th><th>Issued Count</th><th style="text-align:center">Returned Count</th><th style="text-align:center">Returned in Good Condition</th>`;

    plTableBody.innerHTML = act.items.map(it => {
        let chk = it.good ? 'checked' : '';
        return `
            <tr>
                <td class="strong">${it.id}</td>
                <td>${it.name}</td>
                <td>${it.issued}</td>
                <td style="text-align:center"><input type="number" class="rs-num-input" value="${it.c_ret || it.issued}" min="0" max="${it.issued}"></td>
                <td style="text-align:center"><input type="checkbox" class="rs-checkbox" ${chk}></td>
            </tr>
        `;
    }).join('');

    // Summary calculation dummy
    let totalIss = act.items.reduce((s, it) => s + it.issued, 0);
    plSumIssued.textContent = totalIss;
    plSumReturned.textContent = totalIss; // Default mocking
    plSumDamaged.textContent = "0";

    panelOverlay.classList.add('show');
    panel.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeProcessPanel() {
    panelOverlay.classList.remove('show');
    panel.classList.remove('open');
    document.body.style.overflow = '';
}

document.getElementById('rsPanelClose').addEventListener('click', closeProcessPanel);
document.getElementById('btnProcessCancel').addEventListener('click', closeProcessPanel);
panelOverlay.addEventListener('click', closeProcessPanel);

chkConfirm.addEventListener('change', e => {
    btnSubmit.disabled = !e.target.checked;
});

btnSubmit.addEventListener('click', () => {
    toast.textContent = "Return processed successfully";
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
    closeProcessPanel();
});


/* ---- SIDEBAR INIT (Preserved from standard layout) ---- */
function initSidebar() {
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (hamburgerBtn) hamburgerBtn.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
    });
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('active');
        document.body.style.overflow = '';
    });

    document.querySelectorAll('.dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const menuId = btn.getAttribute('aria-controls');
            const menu = document.getElementById(menuId);
            const isOpen = btn.getAttribute('aria-expanded') === 'true';

            document.querySelectorAll('.dropdown-toggle').forEach(other => {
                if (other !== btn) {
                    other.setAttribute('aria-expanded', 'false');
                    other.classList.remove('active');
                    const om = document.getElementById(other.getAttribute('aria-controls'));
                    if (om) om.classList.remove('active');
                }
            });

            btn.setAttribute('aria-expanded', String(!isOpen));
            btn.classList.toggle('active', !isOpen);
            if (menu) menu.classList.toggle('active', !isOpen);
        });
    });

    document.querySelectorAll('.sub-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const menu = document.getElementById(btn.getAttribute('aria-controls'));
            const isOpen = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', String(!isOpen));
            if (menu) menu.classList.toggle('active', !isOpen);
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    if (typeof lucide !== 'undefined') lucide.createIcons();
    initSidebar();
    updateKPIs();
    renderCards();
});
