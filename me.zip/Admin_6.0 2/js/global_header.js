/* ============================================================
   GLOBAL HEADER — Notifications + Profile Modal
   Shared across ALL portal pages.
   Must be loaded LAST (after all page-specific JS).
   ============================================================ */

(function () {
    // Default notification data shown on every page
    var DEFAULT_NOTIFICATIONS = [
        { id: 1, message: 'New deadline approaching for Team Alpha', time: '2 hours ago', read: false, type: 'deadline' },
        { id: 2, message: 'Ticket requires attention', time: '5 hours ago', read: false, type: 'ticket' },
        { id: 3, message: 'Team Beta submitted Stage 4 report', time: '1 day ago', read: true, type: 'project' }
    ];

    var iconColors = {
        deadline: { bg: '#fef2f2', color: '#ef4444' },
        ticket: { bg: '#fffbeb', color: '#f59e0b' },
        project: { bg: '#dbeafe', color: '#3b82f6' }
    };

    function getNotifications() {
        try {
            if (window.__RPL_DB__ && window.__RPL_DB__.notifications) {
                return window.__RPL_DB__.notifications;
            }
        } catch (e) { }
        return DEFAULT_NOTIFICATIONS;
    }

    function renderNotificationList(list, notifications) {
        if (!list) return;

        if (!notifications || notifications.length === 0) {
            list.innerHTML = '<li style="padding:16px;color:#94a3b8;font-size:13px;text-align:center;">No notifications</li>';
            return;
        }

        list.innerHTML = notifications.map(function (n) {
            var ic = iconColors[n.type] || iconColors.project;
            return '<li class="notification-item ' + (n.read ? '' : 'unread') + '" data-id="' + n.id + '" style="display:flex;gap:12px;padding:14px 16px;border-bottom:1px solid #f1f5f9;cursor:pointer;transition:background 0.2s;">' +
                '<div style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:' + ic.bg + ';color:' + ic.color + ';">' +
                '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>' +
                '</div>' +
                '<div style="display:flex;flex-direction:column;gap:3px;">' +
                '<p style="font-size:13px;color:#1e293b;line-height:1.4;margin:0;">' + n.message + '</p>' +
                '<span style="font-size:11px;color:#94a3b8;">' + n.time + '</span>' +
                '</div>' +
                '</li>';
        }).join('');

        // Click to mark individual as read
        list.querySelectorAll('.notification-item').forEach(function (item) {
            item.addEventListener('click', function () {
                var id = parseInt(item.dataset.id, 10);
                var notifications = getNotifications();
                var notif = notifications.find(function (n) { return n.id === id; });
                if (notif) {
                    notif.read = true;
                    item.classList.remove('unread');
                    item.style.background = '';
                    updateBadge(notifications);
                }
            });
        });
    }

    function updateBadge(notifications) {
        var badge = document.getElementById('notificationBadge');
        if (!badge) return;
        var unread = notifications.filter(function (n) { return !n.read; }).length;
        if (unread > 0) {
            badge.textContent = unread;
            badge.style.display = '';
        } else {
            badge.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {

        /* ---- Notification Dropdown ---- */
        var notifBtn = document.getElementById('notificationBtn');
        var notifDropdown = document.getElementById('notificationDropdown');
        var notifList = document.getElementById('notificationList');
        var markReadBtn = document.getElementById('markAllReadBtn');

        if (notifBtn && notifDropdown) {
            var notifications = getNotifications();

            // Populate the list
            renderNotificationList(notifList, notifications);
            updateBadge(notifications);

            // Toggle dropdown on bell click
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                var isOpen = notifDropdown.classList.contains('active');
                // Close all other dropdowns first
                document.querySelectorAll('.notification-dropdown.active').forEach(function (d) {
                    d.classList.remove('active');
                });
                if (!isOpen) {
                    notifDropdown.classList.add('active');
                }
            });

            // Prevent clicks inside dropdown from closing it
            notifDropdown.addEventListener('click', function (e) {
                e.stopPropagation();
            });

            // Close when clicking elsewhere
            document.addEventListener('click', function () {
                notifDropdown.classList.remove('active');
            });

            // Mark all read
            if (markReadBtn) {
                markReadBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    notifications.forEach(function (n) { n.read = true; });
                    renderNotificationList(notifList, notifications);
                    updateBadge(notifications);
                });
            }
        }

        /* ---- Profile Modal ---- */
        var profileBtn = document.getElementById('profileBtn');
        var profileModal = document.getElementById('globalProfileModal');
        var closeBtn = document.getElementById('closeGlobalProfileModal');
        var cancelBtn = document.getElementById('cancelGlobalProfileModal');

        function openProfile() {
            if (profileModal) {
                profileModal.classList.add('active');
            }
        }

        function closeProfile() {
            if (profileModal) {
                profileModal.classList.remove('active');
            }
        }

        if (profileBtn) {
            profileBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                openProfile();
            });
        }

        if (closeBtn) closeBtn.addEventListener('click', closeProfile);
        if (cancelBtn) cancelBtn.addEventListener('click', closeProfile);

        if (profileModal) {
            profileModal.addEventListener('click', function (e) {
                if (e.target === profileModal) closeProfile();
            });
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeProfile();
        });

        /* ---- Re-render Lucide icons ---- */
        if (window.lucide && window.lucide.createIcons) {
            window.lucide.createIcons();
        }
    });

})();
